let express=require("express");
const apiDoc=require("../clothing/modules/v1/Api_document/route");

let app_rouring=require("./modules/v1/app_routing");
const  config  = require("./config/config");
let cron=require("node-cron");
const common = require("./utilities/common");
let app=express();
app.use("/api-doc",apiDoc);
app.use(express.text());
app.use('/',require('../clothing/middelware/validation').extractHeaderLanguage);
app.use('/',require('../clothing/middelware/validation').validatorApikey);
app.use('/',require('../clothing/middelware/validation').validatorHeaderToken);
app_rouring.v1(app);
app.listen(config.server_listner,()=>{
    console.log("server running on ",config.server_listner);
    
})
