let md5 = require("md5");
let Commen = require("../../../../utilities/common");
const database = require("../../../../config/databse");
let error_code = require("../../../../utilities/error_response");
const common = require("../../../../utilities/common");
const { log } = require("math");
class userModule {
    async signUp(requireData, type, callback) {
        try {
            let mainresult = {}

            let deviceDetails = {
                device_token: common.generatetocken(10),
                os_version: requireData.os_version,
                app_version: requireData.os_version,
                device_type: requireData.device_type
            }

            if (!type || type == undefined) {
                let data = {
                    first_name: requireData.first_name,
                    last_name: requireData.last_name,
                    country_code_id: requireData.country_code_id,
                    phone: requireData.phone,
                    email: requireData.email,
                    password: md5(requireData.password)
                }
                let [check] = await database.query("select * from tbl_user where phone=? and email=? and is_deleted='0'", [data.phone, data.email]);
                if (check.length > 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "email and phone is alredy used",
                        data: []
                    })
                }



                let insert = "insert into tbl_user set ?";
                let [result] = await database.query(insert, data);
                if (result.length < 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "user is not register",
                        data: []
                    })
                }
                let otpDetails = {
                    user_id: result.insertId,
                    otp: Commen.GenerateOtp(),
                    phone: requireData.phone
                }
                deviceDetails.user_id = result.insertId;
                mainresult.user_details = result;

                await database.query("insert into tbl_otp set?", otpDetails);
            }
            else {
                let data = {
                    login_type: type,
                    step_count:3,
                    social_id: common.generatetocken(10)
                }
                let insert = "insert into tbl_user set ?";
                let [result] = await database.query(insert, data);
                if (result.length < 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "user is not register",
                        data: []
                    })
                }
                mainresult.user_details = result;
                deviceDetails.user_id = result.insertId;

            }

            await database.query("insert into tbl_device set ?", deviceDetails);
            return callback({
                code: error_code.success,
                keyword: "user is register",
                data: mainresult
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "user is not register",
                data: []
            })
        }
    }
    async logIn(requireData,type, callback) {
        let id=0;

        let deviceDetails={
            device_type:requireData.deviceType
        }

        if(type==undefined)
        {
                let data = {
                    password: md5(requireData.password),
                }
                
                let check = "select * from tbl_user where (phone=? or email=?) and password=? and is_deleted=0 and is_active=1";
                let [result] = await database.query(check, [requireData.phone, requireData.email, data.password]);
                console.log(result[0]);
                if (result.length <= 0) {
                    console.log("data not found");
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "user not found",
                        data: []
                    })
                }
                id=result[0].id;
                if (result[0].step_count == 1) {

                    return callback({
                        code: error_code.not_register,
                        content: { username: result[0].first_name },
                        keyword: "not_verified",
                    })
                }
                if (result[0].step_count == 2) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "set your location first",
                    })}
        }else{
                let check = "select * from tbl_user where login_type=? and social_id=? and is_deleted=0 and is_active=1";
                let [result] = await database.query(check, [type, requireData.social_id]);

                if (result.length <= 0) {
                    console.log("data not found");
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "user not found",
                        data: []
                    })
                }
                id=result[0].id;
             }
        await database.query("update tbl_device set ? where user_id=?", [deviceDetails,id])
        common.SetToken(id);
        return callback({
            code: error_code.success,
            keyword: "login_success",
        })


    }
    async logOut(requireData,callback) {
       try{ 
            let[result]= await database.query("update tbl_device set token='',device_type='', where user_id=?",[requireData.user_id]);
            if(result.length<=0){
                return callback({
                     code:error_code.not_approve,
                     keyword:"not logout"
                })
            }
            return callback({
                code:error_code.success,
                keyword:"logout successfuly"
           })
       }catch(Error){
        return callback({
            code:error_code.not_approve,
            keyword:"not logout"
        })
       }
    }
    async otpVerification(requireData, callback) {
        let data = {
            user_id: requireData.user_id,
            otp: requireData.otp
        }
        let [result] = await database.query("select * from tbl_otp where user_id=? and otp=?", [data.user_id, data.otp]);
        if (result.length <= 0) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no user found",
                data: []
            })
        }
        await database.query("update tbl_otp set is_verify='1' where user_id=?", [data.user_id]);
        let step_count =  await common.getStepCount(data.user_id);
        console.log(step_count);
        
        if (step_count == 1) {
            await database.query("update tbl_user set step_count=2 where id=?", [data.user_id]);
            common.SetToken(data.user_id);
        }
        return callback({
            code: error_code.success,
            keyword: "verification is complete",
            data: []
        })
    }
    async setLocation(requireData, callback) {
        if (requireData.step_count == 2) {
            let data = {
                latitude: requireData.latitude,
                longitude: requireData.longitude,
                address: requireData.address,
                id: requireData.user_id,

            }
            let [result] = await database.query("update tbl_user set ? where id=?", [data,data.id]);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "location is not updated yet",
                    data: []
                })
            }
            await database.query("update tbl_user set step_count=3 where id=?", [requireData.user_id])
            return callback({
                code: error_code.success,
                keyword: "location is set",
                data: result
            })
        }
        return callback({
            code: error_code.success,
            keyword: "Profile is completed",

        })
    }
    async forgotPassword(requireData, callback) {
        try {

            let [result] = await database.query("select * from tbl_user where (email=? or phone=?) and is_deleted=0 ", [requireData.email, requireData.phone])
            if (result <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "email id or phone is not found"
                })
            }

            let otp = Commen.GenerateOtp();
            await database.query("update tbl_otp set otp=? ,is_verify='0' where user_id=?", [otp, result[0].id])
            return callback({
                code: error_code.success,
                keyword: "otp sent to your device"
            })


        } catch (error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form",
            });
        }
    }
    async resetPassword(RequireData, callback) {
        try {
            let [verify] = await database.query("select * from tbl_otp where user_id=?", [RequireData.user_id]);
            if (verify[0].is_verify == 1) {
                let data = {
                    id: RequireData.user_id,
                    password: md5(RequireData.password)
                };
              
                let updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";

                let [result] = await database.query(updatePasswordQuery, [data.password, data.id]);

                if (result.length <= 0) {
                    return callback({
                        code: error_code.not_approve,
                        keyword: "password not changed"
                    });
                }

                return callback({
                    code: error_code.success,
                    keyword: "password changed"
                });
            }

            return callback({
                code: error_code.not_approve,
                keyword: "first verify your phone or email"
            });

        } catch (error) {
            console.error("Error in ResetPassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form"
            });
        }
    }
    async changePassword(RequireData, callback) {
        try {


            let oldPassword = md5(RequireData.old_password);
            let newPassword = md5(RequireData.new_password);

            let checkPasswordQuery = "SELECT * FROM tbl_user WHERE id=? and is_deleted=0 and is_active=1";

            let [result] = await database.query(checkPasswordQuery, [RequireData.user_id]);
            console.log(result[0]);

            if (!result.length) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "User not found"
                });
            }

            let dbPassword = result[0].password;

            // Check if old password matches
            if (dbPassword !== oldPassword) {
                return callback({
                    code: error_code.invalid_input,
                    keyword: "Old password does not match"
                });
            }


            if (newPassword === dbPassword) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Old password and new password cannot be the same"
                });
            }


            let updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";
            let [updateResult] = await database.query(updatePasswordQuery, [newPassword, RequireData.user_id]);

            if (updateResult.affectedRows <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "Password not changed"
                });
            }

            return callback({
                code: error_code.success,
                keyword: "Password changed successfully"
            });

        } catch (error) {
            console.error("Error in ChangePassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "Enter proper values in the form"
            });
        }
    }
    async addtocart(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                product_id: requireData.product_id,
                qty: requireData.qty,
            }

            let [item] = await database.query("select * from tbl_add_cart where product_id=?  and user_id=?", [data.product_id, data.user_id]);
            if (item.length <= 0) {
                let [result] = await database.query("insert into tbl_add_cart set?", [data]);
                if (result.length <= 0) {
                    return callback({
                        code: error_code.invalid_input,
                        keyword: "items is not selected",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "items is selected",
                    data: result
                })
            } else {
                data.qty = requireData.qty + item[0].qty;
                let [result] = await database.query("update tbl_add_cart set? where user_id=?", [data, data.user_id]);
                if (result.length <= 0) {
                    return callback({
                        code: error_code.invalid_input,
                        keyword: "items is not selected",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "items is selected",
                    data: result
                })
            }


        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "items is not selected",
                data: []
            })
        }

    }
    async placeOrder(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
            };
            let mainresult = {};
                let [cart] = await database.query(
                    `SELECT user_id, product_id, qty
                     FROM tbl_add_cart 
                     WHERE user_id = ? `,
                    [requireData.user_id]
                );
                if (cart.length === 0) {
                    return callback({
                        code: error_code.not_approve,
                        keyword: "Cart is empty, order not placed",
                        data: []
                    });
                }
                // Calculate total price
                let [price] = await database.query(
                    `SELECT SUM(m.price * a.qty) AS total 
                     FROM tbl_product AS m 
                     INNER JOIN tbl_add_cart AS a ON m.id = a.product_id
                     WHERE a.user_id = ? `,
                    [data.user_id]
                );
                let address=await common.getUserDetails(data.user_id);
                data.address=address[0].address
                console.log("Price:", price);      
                let distance= await common.getDistance(data.user_id);   
                console.log(distance);
                
                let delivery_charge=distance*20;      
                data.delivery_charge=delivery_charge;
                data.total_price = parseInt(price[0].total) +delivery_charge;

                // Insert order into tbl_order
                let [result] = await database.query("INSERT INTO tbl_order SET ?", [data]);
                mainresult.orders = result;

                if (result.length === 0) {
                    return callback({
                        code: error_code.not_approve,
                        keyword: "Order is not placed",
                        data: []
                    });
                }

                let sub_totals = 0;
                let qty = 0;

                // Insert order details
                for (let element of cart) {
                    let [productData] = await database.query(
                        "SELECT * FROM tbl_product WHERE id = ?",
                        [element.product_id]
                    );

                    let itemPrice = productData[0].price * element.qty;
                    sub_totals += itemPrice;
                    qty += element.qty;

                    await database.query(
                        `INSERT INTO tbl_order_detials (order_id, product_id, qty, price) 
                         VALUES (?, ?, ?, ?);`,
                        [result.insertId, element.product_id, element.qty, itemPrice]
                    );
                }

                console.log("Sub Total:", sub_totals);

                // Update order summary
                let updateOrder = {
                    sub_total: sub_totals,
                    total_qty: qty,
                    status: "confirm"
                };

                await database.query(
                    "UPDATE tbl_order SET ? WHERE id = ?",
                    [updateOrder, result.insertId]
                );
                // Delete cart items after order placement
                await database.query(
                    `DELETE a FROM tbl_add_cart AS a 
                     INNER JOIN tbl_product AS m ON m.id = a.product_id 
                     WHERE a.user_id = ? ;`,
                    [requireData.user_id]
                );

              /*  // Send order notification
                let notification = {
                    sender_id: 1,
                    reciver_id: requireData.user_id,
                    type: "place Order",
                    notification: "Your order has been placed successfully"
                };

                await database.query("INSERT INTO tbl_notification SET ?", [notification]);
                */
                return callback({
                    code: error_code.success,
                    keyword: "Order placed successfully",
                    data: mainresult
                });
            
        } catch (error) {
            console.error("Error in placeOrder:", error);
            return callback({
                code: error_code.not_approve,
                keyword: "Order not placed",
                data: []
            });
        }
    }
    async displayAllProduct(requireData, callback) {
        try {
            let mainresut = {};
            mainresut.user_details = await common.getUserDetails(requireData.user_id);

           let [allcategory]=await database.query("select * from tbl_category");
            mainresut.allcategory=allcategory;
            let [bestSeller] = await database.query("SELECT m.*,CASE WHEN EXISTS(SELECT 1 FROM tbl_product_like as f WHERE f.product_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM  tbl_product as m ORDER BY avg_rate DESC",[requireData.user_id]);
            mainresut.allpost = bestSeller;
            let[recentView]=await database.query("SELECT DISTINCT p.* FROM tbl_product as p INNER JOIN tbl_recentview as r on p.id=r.product_id WHERE r.user_id=? ORDER BY r.updateat DESC;",[requireData.user_id]);
            mainresut.recentView=recentView;
            if (mainresut.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "data is not found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresut
            })

        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "data not found",
                data: []
            })
        }
    }
    async displayProductDetails(requireData, callback) {
        try {
            let data = {
                product_id: requireData.product_id
            }
            let mainresult = {}
            let [result] = await database.query("select * from tbl_product  where id=?", [data.product_id]);
            mainresult.productDetails = result;
            let [colores] = await database.query("select c.name from tbl_product_color as p inner join tbl_colore as c on c.id=p.color_id where p.product_id=?", [data.product_id]);
            mainresult.colores = colores;
            let [size] = await database.query("select c.size from tbl_product_size as p inner join tbl_size as c on c.id=p.size_id where product_id=?", [data.product_id]);
            mainresult.size = size;
            if (result.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "data is not found",
                    data: []
                })
            }

            let [count]=await database.query("select * from tbl_recentview where product_id=? and user_id=?",[requireData.product_id,requireData.user_id]);
            let currentdate=new Date();
            console.log(currentdate);
            
            const formattedDate = currentdate.toISOString().slice(0, 19).replace('T', ' ');
            console.log(formattedDate);
            
            let view={
                user_id:requireData.user_id,
                product_id:requireData.product_id,
                updateat:currentdate
            }
            if(count.length<=0){
            await database.query("insert into  tbl_recentview set?",[view]);
        }else{
            await database.query("update tbl_recentview set? where  product_id=? and user_id=?",[view,requireData.product_id,requireData.user_id]);
        }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresult
            })
        } catch (Error) {
            console.log(Error);
            
            return callback({
                code: error_code.no_data_found,
                keyword: "data not found 1",
                data: []
            })
        }
    }
    async displayOrders(requireData, callback) {
        try {

            let [order] = await database.query("SELECT * FROM tbl_order WHERE  user_id=?", [requireData.user_id]);
            if (order.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "not data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: " data found",
                data: order
            })

        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
    }
    async addreview(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                product_id: requireData.product_id,
                review:requireData.review
                }
                let [result]=await database.query("insert into tbl_review set ?",[data]);
                if(result.length<=0){
                    return callback({
                        code:error_code.not_register,
                        keyword:"review in not register",
                        data:[]
                    })
                }
                let [count]=await database.query("select sum(user_id) as count from tbl_review where product_id=?",[data.product_id]);
                await database.query("update tbl_product set total_review=? where id=?",[count[0].count,data.product_id]);
                return callback({
                    code:error_code.success,
                    keyword:"Success",
                    data:result
                })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "review in not register",
                data: []
            })
        }

    }
    async addrating(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                product_id: requireData.product_id,
                rating:requireData.rating
                }
                let [result]=await database.query("insert into tbl_rating set ?",[data]);
                if(result.length<=0){
                    return callback({
                        code:error_code.not_register,
                        keyword:"rating is not register",
                        data:[]
                    })
                }
                let [count]=await database.query("select avg(rating) as count from tbl_rating where product_id=?",[data.product_id]);
                await database.query("update tbl_product set avg_rate=? where id=?",[count[0].count,data.product_id]);
                return callback({
                    code:error_code.success,
                    keyword:"Success",
                    data:result
                })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "rating is not register",
                data: []
            })
        }

    }
    async likeproduct(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                product_id: requireData.product_id,
                }
                let [result]=await database.query("insert into tbl_product_like set ?",[data]);
                if(result.length<=0){
                    return callback({
                        code:error_code.not_register,
                        keyword:"like is not register",
                        data:[]
                    })
                }
                let [count]=await database.query("select sum(DISTINCT(user_id)) as count from tbl_product_like where product_id=?",[data.product_id]);
                await database.query("update tbl_product set total_likes=? where id=?",[count[0].count,data.product_id]);
                return callback({
                    code:error_code.success,
                    keyword:"Success",
                    data:result
                })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "like is not register",
                data: []
            })
        }

    }
}
module.exports = new userModule();