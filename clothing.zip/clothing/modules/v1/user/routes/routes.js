let user=require("../controller/user");
let CustomeRoute=(app)=>{
    app.post("/v1/user/signup/:type?",user.singUp);
    app.post("/v1/user/login/:type?",user.logIn);
    app.post("/v1/user/logout",user.logOut);
    app.post("/v1/user/otpverification",user.otpVerify);
    app.post("/v1/user/setlocation",user.setlocation);
    app.post("/v1/user/forgotpassword",user.forgotPassword);
    app.post("/v1/user/resetpassword",user.resetPassword);
    app.post("/v1/user/changepassword",user.changePassword);
    app.post("/v1/user/addtocart",user.addToCart);
    app.post("/v1/user/placeorder",user.placeOrder);
    app.post("/v1/user/displayallproduct",user.displayAllProduct);
    app.post("/v1/user/displayproductdetails",user.displayProductDetails);
    app.post("/v1/user/displayorders",user.displayOrders);
    app.post("/v1/user/addreview",user.addreview);
    app.post("/v1/user/addrating",user.addrating);
    app.post("/v1/user/likeproduct",user.likeProduct);




 








    













}
module.exports=CustomeRoute;