let express=require("express");
const apiDoc=require("../cargo_ride/modules/v1/Api_document/route");
let cron=require('node-cron');
let app_rouring=require("./modules/v1/app_routing");
const  config  = require("./config/config");
const common = require("./utilities/common");
let app=express();
app.use("/api-doc",apiDoc);
app.use(express.text());
app.use('/',require('../cargo_ride/middelware/validation').extractHeaderLanguage);
app.use('/',require('../cargo_ride/middelware/validation').validatorApikey);
app.use('/',require('../cargo_ride/middelware/validation').validatorHeaderToken);
app_rouring.v1(app);
//cron.schedule('*/1 * * * *', () => {
  //  common.cancelOrder();    });
app.listen(config.server_listner,()=>{
    console.log("server running on ",config.server_listner);
    
})
