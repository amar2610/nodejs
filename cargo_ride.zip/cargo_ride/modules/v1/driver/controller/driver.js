let driverModule = require("../../driver/module/driver_module");
const middleware = require("../../../../middelware/validation");
let validation_rules = require("../../../../middelware/validation_rules");
const common = require("../../../../utilities/common");
class user {
    singUp(req, res) {
        let data = req.body;
     /*  if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        let rules="";
         rules = validation_rules.signUp;
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            driverModule.signUp(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    logIn(req, res) {
            let data = req.body;
            console.log(data);
        /*  if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/ let type=req.params.type;

         let rules="";
            if(type==undefined){
             rules = validation_rules.login;
            }else{
                rules=validation_rules.socialLogin
            }
            let message = {
                reauired: req.reauired
            }

            let keyword = {};
            if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
                driverModule.logIn(data, function (_respons) {
                    middleware.send_response(req, res, _respons);
                })
            }
       
    }
    logOut(req, res) {
        let data = req.body;
        
   /*  if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/ 

     let rules="";
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            driverModule.logOut(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
   
}
    otpVerify(req, res) {
        let data = req.body;
       /*  if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        let rules = validation_rules.verifyOtp;
        let message = {
            reauired: req.reauired
        }
        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            driverModule.otpVerification(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    addvehicleDetails(req, res) {
        let data = req.body;
        /*  if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        data.driver_id = req.driver_id;
        let rules = "";
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            driverModule.addvehicleDetails(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
     addAvailable(req, res) {
        let data = req.body;
        /*  if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        data.driver_id = req.driver_id;
        let rules ="";
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            driverModule.addAvailable(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    acceptOrder(req, res) {
        let data = req.body;
        /*  if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        data.driver_id = req.driver_id;
        let rules ="";
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            driverModule.acceptOrder(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    completeOrder(req, res) {
        let data = req.body;
        /*if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        data.driver_id = req.driver_id;
        let rules ="";
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            driverModule.completeOrder(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    forgotPassword(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = validation_rules.forgotPassword;
        let message = {
            reauired: req.reauired
        }
        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            driverModule.forgotPassword(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    resetPassword(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = validation_rules.resetPassword;
        let message = {
            reauired: req.reauired
        }
        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            driverModule.resetPassword(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    changePassword(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = validation_rules.changePassword;
        let message = {
            reauired: req.reauired
        }
        data.user_id = req.user_id;
        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            driverModule.changePassword(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    report(req, res) {
        let data = req.body;
        /* if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.driver_id = req.driver_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            driverModule.report(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayEarning(req, res) {
        let data = req.body;
        /* if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.driver_id = req.driver_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            driverModule.displayEarning(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayOrders(req, res) {
        let data = req.body;
        /* if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.driver_id = req.driver_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            driverModule.displayOrdes(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayOrderDetails(req, res) {
        let data = req.body;
        /* if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.driver_id = req.driver_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            driverModule.displayOrdersDetails(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayRatingAndReview(req, res) {
        let data = req.body;
        /* if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.driver_id = req.driver_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            driverModule.displayRatingAndReview(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayNotification(req, res) {
        let data = req.body;
        /* if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }*/
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.driver_id = req.driver_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            driverModule.displayNotification(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
}

module.exports = new user();