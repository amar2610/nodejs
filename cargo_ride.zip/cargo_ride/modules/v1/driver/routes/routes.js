let driver=require("../controller/driver");
let CustomeRoute=(app)=>{
    app.post("/v1/driver/signup/:type?",driver.singUp);
    app.post("/v1/driver/login/:type?",driver.logIn);
    app.post("/v1/driver/logout",driver.logOut);
    app.post("/v1/driver/otpverification",driver.otpVerify);
    app.post("/v1/driver/addvehicledetails",driver.addvehicleDetails);
    app.post("/v1/driver/forgotpassword",driver.forgotPassword);
    app.post("/v1/driver/resetpassword",driver.resetPassword);
    app.post("/v1/driver/changepassword",driver.changePassword);
    app.post("/v1/driver/addavailable",driver.addAvailable);
    app.post("/v1/driver/acceptorder",driver.acceptOrder);
    app.post("/v1/driver/completeorder",driver.completeOrder);
    app.post("/v1/driver/report",driver.report);
    app.post("/v1/driver/orders",driver.displayOrders);
    app.post("/v1/driver/orderdetails",driver.displayOrderDetails);
    app.post("/v1/driver/displayratingreview",driver.displayRatingAndReview);
    app.post("/v1/driver/displayearning",driver.displayEarning);
    app.post("/v1/driver/displaynotification",driver.displayNotification);






 








    













}
module.exports=CustomeRoute;