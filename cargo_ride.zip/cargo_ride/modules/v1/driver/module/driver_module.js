let md5 = require("md5");
let Commen = require("../../../../utilities/common");
const database = require("../../../../config/databse");
let error_code = require("../../../../utilities/error_response");
const common = require("../../../../utilities/common");
let template = require("../../../../utilities/template");
const { log } = require("math");

class driverModule {
    async signUp(requireData, callback) {
        try {
            let mainresult = {}

            let deviceDetails = {
                device_token: common.generatetocken(10),
                os_version: requireData.os_version,
                app_version: requireData.os_version,
                device_type: requireData.device_type
            }
            let data = {
                full_name: requireData.fullname,
                country_id: requireData.country_id,
                phone: requireData.phone,
                driver_image: requireData.user_image,
                email: requireData.email,
                password: md5(requireData.password),
                otp: common.GenerateOtp(),
                address: requireData.address,
                latitude: requireData.latitude,
                longitude: requireData.longitude
            }
            let [check] = await database.query("select * from tbl_driver where phone=? and email=? and is_deleted='0'", [data.phone, data.email]);
            if (check.length > 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "email and phone is alredy used",
                    data: []
                })
            }
            let insert = "insert into tbl_driver set ?";
            let [result] = await database.query(insert, data);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "user is not register",
                    data: []
                })
            }
            deviceDetails.user_id = result.insertId;
            deviceDetails.role = "driver";
            mainresult.user_details = result;
            await database.query("insert into tbl_device set ?", deviceDetails);
            return callback({
                code: error_code.success,
                keyword: "user is register",
                data: mainresult
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "user is not register",
                data: []
            })
        }
    }
    async logIn(requireData, callback) {
        let deviceDetails = {
            device_type: requireData.deviceType
        }
        let id = "";
        let name = "";

        let data = {
            password: md5(requireData.password),
        }

        console.log(data.password);

        let check = "select * from tbl_driver where (phone=? or email=?) and password=? and is_deleted=0 and is_active=1";
        let [result] = await database.query(check, [requireData.phone, requireData.email, data.password]);
        console.log(result[0]);
        if (result.length <= 0) {
            console.log("data not found");
            return callback({
                code: error_code.no_data_found,
                keyword: "driver not found",
                data: []
            })
        }
        id = result[0].id;
        name = result[0].full_name;

        if (result[0].step_count == 1) {
            return callback({
                code: error_code.not_register,
                content: { username: name },
                keyword: "not_verified",
            })
        } else if (result[0].step_count == 2) {
            return callback({
                code: error_code.not_register,
                content: { username: name },
                keyword: "Set Availability",
            })
        } else if (result[0].step_count == 3) {
            return callback({
                code: error_code.not_register,
                content: { username: name },
                keyword: "fullfile vehicle details",
            })
        }
        await database.query("update tbl_device set ? where user_id=? and role='driver'", [deviceDetails, id])
        common.SetToken(id, 'driver');
        return callback({
            code: error_code.success,
            content: { username: name },
            keyword: "login_success",
        })


    }
    async logOut(requireData, callback) {
        try {
            let [result] = await database.query("update tbl_device set token='',device_type='' where user_id=? and role=? ", [requireData.user_id, "user"]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "not logout"
                })
            }
            return callback({
                code: error_code.success,
                keyword: "logout successfuly"
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_approve,
                keyword: "not logout"
            })
        }
    }
    async otpVerification(requireData, callback) {
        let data = {
            user_id: requireData.id,
            otp: requireData.otp
        }
        let [result] = await database.query("select * from tbl_driver where id=? and otp=?", [data.user_id, data.otp]);
        if (result.length <= 0) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no driver found",
                data: []
            })
        }
        if (result[0].step_count == 1) {
            common.SetToken(data.user_id, 'driver');
        }
        await database.query("update tbl_driver set is_verify='1' ,step_count=2 where id=?", [data.user_id]);

        return callback({
            code: error_code.success,
            keyword: "verification is complete",
            data: []
        })
    }
    async addvehicleDetails(requireData, callback) {

        let data = {
            driver_id: requireData.driver_id,
            vehicle_category_id: requireData.vehicle_category_id,
            vehicle_company: requireData.vehicle_company,
            vehicle_number: requireData.vehicle_number,
            vehicle_rto: requireData.vehicle_rto,
            vehicle_model: requireData.vehicle_model,

        }
        let [result] = await database.query("insert into tbl_vehicle_details set?", [data]);
        if (result.length < 0) {
            return callback({
                code: error_code.not_register,
                keyword: "vehicle details is not register",
                data: []
            })
        }
        await database.query("update tbl_driver set step_count=4 where id=?", [data.driver_id])
        return callback({
            code: error_code.success,
            keyword: "vehicle details added successfully",
            data: result
        })
    }
    async forgotPassword(requireData, callback) {
        try {
            let [result] = await database.query("select * from tbl_driver where (email=? or phone=?) and is_deleted=0 ", [requireData.email, requireData.phone])
            if (result <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "email id or phone is not found"
                })
            }
            let otp = Commen.GenerateOtp();
            await database.query("update tbl_driver set otp=? ,is_verify='0' where id=? ", [otp, result[0].id]);
            return callback({
                code: error_code.success,
                keyword: "otp sent to your device"
            })


        } catch (error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form",
            });
        }
    }
    async resetPassword(RequireData, callback) {
        try {
            let [verify] = await database.query("select * from tbl_driver  where id=?", [RequireData.user_id]);
            if (verify[0].is_verify != 1) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "first verify your phone or email"
                });
            }
            let data = {
                id: RequireData.user_id,
                password: md5(RequireData.password)
            };

            let updatePasswordQuery = "UPDATE tbl_driver SET password=? WHERE id=?";

            let [result] = await database.query(updatePasswordQuery, [data.password, data.id]);

            if (result.length <= 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "password not changed"
                });
            }

            return callback({
                code: error_code.success,
                keyword: "password changed"
            });
        }
        catch (error) {
            console.error("Error in ResetPassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form"
            });
        }
    }
    async changePassword(RequireData, callback) {
        try {


            let oldPassword = md5(RequireData.old_password);
            let newPassword = md5(RequireData.new_password);

            let checkPasswordQuery = "SELECT * FROM tbl_driver WHERE id=? and is_deleted=0 and is_active=1";

            let [result] = await database.query(checkPasswordQuery, [RequireData.user_id]);
            console.log(result[0]);

            if (!result.length) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "Driver not found"
                });
            }

            let dbPassword = result[0].password;

            // Check if old password matches
            if (dbPassword !== oldPassword) {
                return callback({
                    code: error_code.invalid_input,
                    keyword: "Old password does not match"
                });
            }


            if (newPassword === dbPassword) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Old password and new password cannot be the same"
                });
            }


            let updatePasswordQuery = "UPDATE tbl_driver SET password=? WHERE id=?";
            let [updateResult] = await database.query(updatePasswordQuery, [newPassword, RequireData.user_id]);

            if (updateResult.affectedRows <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "Password not changed"
                });
            }

            return callback({
                code: error_code.success,
                keyword: "Password changed successfully"
            });

        } catch (error) {
            console.error("Error in ChangePassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "Enter proper values in the form"
            });
        }
    }
    async acceptOrder(requireData, callback) {
        try {
            let data = {
                order_id: requireData.order_id,
                status: requireData.status
            };
            if (data.status == "true") {
                let [result] = await database.query("update tbl_order set status='confirm', driver_id=? where id=?", [requireData.driver_id, data.order_id]);
                if (result.length <= 0) {
                    return callback({
                        code: error_code.success,
                        keyword: "Order is not placed ",
                        data: result
                    });
                }
                let [user] = await database.query("select * from tbl_order  where id=?", [data.order_id]);
                console.log(user[0].receiver_address_id);

                let [data1] = await database.query("select * from tbl_order_reciver_address where id=?", user[0].receiver_address_id)
                let notification = {
                    sender_id: 1,
                    reciver_id: user[0].user_id,
                    type: "place Order",
                    role: "user",
                    message: "Your order has been placed successfully"
                };
                data1[0].otp = user[0].otp;
                data1[0].otp_for = " complete order"

                common.sendMail("new order", data1[0].email, template.otp(data1[0]), function (error, res) { });

                await database.query("INSERT INTO tbl_notification SET ?", [notification]);
                return callback({
                    code: error_code.success,
                    keyword: "Order placed successfully",
                });
            }


        } catch (error) {
            console.error("Error in placeOrder:", error);
            return callback({
                code: error_code.not_approve,
                keyword: "Order not placed",
                data: []
            });
        }
    }
    async completeOrder(requireData, callback) {
        try {
            let data = {
                driver_id: requireData.driver_id,
                otp: requireData.otp,
                order_id: requireData.order_id
            }
            let [result] = await database.query("select * from tbl_order where otp=? and id=? and driver_id=?", [data.otp, data.order_id, data.driver_id]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "order is not complete",
                    data: []
                })
            }
            await database.query("update tbl_order set status='complete' where id=?", data.order_id);
            let notification = {
                sender_id: 1,
                reciver_id: result[0].user_id,
                type: "Order Complete",
                role: "user",
                message: "Your order has been complete successfully"
            };
            let [email] = await database.query("select * from tbl_user where id=?", [result[0].user_id]);
            // send gmail to the user
            common.sendMail("order is complete", email[0].email, template.order_details(await common.displayOrdersDetails(data.order_id)), function (error, res) { });
            await database.query("INSERT INTO tbl_notification SET ?", [notification]);
            return callback({
                code: error_code.not_approve,
                keyword: "order is  completed",
                data: result
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.not_approve,
                keyword: "order is not complete",
                data: []
            })
        }

    }
    async report(requireData, callback) {
        try {
            let data = {

                subject: requireData.subject,
                description: requireData.description,
                driver_id: requireData.driver_id,
                user_id: requireData.user_id
            }
            let images = requireData.images.split(',');
            let [result] = await database.query("insert into tbl_driver_report set ?", [data]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "report is not register",
                    data: []
                })
            }
            for (let i = 0; i < images.length; i++) {
                let imagedata = {
                    report_id: result.insertId,
                    image_name: images[i]
                }
                await database.query("insert into tbl_driver_report_image set ?", [imagedata]);
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "rrport is not register",
                data: []
            })
        }
    }
    async displayEarning(requireData, callback) {
        try {
            let [result] = await database.query(`SELECT * FROM tbl_order
            WHERE order_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) and driver_id=?`, requireData.driver_id);
            if (result.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
    }
    async displayNewOrders(requireData, callback) {
        try {
            let [result] = await database.query(`SELECT * FROM tbl_order
            WHERE status='pending' and is_active='1' and is_deleted='0'`);
            let 
            if (result.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
    }
    async displayOrdes(requireData, callback) {
        try {
            let type = requireData.type;

            let details = `SELECT o.user_id, r.full_name, r.email, r.phone, r.address AS receiverAddress,
       o.address_id,o.second_address_id,
       DATE_FORMAT(o.order_date, '%d-%m-%Y') AS date,
       TIME(o.order_date) AS time,
       (SELECT SUM(qty) FROM tbl_order_items WHERE order_id = o.id AND type = 'Document') AS document,
       (SELECT SUM(qty) FROM tbl_order_items WHERE order_id = o.id AND type = 'Package') AS package,
       COALESCE(a.address, s.address) AS sender_address
        FROM tbl_order AS o
        INNER JOIN tbl_order_reciver_address AS r ON r.id = o.receiver_address_id
        LEFT JOIN tbl_address AS a ON a.id = o.address_id 
        LEFT JOIN tbl_second_address AS s ON s.id = o.second_address_id
        WHERE o.driver_id=? and is_deleted=0`;
            if (type == 'running') {
                details = details + ' and date(order_date)=CURRENT_DATE'
            } else if (type == 'upcoming') {
                details = details + ' and date(o.order_date)>CURRENT_DATE'
            } else if (type == 'history') {
                details = details + ' and o.order_date<CURRENT_DATE'
            }
            let arrayresult = [];
            let [result] = await database.query(details, [requireData.driver_id]);
            for (let element of result) {

                let orderDetails = {};
                orderDetails.packageDetails = {
                    document: element.document,
                    package: element.package
                }

                orderDetails.locationDetails = {
                    sende_address: element.sender_address,
                    receiverAddress: element.receiverAddress
                }
                orderDetails.dateandtime = {
                    date: element.date,
                    time: element.time
                }

                arrayresult.push(orderDetails);

            }
            if (result.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: " data found",
                data: arrayresult
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
    }
    async displayOrdersDetails(requireData, callback) {
        try {

            let data = {
                order_id: requireData.order_id,
            }
            let result = await common.displayOrdersDetails(data.order_id);
            if (result.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            delete result.driver_details;
            return callback({
                code: error_code.success,
                keyword: " data found",
                data: result
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "no data found",
                data: []
            })
        }

    }
    async displayRatingAndReview(requireData, callback) {
        let [result] = await database.query("select u.user_image,u.full_name,r.rating,r.review from tbl_ratig as r inner join tbl_user as u on u.id=r.user_id where driver_id=? and is_deleted=0", requireData.driver_id)
        if (result.length <= 0) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
        return callback({
            code: error_code.success,
            keyword: " data found",
            data: result
        })
    }
    async displayNotification(requireData, callback) {
        let result = await common.displayNotification(requireData.driver_id, 'driver');
        if (result.length <= 0) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
        return callback({
            code: error_code.success,
            keyword: " data found",
            data: result
        })
    }

}
module.exports = new driverModule();