let md5 = require("md5");
let Commen = require("../../../../utilities/common");
const database = require("../../../../config/databse");
let error_code = require("../../../../utilities/error_response");
const common = require("../../../../utilities/common");
let template = require("../../../../utilities/template");
const message = require("../../../../language/en");


class userModule {
    async signUp(requireData, type, callback) {
        try {
            let mainresult = {}

            let deviceDetails = {
                device_token: common.generatetocken(10),
                os_version: requireData.os_version,
                app_version: requireData.os_version,
                device_type: requireData.device_type
            }
            let email = "";

            if (!type || type == undefined) {
                let data = {
                    full_name: requireData.fullname,
                    country_id: requireData.country_id,
                    phone: requireData.phone,
                    user_image: requireData.user_image,
                    email: requireData.email,
                    password: md5(requireData.password),
                    otp: common.GenerateOtp()
                }
                email = data.email;
                let [check] = await database.query("select * from tbl_user where phone=? and email=? and is_deleted='0'", [data.phone, data.email]);
                if (check.length > 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "email and phone is alredy used",
                        data: []
                    })
                }
                let insert = "insert into tbl_user set ?";
                let [result] = await database.query(insert, data);
                if (result.length < 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "user is not register",
                        data: []
                    })
                }
                let address = {
                    user_id: result.insertId,
                    address: requireData.address,
                    latitude: requireData.latitude,
                    longitude: requireData.longitude
                }
                await database.query("insert into tbl_address set?", [address]);
                data.otp_for="Emali Validation";
                common.sendMail("email verification", email, template.otp(data), function (error, res) { });
                deviceDetails.user_id = result.insertId;
                deviceDetails.role = "user";
                mainresult.user_details = result;
            }
            else {
                let data = {
                    login_type: type,
                    step_count: 3,
                    social_id: common.generatetocken(10)
                }
                let insert = "insert into tbl_user set ?";
                let [result] = await database.query(insert, data);
                if (result.length < 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "user is not register",
                        data: []
                    })
                }
                mainresult.user_details = result;
                deviceDetails.user_id = result.insertId;

            }

            await database.query("insert into tbl_device set ?", deviceDetails);

            return callback({
                code: error_code.success,
                keyword: "user is register",
                data: mainresult
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "user is not register",
                data: []
            })
        }
    }
    async logIn(requireData, type, callback) {
        let deviceDetails = {
            device_type: requireData.deviceType
        }
        let id = "";
        let name = "";
        if (type == undefined) {
            let data = {
                password: md5(requireData.password),
            }

            let check = "select * from tbl_user where (phone=? or email=?) and password=? and is_deleted=0 and is_active=1";
            let [result] = await database.query(check, [requireData.phone, requireData.email, data.password]);
            console.log(result[0]);
            if (result.length <= 0) {
                console.log("data not found");
                return callback({
                    code: error_code.no_data_found,
                    keyword: "user not found",
                    data: []
                })
            }
            id = result[0].id;
            name = result[0].full_name;

            if (result[0].step_count == 1) {

                return callback({
                    code: error_code.not_register,
                    content: { username: name },
                    keyword: "not_verified",
                })
            }

        } else {
            let check = "select * from tbl_user where login_type=? and social_id=? and is_deleted=0 and is_active=1";
            let [result] = await database.query(check, [type, requireData.social_id]);

            if (result.length <= 0) {
                console.log("data not found");
                return callback({
                    code: error_code.no_data_found,
                    keyword: "user not found",
                    data: []
                })
            }
            id = result[0].id;
            name = result[0].full_name;
        }
        await database.query("update tbl_device set ? where user_id=?", [deviceDetails, id])
        common.SetToken(id, 'user');
        return callback({
            code: error_code.success,
            content: { username: name },
            keyword: "login_success",
        })


    }
    async resentotp(requireData, callback) {

        let data = {
            user_id: requireData.user_id,
            otp: common.GenerateOtp()
        }

        let check = "select * from tbl_user where id=? and is_deleted=0 and is_active=1";
        let [result] = await database.query(check, [data.user_id]);
        console.log(result[0]);
        if (result.length <= 0) {
            console.log("data not found");
            return callback({
                code: error_code.no_data_found,
                keyword: "user not found",
                data: []
            })
        }
        await database.query("update tbl_user set  otp=? where id=?", [data.otp, data.user_id]);
        common.sendMail("OTP For Email Verification", result[0].email, template.otp(result[0]), function (error, res) { });
        return callback({
            code: error_code.success,
            keyword: "otp_success",
        })


    }
    async logOut(requireData, callback) {
        try {
            let [result] = await database.query("update tbl_device set token='',device_type='' where user_id=? and role=? ", [requireData.user_id, "user"]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "not logout"
                })
            }
            return callback({
                code: error_code.success,
                keyword: "logout successfuly"
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_approve,
                keyword: "not logout"
            })
        }
    }
    async otpVerification(requireData, callback) {
        let data = {
            user_id: requireData.id,
            otp: requireData.otp
        }
        let [result] = await database.query("select * from tbl_user where id=? and otp=?", [data.user_id, data.otp]);
        if (result.length <= 0) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no user found",
                data: []
            })
        }
        if (result[0].step_count == 1) {
            common.SetToken(data.user_id);
        }
        await database.query("update tbl_user set is_verify='1' ,step_count=2 where id=?", [data.user_id]);

        return callback({
            code: error_code.success,
            keyword: "verification is complete",
            data: []
        })
    }
    async addSecondLocation(requireData, callback) {
        let data = {
            full_name: requireData.full_name,
            email: requireData.email,
            country_id: requireData.country_id,
            latitude: requireData.latitude,
            longitude: requireData.longitude,
            address: requireData.address,
            user_id: requireData.user_id,

        }
        let [result] = await database.query("insert into tbl_second_address set ?", [data]);
        if (result.length < 0) {
            return callback({
                code: error_code.not_register,
                keyword: "location is not updated yet",
                data: []
            })
        }
        return callback({
            code: error_code.success,
            keyword: "location is set",
            data: result
        })
    }
    async forgotPassword(requireData, callback) {
        try {
            let [result] = await database.query("select * from tbl_user where (email=? or phone=?) and is_deleted=0 ", [requireData.email, requireData.phone])
            if (result <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "email id or phone is not found"
                })
            }
            let otp = Commen.GenerateOtp();
            const insertOtpQuery = `
            INSERT INTO tbl_otp (user_id,email, expires_at,otp) 
            VALUES (?,?, DATE_ADD(NOW(), INTERVAL 1 MINUTE),?) `;
        await database.query(insertOtpQuery,[result[0].id,requireData.email,otp]);

         const url = "http://localhost/resetemailpassword.php?token=" + otp;
         const subject = "Cargo Rider - Reset Password";
         const message = `Click on the link to reset your password: ${url}`;
         let  email = requireData.email;
         common.sendMail(subject, email, message, function (error, res) {
            console.log(error);
          });         
            return callback({
                code: error_code.success,
                keyword: "reset password link sent to your email"
            })


        } catch (error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form",
            });
        }
    }
    async resetPassword(RequireData, callback) {
        try {
            let [verify] = await database.query("select * from tbl_user  where id=?", [RequireData.user_id]);
            if (verify[0].is_verify != 1) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "first verify your phone or email"
                });
            }
            let data = {
                id: RequireData.user_id,
                password: md5(RequireData.password)
            };

            let updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";

            let [result] = await database.query(updatePasswordQuery, [data.password, data.id]);

            if (result.length <= 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "password not changed"
                });
            }

            return callback({
                code: error_code.success,
                keyword: "password changed"
            });
        }
        catch (error) {
            console.error("Error in ResetPassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form"
            });
        }
    }
    async changePassword(RequireData, callback) {
        try {


            let oldPassword = md5(RequireData.old_password);
            let newPassword = md5(RequireData.new_password);

            let checkPasswordQuery = "SELECT * FROM tbl_user WHERE id=? and is_deleted=0 and is_active=1";

            let [result] = await database.query(checkPasswordQuery, [RequireData.user_id]);
            console.log(result[0]);

            if (!result.length) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "User not found"
                });
            }

            let dbPassword = result[0].password;

            // Check if old password matches
            if (dbPassword !== oldPassword) {
                return callback({
                    code: error_code.invalid_input,
                    keyword: "Old password does not match"
                });
            }


            if (newPassword === dbPassword) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Old password and new password cannot be the same"
                });
            }


            let updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";
            let [updateResult] = await database.query(updatePasswordQuery, [newPassword, RequireData.user_id]);

            if (updateResult.affectedRows <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "Password not changed"
                });
            }

            return callback({
                code: error_code.success,
                keyword: "Password changed successfully"
            });

        } catch (error) {
            console.error("Error in ChangePassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "Enter proper values in the form"
            });
        }
    }
    async addtocart(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                type: requireData.type,
                weight: requireData.weight,
                unit: requireData.unit,
                height: requireData.height,
                width: requireData.width,
                notes: requireData.notes,
                in: requireData.in
            }
            let [result] = await database.query("insert into tbl_add_to_cart set?", [data]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.invalid_input,
                    keyword: "items is not selected",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "items is selected",
                data: result
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "items is not selected",
                data: []
            })
        }

    }
    async placeOrder(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                receiver_address_id: requireData.receiverAddress_id,
                vehicle_category_id: requireData.vehicle_category_id
            };

            if (requireData.scheduledate) {
                data.order_date = requireData.scheduledate;
            }
            let mainresult = {};
            let [cart] = await database.query(
                `SELECT *
                     FROM tbl_add_to_cart 
                     WHERE user_id = ? `,
                [requireData.user_id]
            );
            if (cart.length === 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Cart is empty, order not placed",
                    data: []
                });
            }
            let distance = "";
            let pod_price = 0;
            console.log(requireData.pod_status);

            if (requireData.pod_status == 'true') {

                data.second_address_id = requireData.address_id;
                let [result] = await database.query(`SELECT ROUND( ( 6371 
                    * ACOS( COS( RADIANS((SELECT latitude FROM tbl_second_address WHERE user_id = ? LIMIT 1)) )
                    * COS( RADIANS( o.latitude ) ) * COS( RADIANS(o.longitude) - RADIANS((SELECT longitude FROM tbl_second_address WHERE user_id = ? LIMIT 1)) )
                    + SIN( RADIANS((SELECT latitude FROM tbl_second_address WHERE user_id = ? LIMIT 1)) ) 
                    * SIN( RADIANS( o.latitude ) ) ) ), 1) AS distance FROM tbl_order_reciver_address AS o WHERE o.id = ?;`, [data.user_id, data.user_id, data.user_id, data.receiver_address_id]);
                distance = result[0].distance;
                data.pod = 200;
                pod_price = 200;
            } else {
                let [address] = await database.query("select * from tbl_address where user_id=?", [data.user_id]);
                data.address_id = address[0].id;

                let [result] = await database.query(`SELECT ROUND( ( 6371 
                    * ACOS( COS( RADIANS((SELECT latitude FROM tbl_address WHERE user_id = ? LIMIT 1)) )
                    * COS( RADIANS( o.latitude ) ) * COS( RADIANS(o.longitude) - RADIANS((SELECT longitude FROM tbl_address WHERE user_id = ? LIMIT 1)) )
                    + SIN( RADIANS((SELECT latitude FROM tbl_address WHERE user_id = ? LIMIT 1)) ) 
                    * SIN( RADIANS( o.latitude ) ) ) ), 1) AS distance FROM tbl_order_reciver_address AS o WHERE o.id = ?;`, [data.user_id, data.user_id, data.user_id, data.receiver_address_id]);
                distance = result[0].distance;

            }
            let [price] = await database.query("select * from tbl_vehicle_category where id=?", [data.vehicle_category_id]);
            data.sub_total = price[0].price_per_km * distance;
            data.total_price = price[0].price_per_km * distance + pod_price;
            console.log("Price:", data.sub_total);
            console.log(distance);
            data.otp = common.GenerateOtp();

            // Insert order into tbl_order
            let [result] = await database.query("INSERT INTO tbl_order SET ?", [data]);
            mainresult.orders = result;

            if (result.length === 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Order is not placed",
                    data: []
                });
            }
            // Insert order details
            for (let element of cart) {

                await database.query(
                    `INSERT INTO tbl_order_items(order_id, type,weight,weight_in,height,width, qty,notes) 
                         VALUES (?, ?, ?, ?,?,?,?,?);`,
                    [result.insertId, element.type, element.weight, element.in, element.height, element.width, element.unit, element.notes]
                );
            }

            // Delete cart items after order placement
            await database.query(
                `DELETE a FROM tbl_add_to_cart AS a 
                     WHERE a.user_id = ? ;`,
                [requireData.user_id]
            );

            // Send order notification

            let drivernotification = {
                sender_id: 1,
                type: "new Order",
                role: "driver",
                message: "Your have a new order"
            };
            const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            const today = days[new Date().getDay()];
            console.log("Day:", today);

            let [drivers] = await database.query(`SELECT o.*, ROUND( ( 6371
                 * ACOS( COS( RADIANS((SELECT latitude FROM tbl_address WHERE user_id = ? LIMIT 1)) ) 
                 * COS( RADIANS( o.latitude ) ) 
                 * COS( RADIANS(o.longitude) - RADIANS((SELECT longitude FROM tbl_address WHERE user_id = ? LIMIT 1)) )
                 + SIN( RADIANS((SELECT latitude FROM tbl_address WHERE user_id = ? LIMIT 1)) ) 
                 * SIN( RADIANS( o.latitude ) ) ) ), 1) AS distance FROM tbl_driver AS o INNER JOIN tbl_vehicle_details as v on v.driver_id=o.id INNER JOIN tbl_driver_available AS da ON o.id = da.driver_id where o.is_approve='1'  AND v.vehicle_category_id = ? AND da.day = ? AND (CURRENT_TIME BETWEEN da.starting_time AND da.ending_time) HAVING distance<20`, [data.user_id, data.user_id, data.user_id, data.vehicle_category_id, today]);

          console.log(drivers[0]);
          
                 for (let i = 0; i < drivers.length; i++) {

                drivernotification.reciver_id = drivers[i].id
                await database.query("INSERT INTO tbl_notification SET ?", [drivernotification]);

            }

            return callback({
                code: error_code.success,
                keyword: "Order placed successfully",
                data: mainresult
            });

        } catch (error) {
            console.error("Error in placeOrder:", error);
            return callback({
                code: error_code.not_approve,
                keyword: "Order not placed",
                data: []
            });
        }
    }
    async displayAllcategory(requireData, callback) {
        try {
            let mainresut = {};
            mainresut.user_details = await common.getUserDetails(requireData.user_id);

            let [allcategory] = await database.query("select * from tbl_category where is_deleted=0");
            mainresut.allcategory = allcategory;

            if (mainresut.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "data is not found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresut
            })

        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "data not found",
                data: []
            })
        }
    }
    async displayallvehicle(requireData, callback) {
        try {
            let data = {
                latitude: requireData.latitude,
                longitude: requireData.longitude,
                address: requireData.address
            }
            let [distance] = await database.query(`select ROUND(( 6371 * ACOS( COS( RADIANS(d.latitude) )  
		* COS( RADIANS( ? ) ) 
		* COS( RADIANS(?) - RADIANS(d.longitude) )  
		+ SIN( RADIANS(d.latitude) )  
		* SIN( RADIANS( ? ) ) ) ),1) as distance from tbl_address as d where user_id=?`, [data.latitude, data.longitude, data.latitude, requireData.user_id]);
            console.log(distance[0].distance);

            let [result] = await database.query("select *,(price_per_km*?) as price from tbl_vehicle_category", [distance[0].distance]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })

        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "data not found ",
                data: []
            })
        }
    }
    async addreceiverDetails(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                full_name: requireData.fullname,
                country_id: requireData.country_id,
                phone: requireData.phone,
                email: requireData.email,
                address: requireData.address,
                latitude: requireData.latitude,
                longitude: requireData.longitude
            }
            let [result] = await database.query("insert into tbl_order_reciver_address set ?", [data]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "receiver address is not register",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "receiver address is not register",
                data: []
            })
        }

    }
    async displayOrdersDetails(requireData, callback) {
        try {
           
            let data = {
                order_id: requireData.order_id,
            }
            let result=await common.displayOrdersDetails(data.order_id);
            if(result.length<=0){
                return callback({
                    code:error_code.no_data_found,
                    keyword:"no data found",
                    data:[]
                })
            }
            return callback({
                code:error_code.success,
                    keyword:" data found",
                    data:result
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "no data found",
                data: []
            })
        }

    }
    async giveRating(requireData, callback) {
        try {
            let data = {
                order_id: requireData.order_id,
                rating: requireData.rating,
                review: requireData.review,
                user_id: requireData.user_id
            }
            let [driver_id] = await database.query("select * from tbl_order where id=?", [data.order_id]);
            data.driver_id = driver_id[0].driver_id;
            let [result] = await database.query("insert into tbl_ratig set ?", [data]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "rating is not register",
                    data: []
                })
            }
            await database.query("update tbl_driver as d set avg_rate=(select avg(rating) from tbl_ratig where driver_id=d.id) where id=?", [driver_id[0].driver_id])
            return callback({
                code: error_code.success,
                keyword: "SUccess",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "rating is not register",
                data: []
            })
        }
    }
    async report(requireData, callback) {
        try {
            let data = {

                subject: requireData.subject,
                description: requireData.description,
                user_id: requireData.user_id,
                driver_id: requireData.driver_id
            }
            let images = requireData.images.split(',');
            let [result] = await database.query("insert into tbl_user_report set ?", [data]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "rating is not register",
                    data: []
                })
            }
            for (let i = 0; i < images.length; i++) {
                let imagedata = {
                    report_id: result.insertId,
                    image_name: images[i]
                }
                await database.query("insert into tbl_user_report_image set ?", [imagedata]);
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "rating is not register",
                data: []
            })
        }
    }
    async displayProfile(requireData,callback){
        try{
            let result=await common.displayProfile(requireData.user_id,'user');
            console.log(result);
            
            if(result.length<=0){
                return callback({
                    code:error_code.no_data_found,
                    keyword:"no data found",
                    data:[]
                })
            }
            return callback({
                code:error_code.success,
                keyword:" data found",
                data:result
            })
        }catch(Error){
            return callback({
                code:error_code.no_data_found,
                keyword:"no data found",
                data:[]
            })
        }
    }
    async EditProfile(requireData,callback){
        let data = {
            full_name: requireData.fullname,
            country_id: requireData.country_id,
            phone: requireData.phone,
            user_image: requireData.user_image,
            email: requireData.email,
        }
        let[result]=await database.query("update tbl_user set? where id=?",[data,requireData.user_id]);
        if(result.length<=0){
            return callback({
                code:error_code.not_register,
                keyword:"data is not update",
                data:[]
            })
        }
        return callback({
            code:error_code.success,
            keyword:"data is update",
            data:result
        })
    }
    async displayOrdes(requireData,callback){
        try{
        let type=requireData.type;
        let details="SELECT r.full_name,r.email,r.phone, concat(day(o.order_date),-MONTH(o.order_date),-YEAR(o.order_date)) as date,time(o.order_date)as time,(select sum(qty) from tbl_order_items where order_id=o.id and type='document')as document,(select sum(qty) from tbl_order_items where order_id=o.id and type='package')as package from tbl_order as o INNER JOIN tbl_order_reciver_address as r on r.id=o.receiver_address_id WHERE  o.user_id=?";
        if(type=='running'){
            details=details+' and date(order_date)=CURRENT_DATE'
        }else if(type=='upcoming'){
            details=details+' and date(o.order_date)>CURRENT_DATE'
        }else if(type=='history'){
            details=details+' and o.order_date<CURRENT_DATE'
        }
        let[result]=await database.query(details,[requireData.user_id]);
        if(result.length<=0){
            return callback({
                code:error_code.no_data_found,
                keyword:"no data found",
                data:[]
            })
        }
        return callback({
            code:error_code.success,
            keyword:" data found",
            data:result
        })
    }catch(Error){
        console.log(Error);
        
        return callback({
            code:error_code.no_data_found,
            keyword:"no data found",
            data:[]
        })
    }
    }
    async displayNotification(requireData,callback){
        let result=await common.displayNotification(requireData.user_id,'user');
        if(result.length<=0){
            return callback({
                code:error_code.no_data_found,
                keyword:"no data found",
                data:[]
            })
        }
        return callback({
            code:error_code.success,
            keyword:" data found",
            data:result
        })
    }
    async clearNotification(requireData,callback){
        let result=await common.clearNotification(requireData.user_id,'user');
        if(result.length<=0){
            return callback({
                code:error_code.no_data_found,
                keyword:"no data found",
                data:[]
            })
        }
        return callback({
            code:error_code.success,
            keyword:" data found",
            data:result
        })
    }
    async cancelOrder(requireData,callback){
        try{
            let data={
                order_id:requireData.order_id,
                reason:requireData.reason
            }
            let[result]=await database.query("update tbl_order set status='cancel',reason=? , is_deleted=1 where id=?",[data.reason,data.order_id]);
            if(result.length<=0){
                return callback({
                    code:error_code.not_approve,
                    keyword:"order is not deleted",
                    data:[]
                })
            }
            return callback({
                code:error_code.success,
                keyword:"order is  deleted",
                data:result
            })

        }catch(Error){
            return callback({
                code:error_code.not_approve,
                keyword:"order is not deleted",
                data:[]
            })
        }
    }
    async contactUs(requireData,callback){
        let data={
            title:requireData.title,
            subject:requireData.subject,
            description:requireData.description,
            user_id:requireData.user_id
        }
        let[result]=await database.query("insert into tbl_user_countac_us set?",data);
        if(result.length<=0){
            return callback({
                code:error_code.not_register,
                keyword:"report in not register",
                data:[]
            })
        }
        let [user_details]=await database.query("select * from tbl_user where id=?",[data.user_id]);
        
        let message={
            full_name:user_details[0].full_name,
            message:data.description
        }
        console.log(user_details[0].email);
        console.log(message);
        
       // common.sendMail("report", email, template.otp(data), function (error, res) { });
        common.sendMail("report",user_details[0].email,template.contactUs(message),function (error, res) { });
        return callback({
            code:error_code.success,
            keyword:"Success",
            data:result
        })
    }

}
module.exports = new userModule();