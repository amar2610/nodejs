let user=require("../controller/user");
let CustomeRoute=(app)=>{
    app.post("/v1/user/signup/:type?",user.singUp);
    app.post("/v1/user/login/:type?",user.logIn);
    app.post("/v1/user/logout",user.logOut);
    app.post("/v1/user/otpverification",user.otpVerify);
    app.post("/v1/user/addsecondaddress",user.addSecondLocation);
    app.post("/v1/user/forgotpassword",user.forgotPassword);
    app.post("/v1/user/resetpassword",user.resetPassword);
    app.post("/v1/user/changepassword",user.changePassword);
    app.post("/v1/user/addtocart",user.addToCart);
    app.post("/v1/user/placeorder",user.placeOrder);
    app.post("/v1/user/displayallcategory",user.displayAllCategory);
    app.post("/v1/user/displayallvehicle",user.displayallvehicle);
    app.post("/v1/user/displayorderdetails",user.displayOrderdetails);
    app.post("/v1/user/addreceiveraddress",user.addreceiverDetails);
    app.post("/v1/user/addrating",user.giveRating);
    app.post("/v1/user/report",user.report);
    app.post("/v1/user/editprofile",user.editProfile);
    app.post("/v1/user/resentotp",user.reSentOtp);
    app.post("/v1/user/displayprofile",user.displayProfile);
    app.post("/v1/user/orders",user.displayOrders);
    app.post("/v1/user/displaynotification",user.displayNotification);
    app.post("/v1/user/clearnotification",user.clearNotification);
    app.post("/v1/user/cancelorder",user.cancelOrder);
    app.post("/v1/user/contactus",user.contactUs);



    





 








    













}
module.exports=CustomeRoute;