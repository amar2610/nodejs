class routing{
    v1(app){
        let user=require("../v1/user/routes/routes");
        let driver=require("../v1/driver/routes/routes");
        user(app);
        driver(app);
    }
}
module.exports=new routing();