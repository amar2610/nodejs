const constant={
    itemPerPage:3,
    imgUrl:"https://www.image.com/meal/",
    is_production:true,
    server_listner:3035,
    version:"1.0.0",
    api_key:"cargoride",
    encryptionKey:encryptlib.getHashSha256("xza548sa3vcr641b5ng5nhy9mlo64r6k",32),
    encryptionIV:"5ng5nhy9mlo64r6k"

}
module.exports = constant;