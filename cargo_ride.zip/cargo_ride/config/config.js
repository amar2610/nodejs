let encryptlib=require("cryptlib");
let env={
    itemPerPage:3,
    imgUrl:"https://www.image.com/meal/",
    is_production:true,
    server_listner:3035,
    version:"1.0.0",
    api_key:"cargoride",
    encryptionKey:encryptlib.getHashSha256("xza548sa3vcr641b5ng5nhy9mlo64r6k",32),
    encryptionIV:"5ng5nhy9mlo64r6k",

    app_url: "http://localhost:3000/",
    mailer_email:"amarratho0@gmail.com",
    mailer_password:"lamx pcjw yczq fmqo",
    from_email: "amarratho0@gmail.com",
    itemPerPage: 12,
    language: "",
    host_mail: "",
    port_base_url: "http://localhost:3000/",
};
 module.exports=env;