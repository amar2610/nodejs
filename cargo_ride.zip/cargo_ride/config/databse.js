let mysql=require("mysql2/promise");
let credential={};
credential={
    host:"localhost",
    user:"root",
    password:"",
    database:"db_cargo_ride",
    dateString:"date",
    port:3304
}
try{
let database=mysql.createPool(credential);
if(database){
    console.log("database is connected");
    module.exports=database;
}
}catch(Error){
    console.log("data base is not connected ",Error);
    
}