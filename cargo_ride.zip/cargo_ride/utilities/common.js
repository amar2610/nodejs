const database = require("../config/databse");
const DataBase = require("../config/databse");
const process = require('../config/config');
let cryptlip = require("cryptlib");
let Math = require("math");
let nodemailer = require("nodemailer");
const message = require("../language/en");
class common {
    Response(res, message) {
        res.json(message);
    }
    //to generate otp
    GenerateOtp() {
        return Math.floor(1000 + Math.random() * 9000);
    }
    //to generate login token
    generatetocken(length) {
        let posible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        let text = "";
        for (let i = 0; i < length; i++) {
            text += posible.charAt(Math.floor(Math.random() * posible.length));
        }
        return text;
    }
    encryptPlain(data) {
        return cryptlip.encrypt(JSON.stringify(data), process.encryptionKey, process.encryptionIV)
    }
    decryptPlain(data) {
        return cryptlip.decrypt(data, process.encryptionKey, process.encryptionIV)
    }
    SetToken(user_id,role) {
        let tokan = this.generatetocken(40);
        let updatetokan = "update tbl_device set token=? where user_id=? and role=?";

        DataBase.query(updatetokan, [tokan, user_id,role], (error, result) => {
            if (error) {
                console.log("operation faild", error);
            }
            if (result <= 0) {
                console.log("token in not generated");
            }
            console.log("token generated");

        })
    }
    async getStepCount(user_id) {
        let [result] = await database.query("select * from tbl_user where id=?", [user_id]);
        if (result.length <= 0) {
            return 0;
        }
        return result[0].step_count;
    }
    async getUserDetails(user_id) {
        let [result] = await database.query("select * from tbl_user where id=?", [user_id]);
        if (result.length <= 0) {
            return [];
        }
        return result;
    }
    async getDistanceFromSenderToReciver(s_latitude,s_longitude,reciver_id) {

        let [distance] = await database.query(`select ROUND(( 6371 * ACOS( COS( RADIANS(?) )  
		* COS( RADIANS( r.latitude ) ) 
		* COS( RADIANS(r.longitude) - RADIANS(?) )  
		+ SIN( RADIANS(?) )  
		* SIN( RADIANS( r.latitude ) ) ) ),1) as distance from  tbl_order_reciver_address as r where r.id=?`, [s_latitude,s_longitude,s_latitude,reciver_id]);
        if (distance.length <= 0) {
            return 0;
        }
        return distance[0].distance;
    }
     generateOrderId() {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let orderId = 'ORD-';
        
        for (let i = 0; i < 8; i++) {
            orderId += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        
        return orderId;
    }
    sendMail(subject, to_email, message, callback) {
        var transporter = nodemailer.createTransport({
            service:"gmail",
            host: 'smtp.office365.com',
            port: 587,
            secure: false, // true for 465, false for other ports                     
            auth: {
                user: process.mailer_email, // generated ethereal user               
                pass: process.mailer_password // generated ethereal password           
            }
        }); // setup email data with unicode symbols        
        var mailOptions = {
            from: process.from_email, // sender address     
            to: to_email, // list of receivers      
            subject: subject, // Subject line   
            html: message
        };
        // send mail with defined transport object     
        transporter.sendMail(mailOptions, (error, info) => {

            if (error) {
                //     console.log("ERROR FOUND :::::::: ++++++++++++++ ")
                console.log(error); //callback(true); 
                callback("", info);
                //callback(error, []);
            } else {
                callback("", info);
            }

        });
    }
   async displayProfile(id,role){
        if(role=='user'){
        let[result]=await database.query("select * from tbl_user where id=? and is_deleted=0",[id]);
        console.log(result[0]);
        
        return result[0];
        }else{
            let[result]=await database.query("select * from tbl_driver where id=? and is_deleted=0",[id]);
        return result[0];
        }

    }
    async displayOrdersDetails(order_id) {
        try {
            let mainresult = {};
           
            let [pod]=await database.query("select case when(o.address_id=0) then 'true' ELSE 'false' end as status from tbl_order as o where o.id=? ",[order_id])
            let time_per_km = 4;
            let details = "";
            if (pod.status == 'true') {
                details = `select ROUND(( 6371 * ACOS( COS( RADIANS(a.latitude) ) 
                * COS( RADIANS( r.latitude ) ) * COS( RADIANS(r.longitude) 
                - RADIANS(a.longitude) ) + SIN( RADIANS(a.latitude) ) 
                * SIN( RADIANS( r.latitude ) ) ) ),1) as distance ,r.*,o.*,d.driver_image,o.status,d.full_name as driver_name,d.phone as driver_phone,d.avg_rate,a.address as sender_address,a.latitude as sender_latitude,a.longitude as sender_longitude from tbl_order as o  left join tbl_driver as d on o.driver_id=d.id inner join tbl_order_reciver_address as r on r.id=o.receiver_address_id INNER JOIN tbl_second_address as a on a.user_id=o.user_id WHERE o.id=? `
            } else {
                details = `select ROUND(( 6371 * ACOS( COS( RADIANS(a.latitude) ) 
                * COS( RADIANS( r.latitude ) ) * COS( RADIANS(r.longitude) 
                - RADIANS(a.longitude) ) + SIN( RADIANS(a.latitude) ) 
                * SIN( RADIANS( r.latitude ) ) ) ),1) as distance ,r.*,o.*,d.driver_image,o.status,d.full_name as driver_name,d.phone as driver_phone,d.avg_rate,a.address as sender_address,a.latitude as sender_latitude,a.longitude as sender_longitude from tbl_order as o  left join tbl_driver as d on o.driver_id=d.id inner join tbl_order_reciver_address as r on r.id=o.receiver_address_id INNER JOIN tbl_address as a on a.user_id=o.user_id WHERE o.id=?`
            }
            let [result] = await database.query(details,[order_id]);
            console.log(result[0]);

            let [item_details] = await database.query("select sum(oi.qty) as count,oi.notes,oi.type from tbl_order as o inner join tbl_order_items as oi on oi.order_id=o.id where o.id=?   GROUP BY type ", [order_id]);
            let location = {
                sender_Address: result[0].sender_address,
                receiverAddress: result[0].address
            }
            let receiver_details = {
                reciver_name: result[0].full_name,
                receiver_email: result[0].email,
                reciver_phone: result[0].phone
            }
            let distanceandtime = {
                distance: result[0].distance + "km",
                time: (result[0].distance * time_per_km) + "min"
            }
            let driver_details = {
                driver_name: result[0].driver_name,
                driver_image: result[0].driver_image,
                driver_phone: result[0].driver_phone,
                driver_rating: result[0].avg_rate,
             
            }
            let order_Summary={
                date:result[0].order_date,
                sub_total:result[0].sub_total,
                pod_charge:result[0].pod,
                total:result[0].total_price
            }
            mainresult.location_Details = location;
            mainresult.reciver_Details = receiver_details;
            mainresult.item_details = item_details;
            mainresult.distance_time = distanceandtime;
            mainresult.driver_details = driver_details;
            mainresult.status=result[0].status;
            if(result[0].status=='complete'){
                mainresult.order_Summary=order_Summary;
            }
            if (mainresult.length <= 0) {
                return 0
              
            }
            return mainresult
            
        } catch (Error) {
            console.log(Error);
            return 0
                
           
        }

    }
    async displayNotification(id,role){
        let[result]=await database.query("select * from tbl_notification where reciver_id=? and role=? and is_deleted=0",[id,role]);
        if(result.length<=0){
            return 0
        }
        return result
    }
    async clearNotification(id,role){
        let[result]=await database.query("update tbl_notification  set is_deleted=1 where reciver_id=? and role=? and is_deleted=0",[id,role]);
        if(result.length<=0){
            return 0
        }
        return result
    }
    async cancelOrder(){
        let[user]=await database.query("select * from tbl_order where (order_date + INTERVAL 15 MINUTE) < NOW() and status='pending' and is_deleted=0 ");
        let[result]=await database.query("UPDATE tbl_order SET is_deleted = 1, status = 'cancel', reason = 'no one can accept this order' WHERE (order_date + INTERVAL 15 MINUTE) < NOW()  AND status = 'pending'");
       
        if(result.affectedRows>=0){
            for(let i=0;i<user.length;i++){
                let data={
                    reciver_id:user[i].user_id,
                    role:"user",
                    type:"order cancel",
                    message:"your order is cancel"
                }
                console.log("hello");
                
                await database.query("insert into tbl_notification set ?",data);
            }
        }
    }
    
}
module.exports = new common();