const { forgotPassword } = require("../modules/v1/user/module/user_module")

const checkValidationRules = {
    login: {
      password:"required",
      deviceType:"required"
    },
   
    addmeal:{
        meal_name: "required",
        image: "required",
        kcal: "required",
        carbs: "required",
        protein:"required",
        fat: "required",
        description: "required",
        ingredients: "required",
        catagory_id: "required",
        day: "required",
    },
    allvehicles:{
        latitude:"required",
        longitude:"required",
        address:"required"
    },
    signUp: {
        fullname:"required",
        email: "required|email",
        user_image:"required",
        phone: "required|digits:10",
        password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"],
        latitude:"required",
        longitude:"required",
        address:"required",

    },
    receiverAddress: {
        fullname:"required",
        email: "required|email",
        phone: "required|digits:10",
        latitude:"required",
        longitude:"required",
        address:"required",

    },
   forgotPassword:{
    email:"required"
   },
   socialLogin:{
    social_id:"required"
   },
   
    setlocation:{
       
    },
    verifyOtp: {
        id:"required",
        otp: "required"
    },
    resetPassword: {
        user_id:"required",
        password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]

    },
    changePassword: {

        old_password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"],
        new_password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]

    },
    
    EditProfile: {
        first_name: "required",
        last_name: "required",
        dob: "required",
        phone: "required",
        gender: "required",
        address: "required",
        image: "required",
        dob: [
            "required",
            "regex:/^(19[0-9]{2}|20[0-2][0-9])-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/"
        ]
    },
    addtocart:{
        type:"required",
        weight:"required",
        unit:"required",
        height:"required",
        width:"required",
        notes:"required"
    },
    review:{
        product_id:"required",
        review:"required"
    },
    like:{
        product_id:"required"    },
    rating:{
        product_id:"required",
        rating:"required"
    },
  
}
module.exports = checkValidationRules
