const Validator = require('Validator');
const process = require('../config/config');
let common = require("../utilities/common");
const { default: localizify } = require('localizify');
let en = require('../language/en');
let ar = require('../language/ar');
let gj = require('../language/gj');
const { t } = require('localizify');
const dataBase = require('../config/databse');
const { response } = require('express');
let byPassMethod = new Array("signup", "login", "otpverification", "forgotpassword", "resetpassword","resentotp");
var middleware = {

    checkValidationRules: function (req, res, request, rules, message, keywords) {

        const v = Validator.make(request, rules, message, keywords);
        if (v.fails()) {
            const errors = v.getErrors();
            console.log(errors);

            var error = "";
            for (var key in errors) {
                error = errors[key][0];
                break;
            }
            response_data = {
                code: "0",
                message: error,
            }

            res.status(200);
           // res.send(response_data);

            res.send(common.encryptPlain(response_data));

            return false;

        } else {
            return true;
        }

    },
    send_response: function (req, res, _respons) {
        //console.log(req.language);

        this.getMessage(req.language, _respons, function (translated_message) {
            // console.log(translated_message);

            if (_respons.data == null) {
                response_data = {
                    code: _respons.code,
                    message: translated_message,
                    data: _respons.data
                }


                res.status(200);
              //  res.send(response_data);
               res.send(common.encryptPlain(response_data));

            } else {
                response_data = {
                    code: _respons.code,
                    message: translated_message,
                    data: _respons.data
                }

                res.status(200);
                //res.send(response_data);
                 res.send(common.encryptPlain(response_data));

            }
        })
    },
    getMessage: function (language, message, callback) {

        localizify
            .add('en', en)
            .add('ar', ar)
            .add('gj', gj)
            .setLocale(language);

        let translatedMessage = t(message.keyword);

        if (message.content) {
            Object.keys(message.content).forEach(key => {
                translatedMessage = translatedMessage.replace(`{ ${key} }`, message.content[key]);
            });
        }

        callback(translatedMessage);
        //        callback(t(message.keyword,message.content));    

    },
    validatorApikey(req, res, callback) {
        try {
            //let apiKey = (req.headers['api-key']);

           let apiKey = common.decryptPlain(req.headers['api-key']);
            
            if (apiKey != "") {
                try {

                    if (apiKey == process.api_key) {
                        callback();
                    }
                    else {
                        res.status(401);
                        //res.send("invalid api key");
                        res.send(common.encryptPlain("invalid api key"));
                    }
                } catch (error) {
                    console.log("error in apikey", error);

                    res.status(400);
                    //res.send("invalid api key");
                    res.send(common.encryptPlain("invalid api key"));
                }
            } else {
                res.status(401);
                //res.send("invalid api key");
                res.send(common.encryptPlain("invalid api key"));
            }
        } catch (Error) {
            console.log(Error);

            res.status(401);
           // res.send("invalid api key");
            res.send(common.encryptPlain("invalid api key"));

        }

    },
    async validatorHeaderToken(req, res, callback) {
        try {
            let pathData = req.path.split('/');
            if (byPassMethod.indexOf(pathData[3]) === -1) {
               // let headerToken = (req.headers['token']);

               let headerToken = common.decryptPlain(req.headers['token']);
                if (headerToken != "") {
                    try {
                        let [result] = await dataBase.query("select * from tbl_device where token=?", headerToken);

                        if (result.length < 0) {
                            res.status(401);
                           // res.send("invalid token provide");
                            res.send(common.encryptPlain("invalid token provide"));
                        }
                        let tokan = result[0].user_id;
                        if(pathData[2]=='driver'){
                            req.driver_id = tokan;

                        }else{
                            req.user_id = tokan;
                        }

                        callback();
                    } catch (error) {
                        res.status(401);
                        //res.send("invalid token provide");

                       res.send(common.encryptPlain("invalid token provide"));
                    }
                } else {
                    res.status(401);
                   // res.send("invalid token provide");

                    res.send(common.encryptPlain("invalid token provide"));
                }
            } else {
                callback();
            }
        
       
        } catch (Error) {
            res.status(401);
            //res.send("invalid token provide");

           res.send(common.encryptPlain("invalid token provide"));
        }

    },

    extractHeaderLanguage: function (req, res, callback) {
        var headerlang = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "")
            ? req.headers['accept-language'] : 'en';

        req.lang = headerlang;

        req.language = (headerlang == 'en') ? en : (headerlang == 'ar') ? ar : gj;

        localizify
            .add('en', en)
            .add('ar', ar)
            .add('gj', gj)
            .setLocale(req.lang);

        callback();
    },
};
module.exports = middleware;