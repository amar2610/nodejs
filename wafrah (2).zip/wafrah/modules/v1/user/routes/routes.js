let user=require("../controller/user");
let CustomeRoute=(app)=>{
    app.post("/v1/user/signup/:type?",user.singUp);
    app.post("/v1/user/login/:type?",user.logIn);
    app.post("/v1/user/logout",user.logOut);
    app.post("/v1/user/setlocation",user.setlocation);
    app.post("/v1/user/addtocart",user.addToCart);
    app.post("/v1/user/placeorder",user.placeOrder);
    app.post("/v1/user/displayallproduct",user.displayAllProduct);
    app.post("/v1/user/displayproductdetails",user.displayProductDetails);
    app.post("/v1/user/displayorders",user.displayOrders);
    app.post("/v1/user/addreview",user.addreview);
    app.post("/v1/user/addrating",user.addrating);
    app.post("/v1/user/likeproduct",user.likeProduct);
    app.post("/v1/user/filter",user.filter);
    app.post("/v1/user/displayorderdetails",user.displayOrderDetails);
    app.post("/v1/user/displayorders",user.displayOrders);
    app.post("/v1/user/displaystore",user.displayStore);
    app.post("/v1/user/displaystoredetails",user.displayStoreDetails);
    app.post("/v1/user/addcarddetails",user.addcardDetails);
    app.post("/v1/user/search",user.search);
    app.post("/v1/user/cancelorder",user.cancelOrder);
    app.post("/v1/user/displaynotification",user.displayNotification);
    app.post("/v1/user/sortby",user.sortby);
    app.post("/v1/user/updatestatus",user.updateOrderStatus);










 








    













}
module.exports=CustomeRoute;