let userModule = require("../module/user_module");
const middleware = require("../../../../middelware/validation");
let validation_rules = require("../../../../middelware/validation_rules");
const common = require("../../../../utilities/common");
class user {
    singUp(req, res) {

        let data = req.body;
        let type=req.params.type;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules=validation_rules.signUp;
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.signUp(data,type, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    logIn(req, res) {
            let data = req.body;
            console.log(data);
            
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        } let type=req.params.type;

         let rules="";
            if(type==undefined){
             rules = validation_rules.login;
            }else{
                rules=validation_rules.socialLogin
            }
            let message = {
                reauired: req.reauired
            }

            let keyword = {};
            if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
                userModule.logIn(data,type, function (_respons) {
                    middleware.send_response(req, res, _respons);
                })
            }
       
    }
    logOut(req, res) {
        let data = req.body;
        
    if (Object.keys(data).length != 0) {
        data = JSON.parse(common.decryptPlain(req.body));
    } 

     let rules="";
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.logOut(data,type, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
   
}
    async setlocation(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        data.user_id = req.user_id;
        let rules = validation_rules.setlocation;
        let step_count = await common.getStepCount(req.user_id);
        data.step_count = step_count;
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.setLocation(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
     addreview(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        data.user_id = req.user_id;
        let rules = validation_rules.review;
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.addreview(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    addrating(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        data.user_id = req.user_id;
        let rules = validation_rules.rating;
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.addrating(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    likeProduct(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        data.user_id = req.user_id;
        let rules =validation_rules.like;
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.likeproduct(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    addToCart(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules =validation_rules.addtocart;
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.addtocart(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    placeOrder(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.placeOrder(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayAllProduct(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayAllProduct(data,  function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayProductDetails(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = validation_rules.productDetail;
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayProductDetails(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayOrders(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayOrders(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    filter(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.filter(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    search(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.search(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayOrderDetails(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayOrdersDetails(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    addcardDetails(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.addcarddetails(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayOrders(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayOrders(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayStore(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayStore(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayStoreDetails(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displaystoreDetails(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    cancelOrder(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.cancelOrder(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayNotification(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayNotification(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    sortby(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.sortby(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    updateOrderStatus(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.updateOrderStatus(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
}

module.exports = new user();