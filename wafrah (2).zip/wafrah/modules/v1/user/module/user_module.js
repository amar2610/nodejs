let md5 = require("md5");
let Commen = require("../../../../utilities/common");
const database = require("../../../../config/databse");
let error_code = require("../../../../utilities/error_response");
const common = require("../../../../utilities/common");
class userModule {
    async signUp(requireData, type, callback) {
        try {
            let id = "";
            let mainresult = {}

            let deviceDetails = {
                device_token: common.generatetocken(10),
                os_version: requireData.os_version,
                app_version: requireData.app_version,
                device_type: requireData.device_type
            }
            if (!type || type == undefined) {
                let data = {
                    name: requireData.name,
                    profile_image: requireData.profile_image,
                    country_code_id: requireData.country_code_id,
                    phone: requireData.phone,
                    email: requireData.email,
                    password: md5(requireData.password)
                }
                let [check] = await database.query("select * from tbl_user where phone=? and email=? and is_deleted='0'", [data.phone, data.email]);
                if (check.length > 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "email and phone is alredy used",
                        data: []
                    })
                }



                let insert = "insert into tbl_user set ?";
                let [result] = await database.query(insert, data);
                if (result.length < 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "user is not register",
                        data: []
                    })
                }
                deviceDetails.user_id = result.insertId;
                id = result.insertId;
                mainresult.user_details = result;
            }
            else {
                let data = {
                    login_type: type,
                    social_id: common.generatetocken(10),
                    name: requireData.name,
                    country_code_id: requireData.country_code_id,
                    phone: requireData.phone,
                    email: requireData.email,
                }
                let [check] = await database.query("select * from tbl_user where phone=? and email=? and is_deleted='0'", [data.phone, data.email]);
                if (check.length > 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "email and phone is alredy used",
                        data: []
                    })
                }
                let insert = "insert into tbl_user set ?";
                let [result] = await database.query(insert, data);
                if (result.length < 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "user is not register",
                        data: []
                    })
                }
                id = result.insertId;

                mainresult.user_details = result;
                deviceDetails.user_id = result.insertId;

            }
            let address_details = {
                address: requireData.address,
                latitude: requireData.latitude,
                longitude: requireData.longitude,
                country: requireData.country,
                state: requireData.state,
                city: requireData.city,
                postal_code: requireData.postal_code,
                user_id: id
            }
            await database.query("insert into tbl_address set ?", address_details);
            await database.query("insert into tbl_device set ?", deviceDetails);
            return callback({
                code: error_code.success,
                keyword: "user is register",
                data: mainresult
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "user is not register",
                data: []
            })
        }
    }
    async logIn(requireData, type, callback) {
        let id = 0;
        let deviceDetails = {
            device_type: requireData.deviceType
        }
        if (type == undefined) {
            let data = {
                password: md5(requireData.password),
            }
            let check = "select * from tbl_user where (phone=? or email=?) and password=? and is_deleted=0 and is_active=1";
            let [result] = await database.query(check, [requireData.phone, requireData.email, data.password]);
            console.log(result[0]);
            if (result.length <= 0) {
                console.log("data not found");
                return callback({
                    code: error_code.no_data_found,
                    keyword: "user not found",
                    data: []
                })
            }
            id = result[0].id;

        } else {
            let check = "select * from tbl_user where login_type=? and social_id=? and is_deleted=0 and is_active=1";
            let [result] = await database.query(check, [type, requireData.social_id]);

            if (result.length <= 0) {
                console.log("data not found");
                return callback({
                    code: error_code.no_data_found,
                    keyword: "user not found",
                    data: []
                })
            }
            id = result[0].id;
        }
        await database.query("update tbl_device set ? where user_id=?", [deviceDetails, id])
        common.SetToken(id);
        return callback({

            code: error_code.success,
            keyword: "login_success",
        })


    }
    async logOut(requireData, callback) {
        try {
            let [result] = await database.query("update tbl_device set token='',device_type='', where user_id=?", [requireData.user_id]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "not logout"
                })
            }
            return callback({
                code: error_code.success,
                keyword: "logout successfuly"
            })
        } catch (Error) {
            return callback({
                code: error_code.not_approve,
                keyword: "not logout"
            })
        }
    }
    async setLocation(requireData, callback) {
        if (requireData.step_count == 2) {
            let data = {
                address: requireData.address,
                latitude: requireData.latitude,
                longitude: requireData.longitude,
                country: requireData.country,
                state: requireData.state,
                city: requireData.city,
                postal_code: requireData.postal_code,
                user_id: id

            }
            let [result] = await database.query("insert into tbl_address set ? ", [data]);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "location is not insert  yet",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "location is set",
                data: result
            })
        }
        return callback({
            code: error_code.success,
            keyword: "Profile is completed",

        })
    }
    async addtocart(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                product_id: requireData.product_id,
                qty: requireData.qty,
                size_id: requireData.size_id,
                comment: requireData.comment
            }

            let [item] = await database.query("select * from tbl_add_to_cart where product_id=?  and user_id=?", [data.product_id, data.user_id]);
            if (item.length <= 0) {
                let [result] = await database.query("insert into tbl_add_to_cart set?", [data]);
                if (result.length <= 0) {
                    return callback({
                        code: error_code.invalid_input,
                        keyword: "items is not selected",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "items is selected",
                    data: result
                })
            } else {
                data.qty = requireData.qty + item[0].qty;
                let [result] = await database.query("update tbl_add_to_cart set? where user_id=?", [data, data.user_id]);
                if (result.length <= 0) {
                    return callback({
                        code: error_code.invalid_input,
                        keyword: "items is not selected",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "items is selected",
                    data: result
                })
            }


        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "items is not selected",
                data: []
            })
        }

    }
    async placeOrder(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                card_id: requireData.card_id,
                address_id: requireData.address_id
            };
            if (requireData.type) {
                data.payment_type = requireData.type
            }
            if (requireData.card_id) {
                data.card_id = requireData.card_id
            }
            let mainresult = {};
            let [cart] = await database.query(
                `SELECT  product_id, qty,size_id,type,comment
                     FROM tbl_add_to_cart 
                     WHERE user_id = ? `,
                [requireData.user_id]
            );
            if (cart.length === 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Cart is empty, order not placed",
                    data: []
                });
            }
            // Calculate total price
            let [price] = await database.query(
                `SELECT SUM(m.price * a.qty) AS total 
                     FROM tbl_product AS m 
                     INNER JOIN tbl_add_to_cart AS a ON m.id = a.product_id
                     WHERE a.user_id = ? `,
                [data.user_id]
            );
            // fetch delivery charge price
            let [delivery_charge] = await database.query("select * from tbl_settings where type='delivery_charege'");
            data.delivery_charge = delivery_charge[0].price;

            //fetch tax price
            let [tax] = await database.query("select * from tbl_settings where type='tax'");
            data.tax = tax[0].price;
            //if discount id is available
            if (requireData.discount_id) {
                data.discount_id = requireData.discount_id;

                let discountPrice = 0;
                //fetch price of discount
                let [discount_price] = await database.query("select * from tbl_coupon_code where id=? and expired_date >CURRENT_TIMESTAMP", [requireData.discount_id]);

                if (discount_price.length <= 0) {
                    discountPrice = 0;
                } else {
                    discountPrice = discount_price[0].price;
                }
                data.total_price = parseInt(price[0].total) - discountPrice + delivery_charge[0].price + tax[0].price;
            } else {
                data.total_price = parseInt(price[0].total) + delivery_charge[0].price + tax[0].price;
            }
            let order_id = common.generatetocken(7);
            data.order_id = order_id;
            // Insert order into tbl_order
            let [result] = await database.query("INSERT INTO tbl_order SET ?", [data]);
            mainresult.orders = result;

            if (result.length === 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Order is not placed",
                    data: []
                });
            }

            let sub_totals = 0;
            let qty = 0;

            // Insert order details
            for (let element of cart) {
                let [productData] = await database.query(
                    "SELECT * FROM tbl_product WHERE id = ?",
                    [element.product_id]
                );

                let itemPrice = productData[0].price * element.qty;
                sub_totals += itemPrice;
                qty += element.qty;

                await database.query(
                    `INSERT INTO tbl_order_item (order_id, product_id, size_id,type,comment,qty, price) 
                         VALUES (?, ?, ?, ?,?,?,?);`,
                    [order_id, element.product_id, element.size_id, element.type, element.comment, element.qty, itemPrice]
                );
            }

            console.log("Sub Total:", sub_totals);

            // Update order summary
            let updateOrder = {
                sub_total: sub_totals,
                total_qty: qty,
                order_status: "order placed",
                payment_status: "complete"
            };

            await database.query(
                "UPDATE tbl_order SET ? WHERE id = ?",
                [updateOrder, result.insertId]
            );
            // Delete cart items after order placement
            await database.query(
                `DELETE a FROM tbl_add_to_cart AS a 
                     INNER JOIN tbl_product AS m ON m.id = a.product_id 
                     WHERE a.user_id = ? ;`,
                [requireData.user_id]
            );

            // Send order notification
            let notification = {
                sender_id: 1,
                reciver_id: requireData.user_id,
                type: "place Order",
                message: "Your order has been placed successfully"
            };

            await database.query("INSERT INTO tbl_notification SET ?", [notification]);

            return callback({
                code: error_code.success,
                keyword: "Order placed successfully",
                data: mainresult
            });

        } catch (error) {
            console.error("Error in placeOrder:", error);
            return callback({
                code: error_code.not_approve,
                keyword: "Order not placed",
                data: []
            });
        }
    }
    async displayAllProduct(requireData, callback) {
        try {
            let mainresut = {};
            let [allcategory] = await database.query("select * from tbl_store");
            mainresut.allcategory = allcategory;
            let [topDeals] = await database.query("SELECT m.*,( SELECT GROUP_CONCAT( pi.image_name) FROM tbl_product_images as pi where pi.product_id=m.id )as producr_images,CASE WHEN EXISTS(SELECT 1 FROM tbl_like_product as f WHERE f.product_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_product as m ORDER BY m.avg_rating DESC", [requireData.user_id]);
            mainresut.topDeals = topDeals;
            let [Trending_Now] = await database.query("SELECT m.*,( SELECT GROUP_CONCAT( pi.image_name) FROM tbl_product_images as pi where pi.product_id=m.id )as producr_images,CASE WHEN EXISTS(SELECT 1 FROM tbl_like_product as f WHERE f.product_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_product as m ORDER BY  m.createdat DESC", [requireData.user_id]);
            mainresut.Trending_Now = Trending_Now;
            let [new_arrivals] = await database.query("SELECT m.*,( SELECT GROUP_CONCAT( pi.image_name) FROM tbl_product_images as pi where pi.product_id=m.id )as producr_images,CASE WHEN EXISTS(SELECT 1 FROM tbl_like_product as f WHERE f.product_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_product as m ORDER BY  m.createdat DESC", [requireData.user_id]);
            mainresut.new_arrivals = new_arrivals;
            let [best_selling] = await database.query("SELECT m.*,( SELECT GROUP_CONCAT( pi.image_name) FROM tbl_product_images as pi where pi.product_id=m.id )as producr_images,(SELECT COUNT(*) FROM tbl_order_item as o where o.product_id=m.id) as COUNT,CASE WHEN EXISTS(SELECT 1 FROM tbl_like_product as f WHERE f.product_id=m.id and f.user_id=1)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_product as m ORDER BY COUNT DESC LIMIT 3", [requireData.user_id]);
            mainresut.best_selling = best_selling;
            let [recent_bought] = await database.query("SELECT p.*,( SELECT GROUP_CONCAT( pi.image_name) FROM tbl_product_images as pi where pi.product_id=p.id )as producr_images,CASE WHEN EXISTS(SELECT 1 FROM tbl_like_product as f WHERE f.product_id=p.id and f.user_id=po.user_id)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_order_item as o INNER JOIN tbl_product as p ON p.id=o.product_id INNER JOIN tbl_order as po on po.order_id=o.order_id WHERE po.user_id=?", [requireData.user_id]);
            mainresut.recent_bought = recent_bought;
            if (mainresut.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "data is not found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresut
            })

        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "data not found",
                data: []
            })
        }
    }
    async displayProductDetails(requireData, callback) {
        try {
            let data = {
                product_id: requireData.product_id
            }
            let mainresult = {}
            let [result] = await database.query("select * from tbl_product  where id=?", [data.product_id]);
            mainresult.productDetails = result;
            let [images] = await database.query("select image_name from tbl_product_images where product_id=?", [data.product_id]);
            mainresult.images = images;
            let [size] = await database.query("select c.size from tbl_size as c inner join tbl_product  as p on p.sub_category_id=c.sub_category_id where p.id=?", [data.product_id]);
            mainresult.size = size;
            let [additional_info] = await database.query("select c.* from tbl_additional_info as c inner join tbl_product  as p on p.id=c.product_id where p.id=?", [data.product_id]);
            mainresult.additional_info = additional_info;
            let [store_Details] = await database.query("select c.* from tbl_store as c inner join tbl_product  as p on p.store_id=c.id where p.id=?", [data.product_id]);
            mainresult.store_Details = store_Details;
            let [suggested_product] = await database.query("SELECT m.*,( SELECT GROUP_CONCAT( pi.image_name) FROM tbl_product_images as pi where pi.product_id=m.id )as producr_images,CASE WHEN EXISTS(SELECT 1 FROM tbl_like_product as f WHERE f.product_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_product as m  where m.sub_category_id =?", [requireData.user_id, result[0].sub_category_id]);
            mainresult.suggested_product = suggested_product;
            if (result.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "data is not found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresult
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "data not found ",
                data: []
            })
        }
    }
    async search(requestData, callback) {
        let search = requestData.search;
        search = search.trim();
        let mainresult = {};
        if (search != undefined) {
            let searchproduct = "select * from tbl_product where name like ?  and is_deleted='0'"
            let [result] = await database.query(searchproduct, [`%${search}%`]);
            if (result.length > 0) {
                mainresult.productDetails = result;
                let data = {
                    user_id: requestData.user_id,
                    role: 'product',
                    search: requestData.search
                }
                await database.query("insert into tbl_recent_search  set ?", [data])
            }
            let searchstore = "select * from tbl_store where name like ?  and is_deleted='0'"
            let [result1] = await database.query(searchstore, [`%${search}%`]);
            if (result1.length > 0) {
                mainresult.store_Details = result1;
                let data = {
                    user_id: requestData.user_id,
                    role: 'store',
                    search: requestData.search
                }
                await database.query("insert into tbl_recent_search  set ?", [data])
            }
            if (mainresult.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "data found",
                data: mainresult
            })
        }
        return callback({
            code: error_code.no_data_found,
            keyword: "no data found",
            data: []
        })
    }
    async filter(requestData, callback) {
        try {

            let data = {};
            // fiter merchants
            let filter_queary = `SELECT * FROM tbl_product as m where m.avg_rating <=? and m.sub_category_id in(?) and m.category_id in (?)  and   m.price BETWEEN 0 and ? `;
            if (requestData.category_id && requestData.category_id != 0) {
                data.category_id = requestData.category_id;
            } else {
                data.category_id = [1, 2, 3, 4, 5];
            }

            if (requestData.sub_category_id && requestData.sub_category_id != 0) {
                data.sub_category_id = requestData.sub_category_id;

            } else {
                data.sub_category_id = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
            }
            if (requestData.avg_rating && requestData.avg_rating != 0) {
                data.avg_rating = requestData.avg_rating;
            } else {
                data.avg_rating = 0;
            }
            if (requestData.price && requestData.price != 0) {
                data.price = requestData.price;
            } else {
                data.price = 1000;
            }
            console.log(data);

            let [result] = await database.query(filter_queary, [data.avg_rating, data.sub_category_id, data.category_id, data.price]);
            console.log(result[0]);

            if (result.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }

            return callback({
                code: error_code.success,
                keyword: "found",
                data: result
            })

        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.success,
                keyword: "no data found",
                data: []
            })
        }
    }
    async displayOrders(requireData, callback) {
        try {

            let [order] = await database.query("SELECT * FROM tbl_order WHERE  user_id=?", [requireData.user_id]);
            if (order.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "not data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: " data found",
                data: order
            })

        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
    }
    async addrating(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                product_id: requireData.product_id,
                rate: requireData.rate,
                review:requireData.review
            }
            let [result] = await database.query("insert into tbl_rating_review set ?", [data]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "rating is not register",
                    data: []
                })
            }
            let [count] = await database.query("select avg(rating) as rate,counts(user_id) from tbl_rating_review where product_id=?", [data.product_id]);
            await database.query("update tbl_product set avg_rating=? ,	review=? where id=?", [count[0].count,count[0].counts, data.product_id]);
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "rating  and review is not register",
                data: []
            })
        }

    }
    async likeproduct(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                product_id: requireData.product_id,
            }
            let [likestatus] = await database.query("select *  from tbl_like_product where product_id=? and user_id=? and is_deleted=0", [data.product_id, data.user_id]);
            let [result] = "";
            if (likestatus <= 0) {
                [result] = await database.query("insert into tbl_product_like set ?", [data]);
            } else {
                [result] = await database.query("update  tbl_product_like  set is_deleted=1 where  product_id=? and user_id=?", [data.product_id, data.user_id]);
            }

            if (result.length <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "like is not register",
                    data: []
                })
            }
            let [count] = await database.query("select count(DISTINCT(user_id)) as count from tbl_product_like where product_id=? and is_deleted=0", [data.product_id]);
            await database.query("update tbl_product set total_likes=? where id=?", [count[0].count, data.product_id]);
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "like is not register",
                data: []
            })
        }

    }
    async displayOrdersDetails(requireData, callback) {
        let data = {
            order_id: requireData.order_id
        }
        let mainresult = {};
        let [result] = await database.query("SELECT a.address ,o.sub_total,o.tax,o.total_price,o.delivery_charge,o.total_qty FROM tbl_order as o INNER JOIN tbl_address as a on a.id=o.address_id INNER JOIN tbl_order_item as oi on oi.order_id=o.order_id where o.id=? ", [data.order_id]);
        mainresult.orderDetails = result;
        let [result1] = await database.query("SELECT o.* ,(SELECT GROUP_CONCAT(p.image_name) FROM tbl_product_images as p WHERE p.product_id=o.product_id) as product_image FROM tbl_order_item as o WHERE o.order_id=?;", [requireData.product_id]);
        mainresult.productInfo = result1;
        if (mainresult.length <= 0) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
        return callback({
            code: error_code.success,
            keyword: " data found",
            data: mainresult
        })
    }
    async addcarddetails(requireData, callback) {
        let data = {
            holder_name: requireData.holder_name,
            card_number: requireData.card_number,
            expiry_date: requireData.expiry_date,
            user_id: requireData.user_id
        }
        let [result] = await database.query("insert into tbl_card set ?", [data]);
        if (result.length <= 0) {
            return callback({
                code: error_code.not_register,
                keyword: "not register",
                data: []
            })
        }
        return callback({
            code: error_code.success,
            keyword: " success",
            data: result
        })
    }
    async displayOrders(requireData, callback) {

        let mainresult = {};
        let [result] = await database.query("SELECT a.address ,o.sub_total,o.tax,o.total_price,o.delivery_charge,o.total_qty FROM tbl_order as o INNER JOIN tbl_address as a on a.id=o.address_id INNER JOIN tbl_order_item as oi on oi.order_id=o.order_id where o.user_id=? ", [requireData.user_id]);
        mainresult.orderDetails = result;

        if (mainresult.length <= 0) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
        return callback({
            code: error_code.success,
            keyword: " data found",
            data: mainresult
        })
    }
    async displayStore(requireData, callback) {

        let [result] = await database.query("SELECT * FROM tbl_store");

        if (result.length <= 0) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
        return callback({
            code: error_code.success,
            keyword: " data found",
            data: result
        })
    }
    async displaystoreDetails(requireData, callback) {
        try {
            let data = {
                store_id: requireData.store_id
            }
            let mainresult={};
            let [result] = await database.query("select * from tbl_store where id=?", data.store_id);
            mainresult.storeDetails=result;
            let [product] = await database.query("SELECT m.*,( SELECT GROUP_CONCAT( pi.image_name) FROM tbl_product_images as pi where pi.product_id=m.id )as producr_images,CASE WHEN EXISTS(SELECT 1 FROM tbl_like_product as f WHERE f.product_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_product as m  where m.store_id=?", [requireData.user_id,data.store_id]);
            mainresult.allProducts=product;

            if (mainresult.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "data is not found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresult
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "data not found ",
                data: []
            })
        }
    }
    async displayAddtoCart(requireData, callback) {
        let mainresult = {};
        let [result] = database.query("select * from tbl_add_to_cart where user_id=?", [requireData.user_id]);
        mainresult.cartInfo = result;
        let [price] = await database.query(
            `SELECT SUM(m.price * a.qty) AS total 
                 FROM tbl_product AS m 
                 INNER JOIN tbl_add_to_cart AS a ON m.id = a.product_id
                 WHERE a.user_id = ? `,
            [data.user_id]
        );
        mainresult.sub_total = price[0].total
        // fetch delivery charge price
        let [delivery_charge] = await database.query("select * from tbl_settings where type='delivery_charege'");
        mainresult.delivery_charge = delivery_charge[0].price;

        //fetch tax price
        let [tax] = await database.query("select * from tbl_settings where type='tax'");
        mainresult.tax = tax[0].price;
        mainresult.total_price = parseInt(price[0].total) + delivery_charge[0].price + tax[0].price;


    }
    async cancelOrder(requireData,callback){
        let data={
            order_id:requireData.order_id,
            reason:requireData.reason
        }
        let[result]=await database.query("update tbl_order set order_status='cancel' ,reason=? where order_id=?",[data.reason,data.order_id]);
        if(result.length<=0){
            return callback({
                code:error_code.not_approve,
                keyword:"not approve",
                data:[]
            })
        }
        let notification = {
            sender_id: 1,
            reciver_id: requireData.user_id,
            type: "Order is cancel",
            message: "Your order has been cancel successfully"
        };

        await database.query("INSERT INTO tbl_notification SET ?", [notification]);
        return callback({
            code:error_code.success,
            keyword:"approve",
            data:result
        })
    }
    async displayNotification(requireData,callback){
        let[result]=await database.query("select * from tbl_notification where reciver_id=?  and is_deleted=0",[requireData.user_id]);
        if(result.length<=0){
            return callback({
                code:error_code.no_data_found,
                keyword:"no data found",
                data:[]
            })
        }
        return callback({
            code:error_code.success,
            keyword:" data found",
            data:result
        })
    }
    async manageOrderStatus(requireData,callback){
        let notification = {
            sender_id: 1,            
        };
        let[user_id]=await database.query("select * from tbl_order where order_id=?"[requireData.order_id]);
        notification.reciver_id=user_id[0].user_id;
        let[result]=await database.query("update tbl_order set order_status=? where order_id=?",[requireData.status,requireData.order_id]);
        if(result.length<=0){
            return callback({
                code:error_code.not_approve,
                keyword:"status is not update",
                data:[]
            })
        }
        if(requireData.status=='item picked up'){
            data.type= "Order status",
           data.message= "Your order is on the way"
        }else if(requireData.status=='delivered'){
              data.type= "Order status",
           data.message= "Your order has been successfully deliverd!"
        }else if(requireData.status=='refund'){
            data.type= "Order status",
         data.message= "Your order refund is sent to your bank!"
      }
        await database.query("INSERT INTO tbl_notification SET ?", [notification]);
        return callback({
            code:error_code.success,
            keyword:" status is update",
            data:result
        })
    }
    async sortby(requireData,callback){
        let sortedQuery=""
        if(requireData.sortby=='asc'){
            sortedQuery="SELECT m.*,( SELECT GROUP_CONCAT( pi.image_name) FROM tbl_product_images as pi where pi.product_id=m.id )as producr_images,CASE WHEN EXISTS(SELECT 1 FROM tbl_like_product as f WHERE f.product_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_product as m ORDER BY m.price asc"
        }else if(requireData.sortby=='desc'){
            sortedQuery="SELECT m.*,( SELECT GROUP_CONCAT( pi.image_name) FROM tbl_product_images as pi where pi.product_id=m.id )as producr_images,CASE WHEN EXISTS(SELECT 1 FROM tbl_like_product as f WHERE f.product_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_product as m ORDER BY m.price DESC"
        }
        let [allProducts] = await database.query(sortedQuery, [requireData.user_id]);
        if(allProducts.length<=0){
            return callback({
                code:error_code.no_data_found,
                keyword:"data not found",
                data:[]
            })
        }
        return callback({
            code:error_code.success,
            keyword:"data  found",
            data:allProducts
        })
    }

}
module.exports = new userModule();