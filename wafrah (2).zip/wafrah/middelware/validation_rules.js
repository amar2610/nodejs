const { forgotPassword } = require("../modules/v1/user/module/user_module")

const checkValidationRules = {
    login: {
      password:"required",
      deviceType:"required"
    },
    productDetail:{
        product_id:"required"
    },
    signUp: {
        name:"required",
        profile_image:"required",
        email: "required|email",
        phone: "required|digits:10",
        password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]

    },
   forgotPassword:{
    email:"required"
   },
   socialLogin:{
    social_id:"required"
   },
   
    setlocation:{
        latitude:"required",
        longitude:"required",
        address:"required",
    },
   
   
   
    addtocart:{
        product_id:"required",
        qty:"required"
    },
    review:{
        product_id:"required",
        review:"required", rating:"required"
    },
    like:{
        product_id:"required"    },
   
  
}
module.exports = checkValidationRules
