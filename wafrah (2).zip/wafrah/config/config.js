let encryptlib=require("cryptlib");
let env={
    itemPerPage:3,
    imgUrl:"https://www.image.com/product/",
    is_production:true,
    server_listner:3035,
    version:"1.0.0",
    api_key:"wafrah",
    encryptionKey:encryptlib.getHashSha256("xza548sa3vcr641b5ng5nhy9mlo64r6k",32),
    encryptionIV:"5ng5nhy9mlo64r6k"
};
 module.exports=env;