const database = require("../config/databse");
const DataBase = require("../config/databse");
const process = require('../config/config');
let cryptlip = require("cryptlib");
let Math = require("math");


class common {
    Response(res, message) {
        res.json(message);
    }
    //to generate login token
    generatetocken(length) {
        let posible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        let text = "";
        for (let i = 0; i < length; i++) {
            text += posible.charAt(Math.floor(Math.random() * posible.length));
        }
        return text;
    }
    encryptPlain(data) {
        return cryptlip.encrypt(JSON.stringify(data), process.encryptionKey, process.encryptionIV)
    }
    decryptPlain(data) {
        return cryptlip.decrypt(data, process.encryptionKey, process.encryptionIV)
    }
    SetToken(user_id) {
        let tokan = this.generatetocken(40);
        let updatetokan = "update tbl_device set token=? where user_id=?";

        DataBase.query(updatetokan, [tokan, user_id], (error, result) => {
            if (error) {
                console.log("operation faild", error);
            }
            if (result <= 0) {
                console.log("token in not generated");
            }
            console.log("token generated");

        })
    }
    async getDistance(id) {

        let [distance] = await database.query(`select ROUND(( 6371 * ACOS( COS( RADIANS(d.latitude) )  
		* COS( RADIANS( 23.128916 ) ) 
		* COS( RADIANS(72.544657) - RADIANS(d.longitude) )  
		+ SIN( RADIANS(d.latitude) )  
		* SIN( RADIANS( 23.128916 ) ) ) ),1) as distance from tbl_user as d where id=?`, [id]);
        if (distance.length <= 0) {
            return 0;
        }
        return distance[0].distance;
    }
   
}
module.exports = new common();