var message = {
    "required": "The :attr field is required",
    "email": "Please enter valid :attr",
    "rest_keywords_required_message": "Please enter :attr",  
    "rest_keywords_unique_email_error":"Hey { username } ! This email is already being used.",
    "rest_keywords_something_went_wrong":"{ username } Something went wrong.",
    "rest_keywords_success":"Success", 
    "not_verified": "{ username } your mobile number/email has not yet been verified",
    "login_invalid_credential": "Invalid credentials",
    "login_success": "Login Success! welcome ",
    "header_key_value_incorrect": "Unauthorized access of api, invalid value for api key",
    "header_authorization_token_error": "Unauthorized access of api, Invalid authorization token please check you request",
    "no_data_found": "No data found",
    "data_found": "Data found",
    "rest_keywords_password":"password"
}

module.exports = message;