const Express= require("express");
const Config=require("./config/config");
const App_Routing=require("./modules/app_routing");

 let app=Express();
 app.use(Express.json());
 app.use('/',require('../ToStylMou/middleware/validators').extractHeaderLanguage);

App_Routing.v1(app);

app.listen(Config.server_listner,()=>{
    console.log("server running on:"+Config.server_listner);
})