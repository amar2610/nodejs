let mysql=require("mysql");
let  credential={}
credential={
    host:"localhost",
    user:"root",
    password:"",
    database:"db_tostyl",
    dateString:"date",
    port:3304
}
try{
let DataBase=mysql.createPool(credential);
if(DataBase){
    console.log("database is connected");
}else{
    console.log("database is not connected");
}
module.exports=DataBase;
}
catch(error){
    console.log("database connection error",error);
}
