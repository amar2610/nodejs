let User = require("../controller/user");
let CusromerRoute = (app) => {
    //Authentication 
    app.post("/v1/user/signup", User.SignUp);
    app.post("/v1/user/otpverify", User.OtpVerify);
    app.post("/v1/user/userlogin", User.UserLogin);
    app.post("/v1/user/forgotpassword", User.ForgotPassword);
    app.post("/v1/user/resetpassword", User.ResetPassword);
    app.post("/v1/user/changePassword", User.ChangePassword);
    app.post("/v1/user/personalinfo", User.Personalinfo);
    app.post("/v1/user/userlogout", User.UserLog_out);

    // post manage
    app.post("/v1/user/createpost", User.CreatePost);
    app.post("/v1/user/addcategory", User.addCategory);
    app.post("/v1/user/addcomment", User.AddComment);
    app.post("/v1/user/addrating", User.AddRating);
    app.post("/v1/user/followprofile", User.followProfile);
    app.post("/v1/user/addsubpostrating", User.AddSubPostRating);



    app.get("/v1/user/getallpost/:type?/:category?", User.GetAllPost);
    app.get("/v1/user/getcategory", User.GetCategory);
    app.get("/v1/user/subpostranking", User.SubPostRanking);
    app.get("/v1/user/gettrendingpost", User.DisplayTrendingPost);
    app.get("/v1/user/displaypost/:type?", User.DisplayPost);
    //app.get("/v1/user/displayuserdetails",User.UserDetail);
    app.get("/v1/user/displayuserpost/:category?", User.ViewUserPost);
    app.get("/v1/user/viewotherprofile/:category?", User.viewotherprofile);






}
module.exports = CusromerRoute;