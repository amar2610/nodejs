const UserModel = require("../models/user_model");
const Common = require("../../../../utilities/common");
var middleware = require('../../../../middleware/validators');
let ValidationRules = require("../../../../middleware/validation_rules");
const { t } = require('localizify');
class User {
    // first step of sign up
    SignUp(req, res) {
        let request = req.body
        // console.log(request);

        var rules = ValidationRules.signUp
        let message = {
            required: req.language.required
        }
        let keyword = {
        }
        if (middleware.checkValidationRules(req, res, request, rules, message, keyword)) {
            UserModel.SignUp(request, function (_responsedata) {
                middleware.send_response(req, res, _responsedata);
            })
        }

    }
    // second step of sign up 
    Personalinfo(req, res) {
        let request = req.body
        // console.log(request);

        var rules = ValidationRules.completProfile
        let message = {
            required: req.language.required
        }
        let keyword = {
        }
        if (middleware.checkValidationRules(req, res, request, rules, message, keyword)) {
            UserModel.PersonalInfo(request, function (_responsedata) {
                middleware.send_response(req, res, _responsedata);
            })
        }
    }
    //otp verification 
    OtpVerify(req, res) {
        let request = req.body
        // console.log(request);

        var rules = ValidationRules.verifyOtp
        let message = {
            required: req.language.required
        }
        let keyword = {
        }
        if (middleware.checkValidationRules(req, res, request, rules, message, keyword)) {
            UserModel.OtpVerify(request, function (_responsedata) {
                middleware.send_response(req, res, _responsedata);
            })
        }
    }
    //display Trending posts
    DisplayTrendingPost(req, res) {
        let RequireData = req.body;
        UserModel.DispalTrendingPost(RequireData, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    //display ranking of sub post
    SubPostRanking(req, res) {
        let RequireData = req.body;
        UserModel.SubPostRanking(RequireData, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    // add comment on post
    AddComment(req, res) {
        let RequireData = req.body;
        UserModel.AddComment(RequireData, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    // add rating on main post
    AddRating(req, res) {
        let RequireData = req.body;
        UserModel.AddRating(RequireData, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    // add rating on sub post
    AddSubPostRating(req, res) {
        let RequireData = req.body;
        UserModel.AddSubPostRating(RequireData, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    // user login
    UserLogin(req, res) {
        let request = req.body
        // console.log(request);

        var rules = ValidationRules.login

        let message = {
            required: req.language.required
        }

        let keyword = {
            'passwords': t('rest_keywords_password')
        }

        if (middleware.checkValidationRules(req, res, request, rules, message, keyword)) {
            UserModel.UserLogin(request, function (_responsedata) {

                middleware.send_response(req, res, _responsedata);
            })
        }


    }
    // forgot password
    ForgotPassword(req, res) {
        let request = req.body
        // console.log(request);

        var rules = {
            email: 'required',
        }

        let message = {
            required: req.language.required
        }

        let keyword = {
            'passwords': t('rest_keywords_password')
        }
        if (middleware.checkValidationRules(req, res, request, rules, message, keyword)) {
            UserModel.ForgotPassword(request, function (_responsedata) {
                console.log(_responsedata.message);

                middleware.send_response(req, res, _responsedata);
            })
        }
    }
    //reset password
    ResetPassword(req, res) {
        let request = req.body
        // console.log(request);

        var rules=ValidationRules.resetPassword

        let message = {
            required: req.language.required
        }

        let keyword = {
            'passwords': t('rest_keywords_password')
        }
        if (middleware.checkValidationRules(req, res, request, rules, message, keyword)) {
            UserModel.ResetPassword(request, function (_responsedata) {
                console.log(_responsedata.message);

                middleware.send_response(req, res, _responsedata);
            })
        }
    }
    //cahnge password
    ChangePassword(req, res) {
        let request = req.body
        // console.log(request);

        var rules = ValidationRules.changePassword
        let message = {
            required: req.language.required
        }
        let keyword = {
        }
        if (middleware.checkValidationRules(req, res, request, rules, message, keyword)) {
            UserModel.ChangePassword(request, function (_responsedata) {
                middleware.send_response(req, res, _responsedata);
            })
        }
    }
    // get all category
    GetCategory(req, res) {
        let RequireData = req.body;
        UserModel.DisplayCategory(RequireData, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    // display all post
    DisplayPost(req, res) {
        let RequireData = req.params.type;
        UserModel.DisplayPost(RequireData, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    // create post
    CreatePost(req, res) {
        let request = req.body
        // console.log(request);

        var rules = ValidationRules.addPost
        let message = {
            required: req.language.required
        }
        let keyword = {
        }
        if (middleware.checkValidationRules(req, res, request, rules, message, keyword)) {
            UserModel.CreatePost(request, function (_responsedata) {
                middleware.send_response(req, res, _responsedata);
            })
        }
    }
    /* UserDetail(req, res) {
         let RequireData = req.body;
         UserModel.UserDetail(RequireData, (__RequireData) => {
             Common.Response(res, __RequireData);
         })
     }*/
    GetAllPost(req, res) {

        let user_id = req.body;
        let RequireData = req.params.type;
        let category = req.params.category;
        UserModel.GetAllPost(RequireData, user_id, category, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    // fetch user detials
    ViewUserPost(req, res) {
        let user_id = req.body;
        let category = req.params.category;
        UserModel.ViewUserPost(user_id, category, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    //user log-out
    UserLog_out(req, res) {
        let user_id = req.body;
        UserModel.LogOutUser(user_id, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }

    addCategory(req, res) {
        let requireData = req.body;
        UserModel.addCategory(requireData, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }
    viewotherprofile(req, res) {
        let request_data = req.body;
        let category = req.params.category;
        UserModel.viewOtherProfile(request_data, category, (_responsedata) => {
            Common.Response(res, _responsedata);
        })
    }
    followProfile(req, res) {
        let RequireData = req.body;
        UserModel.followProfile(RequireData, (__RequireData) => {
            Common.Response(res, __RequireData);
        })
    }

}
module.exports = new User();