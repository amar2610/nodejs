const DataBase = require("../../../../config/database");
const Md5 = require("md5");
const Error_Code = require("../../../../utilities/error_response");
const error_code = require("../../../../utilities/error_response");
const { GenerateOtp } = require("../../../../utilities/common");
const common = require("../../../../utilities/common");
class UserModel {
    id = 0;
    SignUp(RequireData, callback) {
     

            let data = {
                user_name: RequireData.user_name,
                email: RequireData.email,
                phone: RequireData.phone,
                password: Md5(RequireData.password)
            }
            let DeviceDetails = {
                device_token: RequireData.devicetoken,
                device_type: RequireData.devicetype,
                os_type: RequireData.ostype,
                app_version: RequireData.appversion,
            }

            let CheckUser = "select * from tbl_user where email=? or phone=?";
            DataBase.query(CheckUser, [data.email, data.phone], (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation faild"
                    })
                }
                if (result.length > 0) {
                    return callback({
                        code: error_code.data_already_exist,
                        keyword: "email and phone alredy exist"
                    })
                }


                let insertQuery = "INSERT INTO tbl_user SET ? ";
                DataBase.query(insertQuery, data, (error, result) => {
                    if (error) {
                        console.error("Database error:", error);
                        return callback({
                            code: error_code.not_register,
                            keyword: "data not inserted"
                        });
                    }
                    if (result <= 0) {
                        return callback({
                            code: error_code.not_register,
                            keyword: "data not inserted"
                        });
                    }
                    console.log(result);
                    this.id = result.insertId;
                    DeviceDetails.user_id = this.id;
                    this.GenerateOtp(RequireData);
                    let InsertDeviceDetails = "insert into tbl_device set?"
                    DataBase.query(InsertDeviceDetails, DeviceDetails, (error, result) => {
                        if (error) {
                            console.log("internal error", error);
                        }
                        if (result <= 0) {
                            console.log("device data not inserted");
                        }
                        console.log("device data inserted successfuly");

                    })
                    return callback({
                        code: error_code.success,
                        keyword: "data inserted"
                    });
                });
            });


      
    }

    GenerateOtp(RequireData) {
        let Data = {
            otp: common.GenerateOtp(),
            user_id: this.id,
            phone: RequireData.phone,
            email: RequireData.email
        }

        let OtpQuery = "insert into tbl_otp set ?"
        DataBase.query(OtpQuery, Data, (result) => {
            console.log("hello");

            if (!result || result === 0) {
                return 0;
            }
            return 1;
        });

    }

    OtpVerify(RequireData, callback) {
        try {
            if (!RequireData.user_id) throw new Error("user_id require");
            if (!RequireData.otp) throw new Error(" otp require");
            let data = {
                user_id: RequireData.id,
                otp: RequireData.otp,
            }
            let id = RequireData.user_id;

            let CheckVerify = "SELECT otp FROM  tbl_otp WHERE  user_id=?";
            DataBase.query(CheckVerify, [id], (error, result1) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation faild",
                    })
                }
                if (result1 <= 0) {
                    return callback({
                        code: error_code.data_already_exist,
                        keyword: "user not exist"
                    })
                }
                if (result1[0].otp != data.otp) {
                    return callback({
                        code: error_code.otp_not_veryfied,
                        keyword: "otp in not same"
                    })
                }
                this.step_count = result1[0].id;
                if (result1[0].otp == data.otp) {
                    // updagte verification status
                    let UpdateStatus = "update tbl_otp set is_verify=1 where user_id= ? ";
                    DataBase.query(UpdateStatus, [id], (error, result) => {
                        if (error) {
                            return callback({
                                code: error_code.operation_failed,
                                keyword: "operation faild"
                            })
                        }

                        if (result <= 0) {
                            return callback({
                                code: error_code.otp_not_veryfied,
                                keyword: " otp is not verify"
                            })
                        }
                        // fetch step count from user table
                        let GetStep = "select * from tbl_user where id=?";
                        DataBase.query(GetStep, [id], (error, result) => {
                            if (error) {
                                console.log("operation faild", error);
                            }
                            if (result[0].step_count != '3') {
                                let UpdateStatus = "update tbl_user set step_count=2 where id=?";
                                DataBase.query(UpdateStatus, [id]);
                            }
                        });

                    });
                    return callback({
                        code: error_code.otp_not_veryfied,
                        keyword: "verify complete of your phone and email"
                    })
                }

            });


        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form", Error
            });
        }

    }

    PersonalInfo(RequireData, callback) {
        try {
            if (!RequireData.profile_image) throw new Error("profile image require");
            if (!RequireData.user_id) throw new Error("user_id require");
            if (!RequireData.fullname) throw new Error("full name require");
            if (!RequireData.dob) throw new Error("date of birth require");
            if (!RequireData.description) throw new Error("description require");
            let data = {

                profile_image: RequireData.profile_image,
                fullname: RequireData.fullname,
                dob: RequireData.dob,
                description: RequireData.description
            }
            let id = RequireData.user_id;

            let CheckVerify = "SELECT * FROM `tbl_user` WHERE  id=?";
            DataBase.query(CheckVerify, [id], (error, result) => {
                console.log(error);
                if (result <= 0) {
                    return callback({
                        code: error_code.data_already_exist,
                        keyword: "user not exist"
                    })
                }
                if (result[0].step_count == 1) {
                    return callback({
                        code: error_code.otp_not_veryfied,
                        keyword: "verify your phone and email"
                    })
                }

                let EditProfile = "update tbl_user set? where id=?";
                DataBase.query(EditProfile, [data, id], (error, result) => {
                    if (!result || result === 0) {
                        return callback({
                            code: error_code.not_register,
                            keyword: "profile not updated"
                        })
                    }
                    let updatestatus = "update tbl_user set step_count=3 where id=?";
                    DataBase.query(updatestatus, [id]);
                    common.SetToken([id]);
                    return callback({
                        code: error_code.success,
                        keyword: "profile  updated successfuly"
                    })
                });

            });


        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form", Error
            });
        }

    }

    UserLogin(RequireData, callback) {
     

            let data = {
                email: RequireData.email,
                password: Md5(RequireData.password)
            }

            let CheckVerify = "SELECT * FROM tbl_user WHERE  email=? and password=?";
            DataBase.query(CheckVerify, [data.email, data.password], (error, result) => {
                console.log(result[0]);
                if (result <= 0) {
                    return callback({
                        code: error_code.data_already_exist,
                        keyword: "login_invalid_credential"
                    })
                }
                if (result[0].step_count == 1) {
                    return callback({
                        code: error_code.otp_not_veryfied,
                        keyword: "verify your phone and email"
                    })
                }
                if (result[0].step_count == 2) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "complete your profile"
                    })
                }

                common.SetToken(result[0].id);
                return callback({
                    code: error_code.success,
                    keyword: "login_success"
                })

            });


      

    }
    //forgotpassword
    ForgotPassword(RequireData, callback) {
        try {
            if (!RequireData.email) throw new Error("email is require");
            let email = RequireData.email;

            let CheckEmail = "select * from tbl_user where email=?";
            DataBase.query(CheckEmail, email, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "no_data_found"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "email id is not found"
                    })
                }
                this.id = result[0].id;


                this.GenerateOtp(result[0])
                return callback({
                    code: error_code.success,
                    keyword: "otp sent to your device"
                })

            })
        } catch (error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form", Error
            });
        }
    }
    //reset password
    ResetPassword(RequireData, callback) {
        try {
          
            let data = {
                id: RequireData.user_id,
                password: RequireData.password
            }
            let updatepassword = "update tbl_user set password=? where id=?";
            DataBase.query(updatepassword, [data.password, data.id], (error, result) => {
                if (error) {
                    console.log(error);

                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation faild"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.not_approve,
                        keyword: "password not changed"
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "password changed"
                })
            })

        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form", Error
            });
        }

    }
    // to change password
    ChangePassword(RequireData, callback) {

        try {
            if (!RequireData.oldpassword) throw new Error("Old password is require");
            if (!RequireData.newpassword) throw new Error("new password is require");
            if (!RequireData.user_id) throw new Error("user id is require");

            let OldPassword = RequireData.oldpassword;
            let NewPassword = RequireData.newpassword;

            let CheckPassword = "select password from tbl_user where id=?";
            DataBase.query(CheckPassword, RequireData.user_id, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation faild"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "data not found"
                    })
                }
                if (result[0].password == OldPassword) {

                    if (NewPassword != result[0].password) {
                        let UpdatePassword = "update tbl_user set password=? where id=?";
                        DataBase.query(UpdatePassword, [NewPassword, RequireData.user_id], (error, result) => {
                            if (error) {
                                return callback({
                                    code: error_code.operation_failed,
                                    keyword: "operation faild at a time of a change password"
                                })
                            }
                            if (result <= 0) {
                                return callback({
                                    code: error_code.not_register,
                                    keyword: "password not changed"
                                })

                            }
                            return callback({
                                code: error_code.success,
                                keyword: "password change successfuly"
                            })
                        })
                    } else {
                        return callback({
                            code: error_code.not_approve,
                            keyword: "olpassword and new password both are same"
                        });
                    }
                }
                else {
                    return callback({
                        code: error_code.invalid_input,
                        keyword: "old password in not match"
                    })
                }
            })


        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form", Error
            });
        }

    }
    GetAllPost(RequireData, user, postcategory, callback) {
        try {
            console.log(RequireData, postcategory);

            if (!user.user_id) throw new error("user id require");
            let GetPost = "";

            if (RequireData == "following") {
                if (postcategory == "tocompare") {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p INNER JOIN tbl_user as u ON u.id=p.user_id WHERE u.id in(SELECT following FROM tbl_following WHERE follower='" + user.user_id + "' and type='tocompare')";
                } else if (postcategory == "tomyself") {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p INNER JOIN tbl_user as u ON u.id=p.user_id WHERE u.id in(SELECT following FROM tbl_following WHERE follower='" + user.user_id + "' and type='tomyself')";
                } else if (postcategory == "tovideo") {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p INNER JOIN tbl_user as u ON u.id=p.user_id WHERE u.id in(SELECT following FROM tbl_following WHERE follower='" + user.user_id + "' and type='tovideo')";
                }
                else {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p INNER JOIN tbl_user as u ON u.id=p.user_id WHERE u.id in(SELECT following FROM tbl_following WHERE follower='" + user.user_id + "')";
                }
            }
            else if (RequireData == "expiry") {
                if (postcategory == "tocompare") {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p WHERE p.expiry_time> CURRENT_TIMESTAMP and type='tocompare';"
                } else if (postcategory == "tomyself") {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p WHERE p.expiry_time> CURRENT_TIMESTAMP and type='tomyself';"
                } else if (postcategory == "tovideo") {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p WHERE p.expiry_time> CURRENT_TIMESTAMP and type='tovideo';"
                } else {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p WHERE p.expiry_time> CURRENT_TIMESTAMP;"
                }
            }
            else if (RequireData == "all") {
                if (postcategory == "tocompare") {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p INNER JOIN tbl_user as u ON u.id=p.user_id WHERE u.id in(SELECT following FROM tbl_following WHERE  type='tocompare')";
                } else if (postcategory == "tomyself") {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p INNER JOIN tbl_user as u ON u.id=p.user_id WHERE u.id in(SELECT following FROM tbl_following WHERE  type='tomyself')";
                } else if (postcategory == "tovideo") {
                    GetPost = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p INNER JOIN tbl_user as u ON u.id=p.user_id WHERE u.id in(SELECT following FROM tbl_following WHERE type='tovideo')";
                } else {
                    GetPost = "SELECT DISTINCT(p.id) as post_image, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p";
                }
            }
            else if (!RequireData) {

                GetPost = "SELECT DISTINCT(p.id) as post_image, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p";

            }

            DataBase.query(GetPost, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "peration faild at time of get all post"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "data not found",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "data found",
                    data: result
                })
            })

        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "data not found", Error
            });
        }
    }
    //display category
    DisplayCategory(RequireData, callback) {
        try {
            let getdata = "SELECT c.category_name,GROUP_CONCAT(s.image_name) FROM tbl_post as p INNER JOIN tbl_category as c ON c.id=p.category_id INNER JOIN tbl_sub_post as s on s.post_id=p.id GROUP by category_id";
            DataBase.query(getdata, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation faild",
                        error: error
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "no data found"
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "data found",
                    data: result
                })

            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "data not found", Error
            });

        }
    }
    //diaplay posts
    DisplayPost(RequireData, callback) {
        try {
            let GetPosts
            if (!RequireData) {
                GetPosts = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p ";
            } else {
                GetPosts = "SELECT DISTINCT(p.id) as post_id, (SELECT group_concat(s.image_name) FROM tbl_sub_post as s where s.post_id=p.id)as post_image FROM `tbl_post` as p WHERE type='tocompare'";
            }
            DataBase.query(GetPosts, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation faild"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "no data found",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "data found",
                    data: result
                })
            })

        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "data not found", Error
            });

        }
    }
    // create new post
    CreatePost(RequireData, callback) {
        try {
            if (!RequireData.image) throw new Error("image is require");
            if (!RequireData.description) throw new Error("description is require");
            if (!RequireData.category) throw new Error("category is require");
            if (!RequireData.expiry) throw new Error("post expiry is require");
            if (!RequireData.type) throw new Error("post type is require");
            if (!RequireData.user_id) throw new Error("user id is require")

            let post = {
                user_id: RequireData.user_id,
                description: RequireData.description,
                category_id: RequireData.category,
                type: RequireData.type,
                expiry_time: RequireData.expiry
            }
            let imagearry = RequireData.image.split(',');
            console.log(imagearry);

            let inserpost = "insert into tbl_post set ?";
            DataBase.query(inserpost, [post], (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation faild"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "post is not upload"
                    })
                }
                let id = result.insertId;
                for (let i = 0; i < imagearry.length; i++) {
                    let data = {
                        post_id: id,
                        image_name: imagearry[i]
                    }
                    let insersubpost = "insert into tbl_sub_post set ?"
                    DataBase.query(insersubpost, [data], (error, result) => {
                        if (error) {
                            console.log(error);
                        }
                        if (result <= 0) {
                            console.log("sub post is not inserted");

                        }
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "post upload successfuly"
                })
            })



        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "data not found", Error
            });
        }
    }
    // to display user posts
    ViewUserPost(user, postcategory, callback) {
        try {
            console.log(postcategory);

            if (!user.user_id) throw new error("user id require");
            let GetPost = "";
            let userdetails = "SELECT u.profile_image,u.user_name,u.description,u.follower,u.following FROM tbl_user as u  WHERE u.id='" + user.user_id + "'";
            if (postcategory) {
                if (postcategory == "tocompare") {
                    GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "' and type='tocompare'";
                } else if (postcategory == "tomyself") {
                    GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "' and type='tomyself'";
                } else if (postcategory == "tovideo") {
                    GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "' and type='tovideo'";
                }
                else {
                    GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "'";
                }
            }
            else if (!postcategory) {

                GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "'";
            }

            DataBase.query(userdetails, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "peration faild at time of get all post"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "data not found",
                        data: []
                    })
                }

                DataBase.query(GetPost, (error, result1) => {
                    if (error) {
                        return callback({
                            code: error_code.operation_failed,
                            keyword: "peration faild at time of get all post"
                        })
                    }
                    if (result <= 0) {
                        return callback({
                            code: error_code.no_data_found,
                            keyword: "data not found",
                            data: []
                        })
                    }
                    return callback({
                        code: error_code.success,
                        keyword: "data found",
                        data: result,
                        user: result1
                    })
                })
            })

        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "data not found", Error
            });
        }
    }
    /*
        UserDetail(user, postcategory, callback) {
            try {
                console.log(postcategory);
    
                if (!user.user_id) throw new error("user id require");
                let GetPost = "";
                let userdetails="SELECT u.profile_image,u.user_name,u.description,u.follower,u.following,p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='"+user.user_id+"'";
                if (postcategory) {
                    if (postcategory == "tocompare") {
                        GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "' and type='tocompare'";
                    } else if (postcategory == "tomyself") {
                        GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "' and type='tomyself'";
                    } else if (postcategory == "tovideo") {
                        GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "' and type='tovideo'";
                    }
                    else {
                        GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "'";
                    }
                }
                else if (!postcategory) {
    
                    GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + user.user_id + "'";
                }
    
                DataBase.query(userdetails,(error,result)=>{
                    if (error) {
                        return callback({
                            code: error_code.operation_failed,
                            keyword: "peration faild at time of get all post"
                        })
                    }
                    if (result <= 0) {
                        return callback({
                            code: error_code.no_data_found,
                            keyword: "data not found",
                            data: []
                        })
                    }
               
                DataBase.query(GetPost, (error, result1) => {
                    if (error) {
                        return callback({
                            code: error_code.operation_failed,
                            keyword: "peration faild at time of get all post"
                        })
                    }
                    if (result <= 0) {
                        return callback({
                            code: error_code.no_data_found,
                            keyword: "data not found",
                            data: []
                        })
                    }
                    return callback({
                        code: error_code.success,
                        keyword: "data found",
                        data: result,
                        post:result1
                    })
                })
            })
    
            } catch (Error) {
                console.log(Error);
                return callback({
                    code: error_code.invalid_input,
                    keyword: "data not found", Error
                });
            }
        }*/
    // add comment on post
    AddComment(RequireData, callback) {
        try {
            if (!RequireData.user_id) throw new Error("user name is require");
            if (!RequireData.post_id) throw new Error("post id is require");
            if (!RequireData.comment) throw new Error("comment is require");

            let data = {
                user_id: RequireData.user_id,
                post_id: RequireData.post_id,
                comment: RequireData.comment
            }
            let addcomment = "insert into tbl_comments set ?";
            DataBase.query(addcomment, data, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "comment add operation faild"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "comment in not added"
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "comment added"
                })
            })

        } catch (error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "data not found", Error
            });
        }
    }
    //add rating on main post
    AddRating(RequireData, callback) {
        try {
            if (!RequireData.user_id) throw new Error("user name is require");
            if (!RequireData.post_id) throw new Error("post id is require");
            if (!RequireData.rating) throw new Error("comment is require");

            let data = {
                user_id: RequireData.user_id,
                post_id: RequireData.post_id,
                rating: RequireData.rating
            }
            let addcomment = "insert into tbl_post_rating set ?";
            DataBase.query(addcomment, data, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "rating add operation faild"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "rating in not added"
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "rating added"
                })
            })

        } catch (error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "data proper data", Error
            });
        }
    }
    //display ternding post
    DispalTrendingPost(RequireData, callback) {
        try {
            let fetchpost = "SELECT * FROM `tbl_post` ORDER BY avg_rating DESC";
            DataBase.query(fetchpost, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "get trending post operation fail"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "data not found",
                        data: []

                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "data found",
                    data: result
                })
            })
        } catch (error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "data not found", Error
            });
        }
    }
    //fetch subpost ranking
    SubPostRanking(RequireData, callback) {
        try {
            if (!RequireData.post_id) throw new Error("post id is require");
            let GetRanking = "SELECT s.image_name, ROW_NUMBER() OVER (ORDER BY s.rating DESC) AS ranking FROM tbl_post as p INNER JOIN tbl_sub_post as s on s.post_id=p.id WHERE s.post_id=? and p.type='tocompare'";
            DataBase.query(GetRanking, [RequireData.post_id], (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "get sub post ranking operation fail"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "data not found on this post id",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "data found",
                    data: result
                })
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "data not found", Error
            });
        }
    }
    //add rating on sub post
    AddSubPostRating(RequireData, callback) {
        try {
            //check valid value from user side
            if (!RequireData.subpost_id) throw new Error("sub post id is require");
            if (!RequireData.user_id) throw new Error("user id is require");
            if (!RequireData.rating) throw new Error("rating is require");
            let data = {
                sub_post_id: RequireData.subpost_id,
                user_id: RequireData.user_id,
                rating: RequireData.rating
            }
            //insert raing in subpost rating table
            let AddRating = "insert into tbl_sup_post_rating set ?";
            DataBase.query(AddRating, data, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation fail",
                        error: error
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "rating is not inserted"
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "rating added successfuly"
                })
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "add proper data", Error
            });
        }
    }
    //user log-out api
    LogOutUser(RequireData, callback) {
        try {
            //check proper value insert
            if (!RequireData.user_id) throw new Error("user id is require");
            // fetch user details
            let fetchuser = "select * from tbl_user where id=?";
            DataBase.query(fetchuser, [RequireData.user_id], (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation faild"
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "user not found"
                    })
                }
                // update token 
                let updatetoken = "update tbl_device set token='' where user_id=?";
                DataBase.query(updatetoken, [RequireData.user_id]);
                return callback({
                    code: error_code.success,
                    keyword: "user log-out successfuly"
                })
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter valid values"
            })

        }

    }
    //add category
    addCategory(RequireData, callback) {
        try {
            if (!RequireData.category_image || !RequireData.category_name) throw new Error("enter valid input");
            let data = {
                category_name: RequireData.category_name,
                category_image: RequireData.category_image
            }

            let insertCategory = "insert into tbl_category set ?";
            DataBase.query(insertCategory, data, (error, result) => {
                if (error) {
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "operation fail",
                        error: error
                    })
                }
                if (result <= 0) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "category is not inserted"
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "category added successfuly"
                })
            })
        } catch (Error) {
            console.log(Error);
            return callback({
                Code: error_code.invalid_input,
                keyword: "enter valid value "
            })

        }
    }
    //view other profiles
    viewOtherProfile(RequireData, postcategory, callback) {
        try {
            // Validate input data
            if (!RequireData.user_id) throw new Error("User ID is required");
            if (!RequireData.other_id) throw new Error("Other user ID is required");

            let GetPost = "";
            let userdetails = "SELECT u.profile_image,u.user_name,u.description,u.follower,u.following FROM tbl_user as u  WHERE u.id='" + RequireData.other_id + "'";
            if (postcategory) {
                if (postcategory == "tocompare") {
                    GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + RequireData.other_id + "' and type='tocompare'";
                } else if (postcategory == "tomyself") {
                    GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + RequireData.other_id + "' and type='tomyself'";
                } else if (postcategory == "tovideo") {
                    GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + RequireData.other_id + "' and type='tovideo'";
                }
                else {
                    GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + RequireData.other_id + "'";
                }
            }
            else if (!postcategory) {

                GetPost = "SELECT p.id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.id WHERE u.id='" + RequireData.other_id + "'";
            }


            let other_id = RequireData.other_id;

            let folowing = "SELECT following FROM tbl_following WHERE follower=?";
            DataBase.query(folowing, [RequireData.user_id], (error, result) => {
                if (error) {
                    console.error("Internal error:", error);
                    return callback({
                        code: error_code.operation_failed,
                        keyword: "Operation failed"
                    });
                }
                if (!result || result.length <= 0) {
                    return callback({
                        code: error_code.no_data_found,
                        keyword: "No data found"
                    });
                }

                let followingIds = result.map(row => row.following);
                if (followingIds.includes(other_id)) {
                    DataBase.query(userdetails, (error, result) => {
                        if (error) {
                            return callback({
                                code: error_code.operation_failed,
                                keyword: "operation faild at time of get all post"
                            })
                        }
                        if (result <= 0) {
                            return callback({
                                code: error_code.no_data_found,
                                keyword: "data not found",
                                data: []
                            })
                        }
                        DataBase.query(GetPost, (error, result1) => {
                            if (error) {
                                return callback({
                                    code: error_code.operation_failed,
                                    keyword: "peration faild at time of get all post"
                                })
                            }
                            if (result <= 0) {
                                return callback({
                                    code: error_code.no_data_found,
                                    keyword: "data not found",
                                    data: []
                                })
                            }
                            return callback({
                                code: error_code.success,
                                keyword: "data found",
                                data: result,
                                user: result1
                            })
                        })
                    })

                } else {
                    return callback({
                        code: error_code.inactive_account,
                        keyword: "You do not follow this user"
                    });
                }
            });

        } catch (error) {
            return callback({
                code: error_code.invalid_input,
                keyword: error.keyword
            });
        }
    }
    //follow others
    followProfile(RequireData,callback){
        try{
            if(!RequireData.user_id || !RequireData.other_id) throw new Error("enter valid values for follow");
            let data={
                follower:RequireData.user_id,
                following:RequireData.other_id
            }
            let interfollow="insert into tbl_following set ?"
            DataBase.query(interfollow,data,(error,result)=>{
                if(error){
                    return callback({
                        code:error_code.operation_failed,
                        keyword:"operation faild",
                        error:error
                    })
                }
                if(result<=0){
                    return callback({
                        code:error_code.not_register,
                        keyword:"data not insert in following table"
                    })
                }
                return callback({
                    code:error_code.success,
                    keyword:"follow successfuly"
                })
            })
        }catch(error){
            console.log(error);
            return callback({
                code:error_code.invalid_input,
                keyword:"enter valid values",
                error:error
            })
        }
    }
}

module.exports = new UserModel;