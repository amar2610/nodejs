
    const checkValidationRules={
        login:{
            email:'required|email',
            password:'required',
        },
        signUp:{
            user_name:"required",
            email:"required|email",
            phone:"required|string|min:10|regex:/^[0-9]+$/",
            password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]
    
        },
        completProfile:{
            user_id:"required",
            fullname:"required",
            description:"required",
            profile_image:"required",
            dob: [
                "required",
                "regex:/^(19[0-9]{2}|20[0-2][0-9])-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/"
            ]
        },
        verifyOtp:{
            user_id:"required", 
            otp:"required"
        },
        addPost:{
            description:"required",
            category:"required",
            expiry:"required",
            type:"required",
            image:"required"
        },
        resetPassword:{
            user_id:"required",
            password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]
            
        },
        changePassword:{

            old_password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"],
           new_password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]
                

        }
    }
    module.exports = checkValidationRules
