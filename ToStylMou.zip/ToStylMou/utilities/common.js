const DataBase = require("../config/database");

class common {
    Response(res, message) {
        res.json(message);
    }
    //to generate otp
    GenerateOtp() {
        return Math.floor(1000 + Math.random() * 9000);
    }
    //to generate login token
    generatetocken(length) {
        let posible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        let text = "";
        for (let i = 0; i < length; i++) {
            text += posible.charAt(Math.floor(Math.random() * posible.length));
        }
        return text;

    }
    // set token in table at a time of login 
    SetToken(user_id) {
        let tokan = this.generatetocken(40);
        let updatetokan = "update tbl_device set token=? where user_id=?";

        DataBase.query(updatetokan, [tokan, user_id], (error, result) => {
            if (error) {
                console.log("operation faild", error);
            }
            if (result <= 0) {
                console.log("token in not generated");
            }
            console.log("token generated");

        })
    }
}
module.exports = new common();