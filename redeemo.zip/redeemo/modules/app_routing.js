class routing{
    v1(app){
        let user=require("./v1/user/routes/route");
        user(app);
    }
}
module.exports=new routing();