const constant = require("../../../../config/constant");
const dataBase = require("../../../../config/database");
const common = require("../../../../utilities/common");
const error_code = require("../../../../utilities/error_response");

class mercahntModules {
    async getallpost(requestData, callback) {
        try {
            let data = {
                user_id: requestData.user_id
            }
           let page=common.getpage(requestData.page);
           
           
            let mainresult = {};
            //get user details
            let getuserDetails = "select image,first_name,latitude,longitude,address from tbl_user where id=?";
            let [result] = await dataBase.query(getuserDetails, [data.user_id]);
            if (result.length < 0) {
                mainresult.userDetails = [];
            } else { mainresult.userDetails = result }

            //get category details
            let categoryDetails = "select image,category_name from tbl_category limit ?,?";
            let [category] = await dataBase.query(categoryDetails,[page[0],page[1]]);
            if (category.length < 0) {
                mainresult.categoryDetails = [];
            } else { mainresult.categoryDetails = category }

            // get featured merchant
            let featuredMerchantDetails = "SELECT m.image ,m.logo,m.name,m.rating,m.address,concat(ROUND(( 6371 * ACOS( COS( RADIANS(?) ) * COS( RADIANS( m.latitude ) ) * COS( RADIANS( m.longitude ) - RADIANS(?) ) + SIN( RADIANS(?) ) * SIN( RADIANS( m.latitude ) ) ) ),1),'','Km') as distanse ,CASE WHEN EXISTS(SELECT 1 FROM tbl_favorites_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchants as m ORDER by m.rating DESC limit ?,?;";
            let [feature] = await dataBase.query(featuredMerchantDetails, [result[0].latitude, result[0].longitude, result[0].latitude, data.user_id,page[0],page[1]]);
            if (feature.length < 0) {
                mainresult.featureDetails = [];
            } else { mainresult.featureDetails = feature }

            // get ternding merchant
            let trendingMerchantDetails = "SELECT m.image ,m.logo,m.name,m.rating,m.address,ROUND(( 6371 * ACOS( COS( RADIANS(?) ) * COS( RADIANS( m.latitude ) ) * COS( RADIANS( m.longitude ) - RADIANS(?) ) + SIN( RADIANS(?) ) * SIN( RADIANS( m.latitude ) ) ) ),1) as distanse FROM tbl_merchants as m ORDER by m.rating DESC limit ?,?;";
            let [trending] = await dataBase.query(trendingMerchantDetails, [result[0].latitude, result[0].longitude, result[0].latitude, data.user_id,page[0],page[1]]);
            if (trending.length < 0) {
                mainresult.trendingDetails = [];
            } else { mainresult.trendingDetails = trending }

            //get nearby merchant
            let nearby = "SELECT  c.category_name,m.image ,m.logo,m.name,m.rating,m.address,concat(ROUND(( 6371 * ACOS( COS( RADIANS(?) ) * COS( RADIANS( m.latitude ) ) * COS( RADIANS( m.longitude ) - RADIANS(?) ) + SIN( RADIANS(?) ) * SIN( RADIANS( m.latitude ) ) ) ),1),'','Km') as distance ,CASE WHEN EXISTS(SELECT 1 FROM tbl_favorites_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchants as m  INNER JOIN tbl_category as c on c.id=m.category_id HAVING distance<5 ORDER by m.rating DESC limit ?,?";
            let [near] = await dataBase.query(nearby, [result[0].latitude, result[0].longitude, result[0].latitude, data.user_id,page[0],page[1]]);
            if (near.length < 0) {
                mainresult.nearmerchant = [];
            } else { mainresult.nearmarchant = near }

            if (mainresult.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresult
            })
        } catch (Error) {
            console.log("error in allpost", Error);

            return callback({
                code: error_code.operation_failed,
                keyword: "not aprove",
                data: []
            })
        }
    }
    /* async nearby(requestData, callback) {
         try {
             let data = {
 
             }
             this.getallpost(requestData, (response) => {
                 if (response.code == error_code.success) {
                     data.nearby = response.data.nearmarchant;
                     console.log(data);
 
 
                     return callback({
                         code: error_code.success,
                         keyword: "success",
                         data: data
                     })
                 }
                 return callback(response);
             })
         } catch (Error) {
             return callback({
                 code: error_code.operation_failed,
                 keyword: "operation faild",
                 data: []
             })
         }
     }*/
    // get near by marchants
    async nearby(requestData, callback) {
        try {
            let data = {
                user_id: requestData.user_id
            };
          
            
            let page=common.getpage(requestData.page);
            let mainresult = {};
            // get user details
            let getuserDetails = "select image,first_name,latitude,longitude,address from tbl_user where id=?";
            let [result] = await dataBase.query(getuserDetails, [data.user_id]);
            if (result.length < 0) {
                console.log("user data in not found");
            } else {
                console.log("success");
            }
            // get nearby merchant details
            let nearby = "SELECT  c.category_name,m.image ,m.logo,m.name,m.rating,m.address,concat(ROUND(( 6371 * ACOS( COS( RADIANS(?) ) * COS( RADIANS( m.latitude ) ) * COS( RADIANS( m.longitude ) - RADIANS(?) ) + SIN( RADIANS(?) ) * SIN( RADIANS( m.latitude ) ) ) ),1),'','Km') as distance ,CASE WHEN EXISTS(SELECT 1 FROM tbl_favorites_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchants as m  INNER JOIN tbl_category as c on c.id=m.category_id HAVING distance<2500 ORDER by m.rating DESC limit ?,?";
            let [near] = await dataBase.query(nearby, [result[0].latitude, result[0].longitude, result[0].latitude, data.user_id,page[0],page[1]]);
          //for count a number of rows on result
            /*const [rows] = await data.query("SELECT FOUND_ROWS() AS total_records");
            mainresult.nearyou = rows[0].total_records;*/
            
            if (near.length < 0) {
                mainresult.nearmerchant = [];
            } else { mainresult.nearmarchant = near }

            // final callback
            if (mainresult.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresult
            })

        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.operation_failed,
                keyword: "operation faild",
                data: []
            })
        }
    }
    //get trending merchants
    async trendingMerchant(requestData, callback) {
        try {
            let data = {
                user_id: requestData.user_id
            };
            let page=common.getpage(requestData.page);
            let mainresult = {};
            // get user details
            let getuserDetails = "select image,first_name,latitude,longitude,address from tbl_user where id=?";
            let [result] = await dataBase.query(getuserDetails, [data.user_id]);
            if (result.length < 0) {
                console.log("user data in not found");
            } else {
                console.log("success");
            }
            // get ternding merchant details
            let trendingMerchantDetails = "SELECT m.image ,m.logo,m.name,m.rating,m.address,ROUND(( 6371 * ACOS( COS( RADIANS(?) ) * COS( RADIANS( m.latitude ) ) * COS( RADIANS( m.longitude ) - RADIANS(?) ) + SIN( RADIANS(?) ) * SIN( RADIANS( m.latitude ) ) ) ),1) as distanse FROM tbl_merchants as m ORDER by m.rating DESC limit ?,?;";
            let [trending] = await dataBase.query(trendingMerchantDetails, [result[0].latitude, result[0].longitude, result[0].latitude, data.user_id,page[0],page[1]]);
            if (trending.length < 0) {
                mainresult.trendingDetails = [];
            } else { mainresult.trendingDetails = trending }

            // final callback
            if (mainresult.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresult
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.operation_failed,
                keyword: "operation faild",
                data: []
            })
        }

    }
    async merchantCategory(requestData, callback) {
        try {
            let mainresult = {};
            let page=common.getpage(requestData.page);

            // get ternding merchant details
            let categoryDetails = "select image,category_name from tbl_category limit ?,?";
            let [category] = await dataBase.query(categoryDetails,[page[0],page[1]]);
            if (category.length < 0) {
                mainresult.categoryDetails = [];
            } else { mainresult.categoryDetails = category }

            // final callback
            if (mainresult.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresult
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.operation_failed,
                keyword: "operation faild",
                data: []
            })
        }

    }
    async search(requestData, callback) {
        let search = requestData.search;
        search = search.trim();

        if (search != undefined) {
            let searchMerchant = "select * from tbl_merchants where name like ?"
            let [result] = await dataBase.query(searchMerchant, [`%${search}%`]);
            if (result.length > 0) {
                return callback({
                    code: error_code.success,
                    keyword: "Success",
                    data: result
                })
            }
            let searchCategory = "select * from tbl_category where category_name like ?"
            let [category] = await dataBase.query(searchCategory, [`%${search}%`]);
            if (category.length > 0) {
                return callback({
                    code: error_code.success,
                    keyword: "Success",
                    data: category
                })
            }
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
        return callback({
            code: error_code.no_data_found,
            keyword: "no data found",
            data: []
        })
    }
    async filter(requestData, callback) {
        try {
            let data = {
                sort: requestData.sort,
                category: requestData.category,
                distance: requestData.distance,
                amenities: requestData.amenities
            }
            //fetch user details
            let getuserDetails = "select image,first_name,latitude,longitude,address from tbl_user where id=?";
            let [result] = await dataBase.query(getuserDetails, [requestData.user_id]);

            // fiter merchants
            let nearby = `SELECT  c.category_name,m.image ,m.logo,m.name,m.rating,m.address,concat(ROUND(( 6371 * ACOS( COS( RADIANS(?) ) * COS( RADIANS( m.latitude ) ) * COS( RADIANS( m.longitude ) - RADIANS(?) ) + SIN( RADIANS(?) ) * SIN( RADIANS( m.latitude ) ) ) ),1),'','Km') as distance  FROM tbl_merchants as m  INNER JOIN tbl_category as c on c.id=m.category_id  INNER JOIN tbl_merchant_amenities AS ma ON ma.merchant_id = m.id
INNER JOIN tbl_amenitiies AS a ON a.id = ma.amenities_id where c.category_name=? and a.amenities_name =? HAVING distance<?  ORDER by ? DESC`;
            if (data.category == "all" || data.amenities == "all") {
                if (data.category != "all") {
                    data.category = requestData.category;
                } else {
                    data.category = ['hotels', 'spa', 'Luxe Lounge', 'Coffee Corner', 'salon'];
                }

                if (data.amenities != "all") {
                    data.amenities = requestData.amenities;
                } else {
                    data.amenities = ['aircondition', 'food', 'hanger', 'RestRoom', 'swiming_pool', 'Tv'];
                }
                nearby = `SELECT   DISTINCT c.category_name, m.image, m.logo, m.name, m.rating, m.address, 
              CONCAT(ROUND((6371 * ACOS(COS(RADIANS(?)) * COS(RADIANS(m.latitude)) * 
              COS(RADIANS(m.longitude) - RADIANS(?)) + SIN(RADIANS(?)) * SIN(RADIANS(m.latitude)))), 1), ' Km') AS distance 
              FROM tbl_merchants AS m 
              INNER JOIN tbl_category AS c ON c.id = m.category_id INNER JOIN tbl_merchant_amenities AS ma ON ma.merchant_id = m.id
INNER JOIN tbl_amenitiies AS a ON a.id = ma.amenities_id
              WHERE c.category_name IN (?) and a.amenities_name IN (?)
              HAVING distance < ? 
              ORDER BY ?? DESC`;
                console.log(data.amenities);

            }
            let [demo] = await dataBase.query(nearby, [result[0].latitude, result[0].longitude, result[0].latitude, data.category, data.amenities, data.distance, data.sort]);
            if (demo.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }

            return callback({
                code: error_code.success,
                keyword: "found",
                data: demo
            })

        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.success,
                keyword: "no data found",
                data: []
            })
        }
    }
    async merchantDetails(requestData, type, callback) {
        try {
            let data = {
                id: requestData.merchant_id
            }
            let mainResult = {};

            let userDetails = await common.getUserDetails(requestData.user_id);
            console.log(type);


            let MerchantDetails = "SELECT m.image ,m.logo,m.name,m.rating,m.address,concat(ROUND(( 6371 * ACOS( COS( RADIANS(?) ) * COS( RADIANS( m.latitude ) ) * COS( RADIANS( m.longitude ) - RADIANS(?) ) + SIN( RADIANS(?) ) * SIN( RADIANS( m.latitude ) ) ) ),1),'','Km') as distanse ,CASE WHEN EXISTS(SELECT 1 FROM tbl_favorites_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchants as m  where id=?;";
            let [merchant] = await dataBase.query(MerchantDetails, [userDetails[0].latitude, userDetails[0].longitude, userDetails[0].latitude, userDetails[0].user_id, data.id]);
            if (merchant.length < 0) {
                mainResult.merchantDetails = [];
            } else { mainResult.merchantDetails = merchant }

            if (!type) {
                let voucher = "select * ,CASE WHEN EXISTS (select 1 FROM tbl_voucher_redeem where voucher_id=v.id and user_id=?)THEN 'used' ELSE 'not used' end as redeem_status,CASE WHEN EXISTS (select 1 FROM tbl_favorites_vouchers where voucher_id=v.id and user_id=?)THEN 'liked' ELSE 'not liked' end as like_status from tbl_vouchers as v WHERE expiry >=CURRENT_TIMESTAMP and merchant_id=?;"
                let [result] = await dataBase.query(voucher, [requestData.user_id, requestData.user_id, data.id]);
                if (result.length < 0) {
                    mainResult.voucher = [];
                }
                mainResult.voucher = result;
            }
            else if (type == "about") {
                let about = "select m.description,(SELECT GROUP_CONCAT(s.image) FROM sub_image as s WHERE s.merchant_id=m.id ) as images,(SELECT GROUP_CONCAT(a.amenities_name) FROM tbl_amenitiies as a INNER join tbl_merchant_amenities as ma on ma.amenities_id=a.id WHERE ma.merchant_id=m.id ) as amenities from tbl_merchants as m where id=?";
                let [result] = await dataBase.query(about, [data.id]);
                if (result < 0) {
                    mainResult.about = [];
                }
                mainResult.about = result;
            }
            else if (type == "branches") {
                let about = "select  m.image ,m.logo,m.name,m.rating,m.address,m.opening_time,m.closing_time from tbl_sub_branch as m where m.merchant_id=?";
                let [result] = await dataBase.query(about, [data.id]);
                if (result < 0) {
                    mainResult.about = [];
                }
                mainResult.branches = result;
            }
            else if (type == "rating") {
                let review = "SELECT u.image,u.first_name,r.rating,r.review,r.createdat FROM tbl_rating as r INNER JOIN tbl_user as u on u.id=r.user_id where r.merchant_id=?";
                let [result] = await dataBase.query(review, [data.id]);
                if (result < 0) {
                    mainResult.review = [];
                }
                mainResult.review = result;
            }
            if (mainResult < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainResult
            })

        }
        catch (Error) {
            console.log("error in merchant details", Error);

            return callback({
                code: error_code.operation_failed,
                keyword: "operation faild",
                data: []
            });
        }


    }
    async voucherDetails(requestData, callback) {

        try {
            let data = {
                voucherid: requestData.voucherid
            };
            let voucherDetail = "select * ,CASE WHEN EXISTS(SELECT 1 FROM tbl_favorites_vouchers as fv WHERE fv.voucher_id=v.id and fv.user_id=?)then 'like' ELSE 'not like' end as like_status,CASE WHEN EXISTS(SELECT 1 FROM tbl_voucher_redeem as fv WHERE fv.voucher_id=v.id and fv.user_id=?)then 'redeem' ELSE 'not nedeem' end as redeem_status from tbl_vouchers as v where v.id=?;"
            let [result] = await dataBase.query(voucherDetail, [requestData.user_id, requestData.user_id, data.voucherid]);
            if (result.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            return callback({
                code: error_code.not_approve,
                keyword: "operation faild",
                data: []
            })
        }

    }
    async retingAndReview(requestData, callback) {
        try {
            let data = {
                user_id: requestData.user_id,
                merchant_id: requestData.merchant_id,
                rating: requestData.rating,
                review: requestData.review
            }
            let [check]= await dataBase.query("select * from tbl_rating where merchant_id=? and user_id=?",[data.merchant_id,data.user_id])
            if(check.length<=0){
            let addReting = "insert into tbl_rating set ?";
            let [result] = await dataBase.query(addReting, data);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "review and rating is not added",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        }else{
            return callback({
                code: error_code.not_approve,
                keyword: "you already added review and rating on this merchant",
                data: []
            })
        }
        } catch (Error) {
            return callback({
                code: error_code.not_register,
                keyword: "review and rating is not added",
                data: []
            })
        }
    }
    async favorite(requestData, type, callback) {
        try {
            let favorit = '';
            let data=await common.getUserDetails(requestData.user_id);
            console.log(data[0]);
            
            let [result]='';
            if (!type) {
                favorit = "SELECT m.image, m.name, m.logo, m.address, m.rating ,concat(ROUND(( 6371 * ACOS( COS( RADIANS(?) ) * COS( RADIANS( m.latitude ) ) * COS( RADIANS( m.longitude ) - RADIANS(?) ) + SIN( RADIANS(?) ) * SIN( RADIANS( m.latitude ) ) ) ),1),'','Km') as distance FROM tbl_merchants AS m INNER JOIN tbl_favorites_merchant AS f ON f.merchant_id = m.id WHERE f.user_id = ? limit ?,?";
                 [result] = await dataBase.query(favorit,[data[0].latitude, data[0].longitude, data[0].latitude, requestData.user_id]);
            } else {
                favorit = "SELECT * FROM tbl_vouchers AS m INNER JOIN tbl_favorites_vouchers AS f ON f.voucher_id = m.id WHERE f.user_id = ?";
                [result] = await dataBase.query(favorit,[requestData.user_id]);

               
            }
    
            
    
            // Fix: Proper condition check
            if (result.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "no data found",
                    data: []
                });
            }
            
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            });
    
        } catch (error) { // Fix: Proper error handling
            console.error("Database Error:", error);
    
            return callback({
                code: error_code.operation_failed,
                keyword: "operation failed",
                data: []
            });
        }
    
    }
   
}
module.exports = new mercahntModules;