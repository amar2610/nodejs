const middleware = require("../../../../middleware/validators");
const validationRule = require("../../../../middleware/validation_rules");
const merchant_module = require("../model/merchant_module");

class merchant {
    //get all post
    allPost(req, res) {
        let data = req.body;
        let rule = "";
        let message = {
            required: req.language.required
        }
        let key = {

        }
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.getallpost(data, function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }
    // get nearby marchant
    nearBy(req, res) {
        let data = req.body;
        let rule = "";
        let message = {
            required: req.language.required
        }
        let key = {

        }
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.nearby(data, function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }
    //get trending marchant post
    trendingMerchant(req, res) {
        let data = req.body;
        let rule = "";
        let message = {
            required: req.language.required
        }
        let key = {};
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.trendingMerchant(data, function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }
    merchantCategory(req, res) {
        let data = req.body;
        let rule = "";
        let message = {
            required: req.language.required
        }
        let key = {};
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.merchantCategory(data, function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }
    search(req, res) {
        let data = req.body;
        let rule = validationRule.search;
        let message = {
            required: req.language.required
        }
        let key = {};
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.search(data, function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }
    filter(req, res) {
        let data = req.body;
        let rule = "";
        let message = {
            required: req.language.required
        }
        let key = {};
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.filter(data, function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }

    merchantDetails(req, res) {
        let data = req.body;
        let type=req.params.type;
        let rule = "";
        let message = {
            required: req.language.required
        }
        let key = {};
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.merchantDetails(data,type, function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }

    voucherDetails(req, res) {
        let data = req.body;
        let rule = "";
        let message = {
            required: req.language.required
        }
        let key = {};
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.voucherDetails(data, function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }
    addreviewAndRating(req, res) {
        let data = req.body;
        let rule = validationRule.retreview;
        console.log(rule);
        
        let message = {
            required: req.language.required
        }
        let key = {};
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.retingAndReview(data, function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }
    favorites(req, res) {
        let data = req.body;
        let type=req.params.type;
        let rule = "";
        let message = {
            required: req.language.required
        }
        let key = {};
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rule, message, key)) {
            merchant_module.favorite(data, type,function (response_data) {
                middleware.send_response(req, res, response_data)
            })
        }
    }
}
module.exports = new merchant();