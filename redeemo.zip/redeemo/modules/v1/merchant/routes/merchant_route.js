const merchant=require("../../merchant/controller/merchant");
let express=require("express");
let router=express.Router();

router.get("/v1/merchant/allpost",merchant.allPost);
router.get("/v1/merchant/nearby",merchant.nearBy);
router.get("/v1/merchant/search",merchant.search);
router.get("/v1/merchant/filter",merchant.filter);
router.post("/v1/merchant/addreviewandrating",merchant.addreviewAndRating);

router.get("/v1/merchant/voucherdetails",merchant.voucherDetails);

router.get("/v1/merchant/merchantdetails/:type?",merchant.merchantDetails);
router.get("/v1/merchant/favorite/:type?",merchant.favorites);




router.get("/v1/merchant/category",merchant.merchantCategory);
router.get("/v1/merchant/trendingmerchant",merchant.trendingMerchant);


module.exports=router;