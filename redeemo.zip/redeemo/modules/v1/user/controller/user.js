const { required } = require("../../../../language/en");
let validationRule=require("../../../../middleware/validation_rules");
const middleware = require("../../../../middleware/validators");
const user_module = require("../model/user_module");
class user{

    signUP(req,res){
        let data=req.body;
        let type=req.params.type;
        let rules=validationRule.signUp
        let message={
            required:req.language.required
        }
        let key={

        }
        if(!type){
        if(middleware.checkValidationRules(req,res,data, rules,message,key)){
            
            user_module.adduser(data,type,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        }else{
            rules="";
            if(middleware.checkValidationRules(req,res,data, rules,message,key)){
            
                user_module.adduser(data,type,function(_respons){
                    middleware.send_response(req,res,_respons);
                })
            }
        }
    }
    EditProfile1(req,res){
        let data=req.body;
      
        let rules=validationRule.EditProfile
        let message={
            required:req.language.required
        }
        let key={

        }
        data.user_id=req.user_id;
        if(middleware.checkValidationRules(req,res,data, rules,message,key)){
            user_module.EditProfile(data,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
    Profile(req,res){
        
        let data=req.body;
        let rules=validationRule.completProfile;
        let message={
            required:req.language.required
        }
        let key={

        }
        data.user_id=req.user_id;
        
        if(middleware.checkValidationRules(req,res,data,rules,message,key)){
            user_module.Profile(data,function(_respons){
                
                middleware.send_response(req,res,_respons);
            })
        }
    }
    verifyOtp(req,res){
        let data=req.body;
        let rules=validationRule.verifyOtp;
        let message={
            required:req.language.required
        }
        let key={

        }
        if(middleware.checkValidationRules(req,res,data,rules,message,key)){
            user_module.verifyOtp(data,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
    logIN(req,res){
        let data=req.body;
        let rules=validationRule.login;
        let message={
            required:req.language.required
        }
        let key={
        
        }
        if(middleware.checkValidationRules(req,res,data,rules,message,key)){
            user_module.logIn(data,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
    addInterest(req,res){
        let data=req.body;
        let rules=validationRule.addInterest;
        let message={
            required:req.language.required
        }
        let key={
        
        }
        data.user_id=req.user_id;
        console.log(data);
        
        if(middleware.checkValidationRules(req,res,data,rules,message,key)){
            user_module.addinterest(data,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
    forgotPassword(req,res){
        let data=req.body;
        let rules="";
        let message={
            required:req.language.required
        }
        let key={
        
        }
        console.log(data);
        
        if(middleware.checkValidationRules(req,res,data,rules,message,key)){
            user_module.forgotPassword(data,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
    resetPassword(req,res){
        let data=req.body;
        let rules="";
        let message={
            required:req.language.required
        }
        let key={
        
        }
        console.log(data);
        
        if(middleware.checkValidationRules(req,res,data,rules,message,key)){
            user_module.resetPassword(data,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
    changePassword(req,res){
        let data=req.body;
        let rules=validationRule.changePassword;
        let message={
            required:req.language.required
        }
        let key={
        
        }
        console.log(data);
        data.user_id=req.user_id;
        
        if(middleware.checkValidationRules(req,res,data,rules,message,key)){
            user_module.changePassword(data,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
    editInterest(req,res){
        let data=req.body;
        let rules=validationRule.addInterest;
        let message={
            required:req.language.required
        }
        let key={
        
        }
        console.log(data);
        data.user_id=req.user_id;
        
        if(middleware.checkValidationRules(req,res,data,rules,message,key)){
            user_module.editInterest(data,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
    logOut(req,res){
        let rules="";
        let message={
            required:req.language.required
        }
        let key={
        
        }
       let user_id=req.user_id;
        console.log(user_id);
        
        if(middleware.checkValidationRules(req,res,user_id,rules,message,key)){
            user_module.logOut(user_id,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
    deleteAccount(req,res){
        let rules="";
        let data=req.body;
        let message={
            required:req.language.required
        }
        let key={
        
        }
       data.user_id=req.user_id;
        
        if(middleware.checkValidationRules(req,res,data,rules,message,key)){
            user_module.deleteAccount(data,function(_respons){
                middleware.send_response(req,res,_respons);
            })
        }
        
    }
}
module.exports=new user();