const user = require("../controller/user");
const express = require('express');
const router = express.Router();


    router.post("/v1/user/login",user.logIN);
   router.post("/v1/user/signup/:type?",user.signUP);
    router.post("/v1/user/editprofile",user.Profile);
    router.post("/v1/user/Editprofile1",user.EditProfile1);
    router.post("/v1/user/editinterest",user.editInterest);


    
    router.post("/v1/user/logout",user.logOut);
    router.post("/v1/user/deleteaccount",user.deleteAccount);


    router.post("/v1/user/forgotpassword",user.forgotPassword);
    router.post("/v1/user/resetpassword",user.resetPassword);
    router.post("/v1/user/changepassword",user.changePassword);


    router.post("/v1/user/addinterest",user.addInterest);
    router.post("/v1/user/otpverification",user.verifyOtp);


module.exports=router;