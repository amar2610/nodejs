let dataBase = require("../../../../config/database");
const { email } = require("../../../../language/en");
let common = require("../../../../utilities/common");
const error_code = require("../../../../utilities/error_response");

class userModule {
    id = 0;
    async adduser(requireData, type, callback) {
        try {


            let devicedata = {
                device_token: requireData.device_token,
                device_type: requireData.device_type,
                os_type: requireData.os_type,
                app_version: requireData.app_version
            };
            if (!type) {
                let data = {
                    email: requireData.email,
                    phone: requireData.phone,
                    password: requireData.password
                };
                let checkemail_phone = "SELECT * FROM tbl_user WHERE phone = ? OR email = ?";
                let [check] = await dataBase.query(checkemail_phone, [data.phone, data.email]);

                if (check.length > 0) {
                    return callback({
                        code: error_code.data_already_exist,
                        keyword: "rest_keywords_unique_email_error"
                    });
                }

                console.log("user module");

                let insert = "INSERT INTO tbl_user SET ?";
                let [result] = await dataBase.query(insert, data);

                if (!result.insertId) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "data not inserted"
                    });
                }
                let otpdata = {
                    user_id: result.insertId,
                    email: requireData.email,
                    phone: requireData.phone,
                    otp: common.GenerateOtp()
                }
                let generateOtp = "INSERT INTO tbl_otp SET ?";
                await dataBase.query(generateOtp, otpdata);
                devicedata.user_id = result.insertId;


            } else {

                let data = {
                    type: type,
                    social_id: common.generatetocken(5),
                    step_count: 4
                }
                let insert = "INSERT INTO tbl_user SET ?";
                let [result] = await dataBase.query(insert, data);
                devicedata.user_id = result.insertId;
                devicedata.token = common.generatetocken(5);
                console.log(devicedata.token);

                if (!result.insertId) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "data not inserted"
                    });
                }

            }



            let deviceinfo = "INSERT INTO tbl_device SET ?";
            await dataBase.query(deviceinfo, devicedata);


            return callback({
                code: error_code.success,
                keyword: "data inserted"
            });

        } catch (error) {
            console.error("Error in adduser:", error);
            return callback({
                code: error_code.server_error,
                keyword: "internal_server_error"
            });
        }
    }
    async Profile(requireData, callback) {

        try {
            let data = {
                id: requireData.user_id,
                first_name: requireData.first_name,
                last_name: requireData.last_name,
                address: requireData.address,
                gender: requireData.gender,
                image: requireData.image,
                latitude: requireData.latitude,
                longitude: requireData.longitude,
                step_count: 3
            }
            console.log(data.id);

            let check = "select * from tbl_user where id=? and is_delete=0 and is_active=1";
            let [checkstatus] = await dataBase.query(check, [data.id]);
            console.log(checkstatus[0]);

            if (checkstatus[0].step_count == 2) {

                let editProfile = "update tbl_user set? where id=?";
                let [result] = await dataBase.query(editProfile, [data, data.id]);

                if (result.length < 0) {
                    return callback({
                        code: error_code.server_error,
                        keyword: "internal_server_error",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "Success",
                    data: []
                })
            } else {
                return callback({
                    code: error_code.otp_not_veryfied,
                    keyword: "first verify your phone or email",
                    data: []
                })
            }

        } catch (Error) {
            console.error("Error in updateProile:", Error);
            return callback({
                code: error_code.not_register,
                keyword: "internal_server_error",
                data: []
            });
        };
    }
    async verifyOtp(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                phone: requireData.phone,
                otp: requireData.otp
            }
            console.log(data);

            let verify = "select * from tbl_otp where phone=? and otp=? and is_verify=0"
            let [is_verify] = await dataBase.query(verify, [data.phone, data.otp]);
            console.log(is_verify[0]);

            if (is_verify.length === 0) {
                return callback({
                    code: error_code.otp_not_veryfied,
                    keyword: "otp is not verify",
                    data: []
                })
            }
            await dataBase.query("update tbl_otp set is_verify=1 where user_id=?", data.user_id);
            common.SetToken(requireData.user_id);
            let update = "update tbl_user set step_count=2 where id=?";
            let [updateuser] = await dataBase.query(update, [requireData.user_id]);
            if (updateuser.length > 0) {
                console.log("user update");

            }
            return callback({
                code: error_code.success,
                keyword: "otp is verify"
            })

        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "internal_server_error in otp verification",
                data: []
            })
        }
    }
    async logIn(requireData, callback) {
        let data = {
            type: requireData.typeoflogin
        }
        if (data.type == 's') {
            data.password = requireData.password;
            data.identifier = requireData.email ? requireData.email : requireData.phone
            let check = "select * from tbl_user where (phone=? or email=?) and password=? and is_delete=0 and is_active=1";
            let [result] = await dataBase.query(check, [requireData.phone, requireData.email, data.password]);
            console.log(result[0]);

            if (result.length <= 0) {
                console.log("data not found");
                return callback({
                    code: error_code.not_register,
                    keyword: "user not found",
                    data: []
                })
            }
            if (result[0].step_count == 1) {
                return callback({
                    code: error_code.not_register,
                    content: { username: result[0].first_name },
                    keyword: "not_verified",
                })
            }
            if (result[0].step_count == 2) {
                return callback({
                    code: error_code.not_register,

                    keyword: "complete your profile first",
                })
            } if (result[0].step_count == 3) {
                return callback({
                    code: error_code.not_register,

                    keyword: "select your interest",
                })
            }

            common.SetToken(result[0].id);
            return callback({
                code: error_code.not_register,
                content: { username: result[0].first_name },
                keyword: "login_success",
            })
        }
        else {

            let check = "select * from tbl_user where social_id=? and type=? and is_delete=0 and is_active=1";
            let [result] = await dataBase.query(check, [requireData.social_id,data.type]);
            console.log(result[0]);

            if (result.length <= 0) {
                console.log("data not found");
                return callback({
                    code: error_code.not_register,
                    keyword: "user not found",
                    data: []
                })
            }
            common.SetToken(result[0].id);
            return callback({
                code: error_code.not_register,
                content: { username: result[0].first_name },
                keyword: "login_success",
            })
        }
    }
    async addinterest(requestData, callback) {
        try {
            let data = {
                user_id: requestData.user_id,
                interest: requestData.interest
            };

            // Validate user existence
            let [step_count] = await dataBase.query("SELECT * FROM tbl_user WHERE id=? and is_delete=0 and is_active=1", [data.user_id]);

            if (!step_count.length) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "User not found"
                });
            }

            if (step_count[0].step_count === '3') {
                // Validate interest input
                if (!data.interest || data.interest.trim() === '') {
                    return callback({
                        code: error_code.invalid_input,
                        keyword: "Interest list cannot be empty"
                    });
                }

                let interestArray = data.interest.split(',');

                let addinterests = "INSERT INTO tbl_user_interest SET ?";

                for (let i = 0; i < interestArray.length; i++) {
                    let fetchid = "SELECT id FROM tbl_interest WHERE interest LIKE ?";
                    console.log(interestArray[i]);

                    let [insert] = await dataBase.query(fetchid, [interestArray[i]]);

                    // Ensure interest exists in tbl_interest
                    if (!insert || insert.length === 0) {
                        console.log(`Interest "${interestArray[i]}" not found in tbl_interest`);
                        return callback({
                            code: error_code.no_data_found,
                            keyword: `Interest "${interestArray[i]}" not found`
                        });
                    }

                    let interstdata = {
                        user_id: requestData.user_id,
                        interest_id: insert[0].id
                    };

                    await dataBase.query(addinterests, [interstdata]);
                    await dataBase.query("update tbl_user set  step_count=4 where id=?", [interstdata.user_id]);
                }

                return callback({
                    code: error_code.success,
                    keyword: "Interest added successfully"
                });

            } else {
                return callback({
                    code: error_code.not_register,
                    keyword: "Complete your profile first"
                });
            }

        } catch (Error) {
            console.log("Error in addinterest:", Error);
            return callback({
                code: error_code.operation_failed,
                keyword: "Something went wrong"
            });
        }
    }
    async forgotPassword(requireData, callback) {
        try {

            let email = requireData.email;

            let CheckEmail = "select * from tbl_user where email=? and is_delete=0 and is_active=1";
            let [result] = await dataBase.query(CheckEmail, email);

            if (result <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "email id is not found"
                })
            }
            this.id = result[0].id;


            this.GenerateOtp(result[0])
            return callback({
                code: error_code.success,
                keyword: "otp sent to your device"
            })


        } catch (error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form", Error
            });
        }
    }
    GenerateOtp(RequireData) {
        let Data = {
            otp: common.GenerateOtp(),
            user_id: this.id,
            phone: RequireData.phone,
            email: RequireData.email,
        }

        let OtpQuery = "insert into tbl_otp set ?"
        dataBase.query(OtpQuery, Data, (result) => {
            console.log("hello");

            if (!result || result === 0) {
                return 0;
            }
            return 1;
        });

    }
    async resetPassword(RequireData, callback) {
        try {
            let data = {
                id: RequireData.user_id,
                password: RequireData.password
            };

            let updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";

            let [result] = await dataBase.query(updatePasswordQuery, [data.password, data.id]);

            if (result.length <= 0) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "password not changed"
                });
            }

            return callback({
                code: error_code.success,
                keyword: "password changed"
            });

        } catch (error) {
            console.error("Error in ResetPassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form"
            });
        }
    }
    async changePassword(RequireData, callback) {
        try {


            let oldPassword = RequireData.old_password;
            let newPassword = RequireData.new_password;

            let checkPasswordQuery = "SELECT * FROM tbl_user WHERE id=? and is_delete=0 and is_active=1";

            let [result] = await dataBase.query(checkPasswordQuery, [RequireData.user_id]);
            console.log(result[0]);

            if (!result.length) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "User not found"
                });
            }

            let dbPassword = result[0].password;

            // Check if old password matches
            if (dbPassword !== oldPassword) {
                return callback({
                    code: error_code.invalid_input,
                    keyword: "Old password does not match"
                });
            }


            if (newPassword === dbPassword) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Old password and new password cannot be the same"
                });
            }


            let updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";
            let [updateResult] = await dataBase.query(updatePasswordQuery, [newPassword, RequireData.user_id]);

            if (updateResult.affectedRows <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "Password not changed"
                });
            }

            return callback({
                code: error_code.success,
                keyword: "Password changed successfully"
            });

        } catch (error) {
            console.error("Error in ChangePassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "Enter proper values in the form"
            });
        }
    }
    async logOut(RequireData, callback) {
        let data = {
            user_id: RequireData
        }
        console.log(data);

        let logout = "update tbl_device set token='' where user_id=?";
        let result = await dataBase.query(logout, [data.user_id]);
        if (result.length < 0) {
            return callback({
                code: error_code.operation_failed,
                keyword: "logout_invalid",

            })
        }
        return callback({
            code: error_code.success,
            keyword: "log-out successfuly"
        })
    }
    async deleteAccount(RequireData, callback) {
        let data = {
            user_id: RequireData.user_id,
            password: RequireData.password
        }
        let check = "update tbl_user set is_delete=1 where id=? and password=?";
        let result = dataBase.query(check, [data.user_id, data.password]);
        if (result < 0) {
            return callback({
                code: error_code.not_approve,
                keyword: "account is not deleted"
            })
        }
        return callback({
            code: error_code.success,
            keyword: "account deleted successfuly"
        })

    }
    async EditProfile(requestData, callback) {
        let data = {
            image: requestData.image,
            first_name: requestData.first_name,
            last_name: requestData.last_name,
            address: requestData.address,
            phone: requestData.phone,
            dob: requestData.dob,
            gender: requestData.gender,

        }
        let [result] = await dataBase.query("update tbl_user set ? where id=?", [data, requestData.user_id]);
        if (result.length < 0) {
            return callback({
                code: error_code.not_register,
                keyword: "profile not updated",
                data: []
            })
        }
        return callback({
            code: error_code.success,
            keyword: "profile updated",
            data: result
        })
    }
    async editInterest(requestData, callback) {
        let data = {
            interest: requestData.interest
        }
        let interestArray = data.interest.split(',');
        if (interestArray.length > 0) {
            dataBase.query("delete from tbl_user_interest where user_id='" + requestData.user_id + "'");
        }
        // let addinterests = "INSERT INTO tbl_user_interest SET ?";
        for (let i = 0; i < interestArray.length; i++) {

            let fetchid = "SELECT id FROM tbl_interest WHERE interest LIKE ?";
            console.log(interestArray[i]);

            let [insert] = await dataBase.query(fetchid, [interestArray[i]]);


            let interstdata = {
                user_id: requestData.user_id,
                interest_id: insert[0].id
            };

            await dataBase.query("INSERT INTO tbl_user_interest SET ?", [interstdata]);
            console.log(insert[0]);
        }

        return callback({
            code: error_code.success,
            keyword: "Interest update successfully"
        });
    }




}

module.exports = new userModule();
