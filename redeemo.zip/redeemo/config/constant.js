const constant={
    itemPerPage:3,
}
module.exports=constant;