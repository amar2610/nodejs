let mysql=require("mysql2/promise");
let credential={};
credential={
    host:"localhost",
    user:"root",
    password:"",
    database:"db_redeemo",
    dateString:"date",
    port:3304
}
try{
    let dataBase=mysql.createPool(credential);
    if(dataBase){
        console.log("is connected");
    }else{
        console.log("not connected");
        
    }
    module.exports=dataBase;
}catch(error){
    console.log("database is not connected",error);
    
}