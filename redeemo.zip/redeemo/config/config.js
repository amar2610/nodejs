let env={
    is_production:true,
    server_listner:3035,
    version:"1.0.0",
    api_key:"redeemo"
};
 module.exports=env;