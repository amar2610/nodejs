
const checkValidationRules = {
    login: {
      typeoflogin:"required",
    },
    signUp: {

        email: "required|email",
        phone: "required|string|min:10|regex:/^[0-9]+$/",
        password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]

    },
    completProfile: {

        first_name: "required",
        last_name: "required",
        dob: "required",
        gender: "required",
        address: "required",
        image: "required",
        latitude: "required",
        longitude: "required",
        dob: [
            "required",
            "regex:/^(19[0-9]{2}|20[0-2][0-9])-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/"
        ]
    },
    verifyOtp: {
        phone: "required",
        otp: "required"
    },
    addPost: {
        description: "required",
        category: "required",
        expiry: "required",
        type: "required",
        image: "required"
    },
    resetPassword: {

        password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]

    },
    changePassword: {

        old_password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"],
        new_password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]

    },
    addcomment: {
        user_id: "required",
        post_id: "required",
        comment: "required"
    },
    addInterest: {

        interest: "required"
    },
    EditProfile: {
        first_name: "required",
        last_name: "required",
        dob: "required",
        phone: "required",
        gender: "required",
        address: "required",
        image: "required",
        dob: [
            "required",
            "regex:/^(19[0-9]{2}|20[0-2][0-9])-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/"
        ]
    },
    search:{
        search:"required"
    },
    retreview:{
        review:"required",
        merchant_id:"required",
        rating:"required"
    }
}
module.exports = checkValidationRules
