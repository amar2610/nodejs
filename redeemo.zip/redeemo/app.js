let express=require("express");
let Config=require("./config/config");
let app_rouring=require("./modules/app_routing");
let app=express();
const userroutes=require("./modules/v1/user/routes/route");
const mercahnt=require("../redeemo/modules/v1/merchant/routes/merchant_route")
app.use(express.json());
app.use('/',require('../redeemo/middleware/validators').extractHeaderLanguage);
app.use('/',require('../redeemo/middleware/validators').validatorApikey);
app.use('/',require('../redeemo/middleware/validators').validatorHeaderToken);
app.use(require('../redeemo/modules/v1/user/routes/route'));
app.use(mercahnt);
app.use(userroutes);

app.listen(Config.server_listner,()=>{
    console.log("server Running on.."+Config.server_listner);
    
})
