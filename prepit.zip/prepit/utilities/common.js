const database = require("../config/databse");
const DataBase = require("../config/databse");
const process = require('../config/config');
let cryptlip = require("cryptlib");
let Math = require("math");


class common {
    Response(res, message) {
        res.json(message);
    }
    //to generate otp
    GenerateOtp() {
        return Math.floor(1000 + Math.random() * 9000);
    }
    //to generate login token
    generatetocken(length) {
        let posible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        let text = "";
        for (let i = 0; i < length; i++) {
            text += posible.charAt(Math.floor(Math.random() * posible.length));
        }
        return text;

    }
    encryptPlain(data) {
        return cryptlip.encrypt(JSON.stringify(data), process.encryptionKey, process.encryptionIV)
    }
    decryptPlain(data) {
        return cryptlip.decrypt(data, process.encryptionKey, process.encryptionIV)
    }
    // set token in table at a time of login 
    SetToken(user_id) {
        let tokan = this.generatetocken(40);
        let updatetokan = "update tbl_device set token=? where user_id=?";

        DataBase.query(updatetokan, [tokan, user_id], (error, result) => {
            if (error) {
                console.log("operation faild", error);
            }
            if (result <= 0) {
                console.log("token in not generated");
            }
            console.log("token generated");

        })
    }
    async getStepCount(user_id) {
        let [result] = await database.query("select * from tbl_user where id=?", [user_id]);
        if (result.length <= 0) {
            return 0;
        }
        return result[0].step_count;
    }
    calculateStartingEndDate(duration) {
        let currentDate = new Date(); // Get current date
        let ending_date = new Date();
        const starting_date = currentDate.toISOString().split('T')[0];
        ending_date.setDate(ending_date.getDate() + duration); // Add 30 days

        const endingDate = ending_date.toISOString().split('T')[0];
        return [starting_date, endingDate]; // Return as YYYY-MM-DD
    }
    async mealDetails(meal_id) {

        let [result] = await database.query("select * from tbl_meal where id=?", [meal_id]);
        let [time] = await database.query("select * from tbl_category where id=?", [result[0].catagory_id]);
        //  console.log(time[0]);

        //console.log(await this.timeDifference(time[0].time,result[0].day));

        let hours = (await this.timeDifference(time[0].time, result[0].day));
        console.log(hours);

        if (hours.hours > 6 && hours.days < 6) {
            return true;
        }
        else {
            return false;
        }
    }

    async timeDifference(time, day) {
        const now = new Date();
        const [hours, minutes, seconds] = time.split(':').map(Number);

        const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

        const currentDayIndex = now.getDay(); // 0-6 (Sunday-Saturday)
        const targetDayIndex = daysOfWeek.indexOf(day);

        if (targetDayIndex === -1) {
            throw new Error("Invalid day name. Use full day names, e.g., 'Wednesday'.");
        }

        // Calculate days to add to reach the next target weekday
        let daysToAdd = targetDayIndex - currentDayIndex;
        if (daysToAdd <= 0) {
            daysToAdd += 7; // Move to the next week's target day
        }

        // Set the future date to the next "targetDayName"
        const givenDate = new Date(now);
        givenDate.setDate(now.getDate() + daysToAdd);

        givenDate.setHours(hours, minutes, seconds, 0);

        const diffMilliseconds = givenDate - now;

        const diffHours = Math.floor(diffMilliseconds / (1000 * 60 * 60));
        const diffDays = Math.floor(diffMilliseconds / (1000 * 60 * 60 * 24));
        console.log(diffDays);

        return {
            days: diffDays,
            hours: diffHours % 24,

        };
    }
    async checkitemtime(meal_id,date){
        console.log(meal_id);
        
        let[result]=await database.query("select * from tbl_meal as m inner join tbl_category as c on c.id=m.catagory_id where m.id=?",[meal_id]);
        let difference= await this.getTimeDifferenc(date,result[0].time);
        console.log(difference);
        if(difference.hours>6|| difference.day>1){
            return true
        }
        return false
        
    }
    async getTimeDifferenc(date,time) {
        const targetDate = new Date(date); // Your specific date
        const currentTime = new Date(); // Current date and time
        const [hours, minutes, seconds] = time.split(':').map(Number); // Extract time parts

        targetDate.setHours(hours, minutes, seconds || 0, 0); 
        
        console.log(`Merged DateTime: ${targetDate}`);
        const diffMs =  targetDate.getTime()-currentTime.getTime(); // Difference in milliseconds
        const diffSeconds = Math.floor(diffMs / 1000);
        const diffMinutes = Math.floor(diffSeconds / 60);
        const diffHours = Math.floor(diffMinutes / 60);
        const diffDays = Math.floor(diffHours / 24);

        return {
            day: diffDays,
            hours: diffHours
        }

    }
    async getUserDetails(user_id) {
        let [result] = await database.query("select * from tbl_user where id=?", [user_id]);
        if (result.length <= 0) {
            return [];
        }
        return result;
    }
    async getDistance(id) {

        let [distance] = await database.query(`select ROUND(( 6371 * ACOS( COS( RADIANS(d.latitude) )  
		* COS( RADIANS( 23.128916 ) ) 
		* COS( RADIANS(72.544657) - RADIANS(d.longitude) )  
		+ SIN( RADIANS(d.latitude) )  
		* SIN( RADIANS( 23.128916 ) ) ) ),1) as distance from tbl_delivery_address as d where id=?`, [id]);
        if (distance.length <= 0) {
            return 0;
        }
        return distance[0].distance;
    }
    async gettotalUser() {
        let [result] = await database.query("select count(*) as total_users from tbl_user");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
    async gettotalorder() {
        let [result] = await database.query("select count(*) as total_orders from tbl_order");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
    async gettotalplan() {
        let [result] = await database.query("select count(*)as total_plan from tbl_subscription_plane");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
    async gettotalPendingOrder() {
        let [result] = await database.query("select count(*) as pendingOrders from tbl_order where status not like'Completed'");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
    async gettotalCompletedOrder() {
        let [result] = await database.query("select count(*)as completedOrders from tbl_order where status  like'Completed'");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
}
module.exports = new common();