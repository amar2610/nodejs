var message = {
    "required": ":attr ફીલ્ડ આવશ્યક છે",
    "email": "મહેરબાની કરી માન્ય :attr દાખલ કરો",
    "rest_keywords_required_message": "કૃપા કરીને :attr",
    "rest_keywords_unique_email_error": "હે { username } ! આ ઈમેલ પહેલેથી જ ઉપયોગમાં છે.",
    "rest_keywords_something_went_wrong": "કંઈક ખોટું થયું { username }",
    "rest_keywords_success": "સફળતા",
    "not_verified": "Hmm your mobile number/email has not yet been verified",
    "login_invalid_credential": "Invalid credentials",
    "logout_invalid": "Not logout Yet",
    "login_success": "લૉગિન સફળ થયું! સ્વાગત છે { username }",
    "header_key_value_incorrect": "Unauthorized access of api, invalid value for api key",
    "header_authorization_token_error": "Unauthorized access of api, Invalid authorization token please check you request",
    "no_data_found": "No data found",
    "data_found": "Data found",
    
    "rest_keywords_password":'password'
}

module.exports = message;