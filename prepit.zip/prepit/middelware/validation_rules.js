const checkValidationRules = {
    login: {
      password:"required",
      latitude:"required",
      longitude:"required",
      deviceType:"required"
    },
    adminlog:{
        email:"required|email",
        password:"required",
        deviceType:"required"
    },
    addmeal:{
        meal_name: "required",
        image: "required",
        kcal: "required",
        carbs: "required",
        protein:"required",
        fat: "required",
        description: "required",
        ingredients: "required",
        catagory_id: "required",
        day: "required",
    },
    mealDetail:{
        meal_id:"required"
    },
    signUp: {
        name:"required",
        email: "required|email",
        phone: "required|digits:10",
        password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]

    },
    help:{
        full_name:"required",
        email: "required|email",
        phone: "required|digits:10",
        description:"required"
    },
    contactus:{
        first_name:"required",
        last_name:"required",
        email: "required|email",
        subject: "required",
        description:"required"
    },
   
    completProfile: {
        weight: "required",
        target_weight: "required",
        gender: "required",
        height: "required",
        physical_activity: "required",
        dob: [
            "required",
            "regex:/^(19[0-9]{2}|20[0-2][0-9])-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/"
        ]
    },
    setlocation:{
        latitude:"required",
        longitude:"required",
        address:"required",
    },
    setgoal:{
        goal_id:"required",
    },
    verifyOtp: {

        otp: "required"
    },
    addPost: {
        description: "required",
        category: "required",
        expiry: "required",
        type: "required",
        image: "required"
    },
    resetPassword: {
        user_id:"required",
        password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]

    },
    changePassword: {

        old_password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"],
        new_password: ["required", "regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/"]

    },
    addcomment: {
        user_id: "required",
        post_id: "required",
        comment: "required"
    },
    addInterest: {

        interest: "required"
    },
    EditProfile: {
        first_name: "required",
        last_name: "required",
        dob: "required",
        phone: "required",
        gender: "required",
        address: "required",
        image: "required",
        dob: [
            "required",
            "regex:/^(19[0-9]{2}|20[0-2][0-9])-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/"
        ]
    },
    search:{
        search:"required"
    },
    retreview:{
        review:"required",
        merchant_id:"required",
        rating:"required"
    },
    plan:{
        plan_name:"required",
        duration:"required",
        description:"required",
        price:"required",
    }
}
module.exports = checkValidationRules
