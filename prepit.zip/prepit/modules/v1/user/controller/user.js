let userModule = require("../module/user_module");
const middleware = require("../../../../middelware/validation");
let validation_rules = require("../../../../middelware/validation_rules");
const common = require("../../../../utilities/common");
class user {
    singUp(req, res) {

        let data = JSON.parse(common.decryptPlain(req.body));
        let rules = validation_rules.signUp;
        let message = {
            required: req.language.required,
        }
        let key = {}
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.signUp(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    logIn(req, res) {
        try {
            let data = JSON.parse(common.decryptPlain(req.body));

            let rules = validation_rules.login;
            let message = {
                reauired: req.reauired
            }

            let keyword = {};
            if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
                userModule.logIn(data, function (_respons) {
                    middleware.send_response(req, res, _respons);
                })
            }
        } catch (Error) {
            res.status(401);
            res.send(common.encryptPlain("data is required"));
        }
    }
    otpVerify(req, res) {
        let data = JSON.parse(common.decryptPlain(req.body));
        let rules = validation_rules.verifyOtp;
        let message = {
            reauired: req.reauired
        }
        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.otpVerification(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    async completeProfile(req, res) {
        let data = JSON.parse(common.decryptPlain(req.body));
        data.user_id = req.user_id;
        let rules = "";
        let step_count = await common.getStepCount(req.user_id);
        data.step_count = step_count;
        if (step_count == 4) {
            rules = validation_rules.completProfile;
        } else if (step_count == 2) {
            rules = validation_rules.setlocation;
        } else if (step_count == 3) {
            rules = validation_rules.setgoal;
        }
        let message = {
            reauired: req.reauired
        }

        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.completProfile(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    forgotPassword(req, res) {
        let data = JSON.parse(common.decryptPlain(req.body));
        let rules = "";
        let message = {
            reauired: req.reauired
        }
        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.forgotPassword(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    resetPassword(req, res) {
        let data = JSON.parse(common.decryptPlain(req.body));
        let rules = validation_rules.resetPassword;
        let message = {
            reauired: req.reauired
        }
        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.resetPassword(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    changePassword(req, res) {
        let data = JSON.parse(common.decryptPlain(req.body));
        let rules = validation_rules.changePassword;
        let message = {
            reauired: req.reauired
        }
        data.user_id = req.user_id;
        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.changePassword(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    addToCart(req, res) {
        let data = "";
        if (req.body != "") {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.addtocart(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    placeOrder(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.placeOrder(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayAllmeal(req, res) {
        let data = "";
        if (req.body != "") {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let type = req.params.type;
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayAllMeal(data, type, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayMealDetails(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = validation_rules.mealDetail;
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayMealDetails(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displaykcalary(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displaykcalry(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayOrderDetails(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayOrderDetails(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayOrders(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayOrders(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayaddress(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayAddress(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displaySubscriptionPlane(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displaySubscriptionPlane(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    selectSubscriptionPlane(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.selectSubscriptionPlane(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    addDeliveryaddress(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = validation_rules.setlocation;
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.addDeliveryAddress(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    helpAndSupport(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = validation_rules.help;
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.helpAndSupport(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    contactUs(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = validation_rules.contactus;
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.contactUs(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    displayNotification(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.displayNotification(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    aboutUs(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.aboutUs(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    termAndCondition(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.termAndCondition(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    privacyPolicy(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.privacyPolicy(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
    report(req, res) {
        let data = req.body;
        if (Object.keys(data).length != 0) {
            data = JSON.parse(common.decryptPlain(req.body));
        }
        let rules = "";
        let message = {
            required: req.language.required,
        }
        let key = {}
        data.user_id = req.user_id;
        if (middleware.checkValidationRules(req, res, data, rules, message, key)) {
            userModule.report(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
}

module.exports = new user();