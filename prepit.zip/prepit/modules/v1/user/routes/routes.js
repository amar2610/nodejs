let user=require("../controller/user");
let CustomeRoute=(app)=>{
    app.post("/v1/user/signup",user.singUp);
    app.post("/v1/user/login",user.logIn);
    app.post("/v1/user/otpverification",user.otpVerify);
    app.post("/v1/user/completeprofile",user.completeProfile);
    app.post("/v1/user/forgotpassword",user.forgotPassword);
    app.post("/v1/user/resetpassword",user.resetPassword);
    app.post("/v1/user/changepassword",user.changePassword);
    app.post("/v1/user/addtocart",user.addToCart);
    app.post("/v1/user/placeorder",user.placeOrder);
    app.post("/v1/user/displayallmeal/:type?",user.displayAllmeal);
    app.post("/v1/user/displaymealdetails",user.displayMealDetails);
    app.post("/v1/user/displayorderdetails",user.displayOrderDetails);
    app.post("/v1/user/displayorders",user.displayOrders);
    app.post("/v1/user/displaycalary",user.displaykcalary);
    app.post("/v1/user/adddeliveryaddress",user.addDeliveryaddress);
    app.post("/v1/user/displayaddress",user.displayaddress);
    app.post("/v1/user/displaynotifiaction",user.displayNotification);
    app.post("/v1/user/displaysubscriptionplan",user.displaySubscriptionPlane);
    app.post("/v1/user/selectsubscriptionplan",user.selectSubscriptionPlane);
    app.post("/v1/user/helpandsupport",user.helpAndSupport);
    app.post("/v1/user/contactus",user.contactUs);
    app.post("/v1/user/aboutus",user.aboutUs);
    app.post("/v1/user/termandcondition",user.termAndCondition);
    app.post("/v1/user/privacypolicy",user.privacyPolicy);
    app.post("/v1/user/report",user.report);








    













}
module.exports=CustomeRoute;