let md5 = require("md5");
let Commen = require("../../../../utilities/common");
const database = require("../../../../config/databse");
let error_code = require("../../../../utilities/error_response");
const common = require("../../../../utilities/common");
class userModule {
    async signUp(requireData, callback) {
        try {
            let data = {
                name: requireData.name,
                country_id: requireData.country_id,
                phone: requireData.phone,
                email: requireData.email,
                password: md5(requireData.password)
            }
            let deviceDetails = {
                device_token: common.generatetocken(10),
                os_version: requireData.os_version,
                app_version: requireData.os_version,
                device_type: requireData.device_type
            }
            let [check] = await database.query("select * from tbl_user where phone=? and email=? and is_deleted='0'", [data.phone, data.email]);
            if (check.length > 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "email and phone is alredy used",
                    data: []
                })
            }
            let insert = "insert into tbl_user set ?";
            let [result] = await database.query(insert, data);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "user is not register",
                    data: []
                })
            }
            deviceDetails.user_id = result.insertId;
            await database.query("insert into tbl_device set ?", deviceDetails);

            let otpDetails = {
                user_id: result.insertId,
                otp: Commen.GenerateOtp(),
                phone: requireData.phone
            }
            await database.query("insert into tbl_otp set?", otpDetails);
            return callback({
                code: error_code.success,
                keyword: "user is register",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "user is not register",
                data: []
            })
        }
    }
    async logIn(requireData, callback) {
        if (!requireData && requireData == undefined) {
            return callback({
                code: error_code.not_register,
                keyword: "data not found",
            })
        }
        console.log(requireData);

        let data = {
            password: md5(requireData.password),
            identifier: requireData.email ? requireData.email : requireData.phone,
        }
        let location = {
            latitude: requireData.latitude,
            longitude: requireData.longitude,
        }
        let deviceDetails = {
            device_type: requireData.deviceType,
            device_token: common.generatetocken(5)

        }

        let check = "select * from tbl_user where (phone=? or email=?) and password=? and is_deleted=0 and is_active=1";
        let [result] = await database.query(check, [requireData.phone, requireData.email, data.password]);
        console.log(result[0]);

        if (result.length <= 0) {
            console.log("data not found");
            return callback({
                code: error_code.no_data_found,
                keyword: "user not found",
                data: []
            })
        }
        console.log(result[0].name);

        if (result[0].step_count == 1) {
            return callback({
                code: error_code.not_register,
                content: { username: result[0].name },
                keyword: "not_verified",
            })
        }
        if (result[0].step_count == 2) {
            return callback({
                code: error_code.not_register,
                keyword: "set your location first",
            })

        }
        if (result[0].step_count == 3) {
            return callback({
                code: error_code.not_register,
                keyword: "set your fitness goal first",
            })

        }
        if (result[0].step_count == 4) {
            return callback({
                code: error_code.not_register,
                keyword: "complete your profile first",
            })
        }
        await database.query("update tbl_delivery_address set ? where id=?", [location, result[0].id]);
        await database.query("update tbl_device set ? where user_id=?", [deviceDetails, result[0].id])
        common.SetToken(result[0].id);

        return callback({
            code: error_code.success,
            content: { username: result[0].name },
            keyword: "login_success",
        })


    }
    async otpVerification(requireData, callback) {
        let data = {
            user_id: requireData.user_id,
            otp: requireData.otp
        }
        let [result] = await database.query("select * from tbl_otp where user_id=? and otp=?", [data.user_id, data.otp]);
        if (result.length <= 0) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no user found",
                data: []
            })
        }
        await database.query("update tbl_otp set is_verify='1' where user_id=?", [data.user_id]);
        await database.query("update tbl_user set step_count=2 where id=?", [data.user_id]);
        common.SetToken(data.user_id);
        return callback({
            code: error_code.success,
            keyword: "verification is complete",
            data: []
        })
    }
    async completProfile(requireData, callback) {
        console.log(requireData.step_count);

        if (requireData.step_count == 4) {
            let data = {
                gender: requireData.gender,
                dob: requireData.dob,
                weight: requireData.weight,
                height: requireData.height,
                target_weight: requireData.target_weight,
                physical_activity: requireData.physical_activity,
                step_count: 5
            }
            let [result] = await database.query("update tbl_user set ? where id=?", [data, requireData.user_id]);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "profile is not updated yet",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "profile is completed",
                data: result
            })
        } else if (requireData.step_count == 2) {
            let data = {
                latitude: requireData.latitude,
                longitude: requireData.longitude,
                address: requireData.address,
                user_id: requireData.user_id,

            }
            let [result] = await database.query("insert into tbl_delivery_address set ?", [data]);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "location is not updated yet",
                    data: []
                })
            }
            await database.query("update tbl_user set step_count=3 where id=?", [requireData.user_id])
            return callback({
                code: error_code.success,
                keyword: "location is set",
                data: result
            })
        } else if (requireData.step_count == 3) {
            let data = {
                fitenessgoal_id: requireData.goal_id,
                step_count: 4
            }
            let [result] = await database.query("update tbl_user set ? where id=?", [data, requireData.user_id]);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "fiteness goal is not set yet",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "fiteness goal is set",
                data: result
            })
        }
        return callback({
            code: error_code.success,
            keyword: "Profile is completed",

        })
    }
    async forgotPassword(requireData, callback) {
        try {

            let [result] = await database.query("select * from tbl_user where (email=? or phone=?) and is_deleted=0 ", [requireData.email, requireData.phone])
            if (result <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "email id or phone is not found"
                })
            }

            let otp = Commen.GenerateOtp();
            await database.query("update tbl_otp set otp=? ,is_verify='0' where user_id=?", [otp, result[0].id])
            return callback({
                code: error_code.success,
                keyword: "otp sent to your device"
            })


        } catch (error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form",
            });
        }
    }
    async resetPassword(RequireData, callback) {
        try {
            let [verify] = await database.query("select * from tbl_otp where user_id=?", [RequireData.user_id]);
            if (verify[0].is_verify == 1) {
                let data = {
                    id: RequireData.user_id,
                    password: md5(RequireData.password)
                };
                let [old_password] = await database.query("select * from tbl_user where id=?", [data.id]);
                let oldPassword = md5(old_password[0].password);
                if (oldPassword === data.password) {
                    return callback({
                        code: error_code.not_approve,
                        keyword: "Old password and new password cannot be the same"
                    });
                }
                // Check the condition of new password different from old password.
                let updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";

                let [result] = await database.query(updatePasswordQuery, [data.password, data.id]);

                if (result.length <= 0) {
                    return callback({
                        code: error_code.not_approve,
                        keyword: "password not changed"
                    });
                }

                return callback({
                    code: error_code.success,
                    keyword: "password changed"
                });
            }

            return callback({
                code: error_code.not_approve,
                keyword: "first verify your phone or email"
            });

        } catch (error) {
            console.error("Error in ResetPassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "enter proper value in form"
            });
        }
    }
    async changePassword(RequireData, callback) {
        try {


            let oldPassword = md5(RequireData.old_password);
            let newPassword = md5(RequireData.new_password);

            let checkPasswordQuery = "SELECT * FROM tbl_user WHERE id=? and is_deleted=0 and is_active=1";

            let [result] = await database.query(checkPasswordQuery, [RequireData.user_id]);
            console.log(result[0]);

            if (!result.length) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "User not found"
                });
            }

            let dbPassword = result[0].password;

            // Check if old password matches
            if (dbPassword !== oldPassword) {
                return callback({
                    code: error_code.invalid_input,
                    keyword: "Old password does not match"
                });
            }


            if (newPassword === dbPassword) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Old password and new password cannot be the same"
                });
            }


            let updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";
            let [updateResult] = await database.query(updatePasswordQuery, [newPassword, RequireData.user_id]);

            if (updateResult.affectedRows <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "Password not changed"
                });
            }

            return callback({
                code: error_code.success,
                keyword: "Password changed successfully"
            });

        } catch (error) {
            console.error("Error in ChangePassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "Enter proper values in the form"
            });
        }
    }
    async addtocart(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                meal_id: requireData.meal_id,
                qty: requireData.qty,
                date: requireData.date
            }

            let [item] = await database.query("select * from tbl_add_cart where meal_id=? and date=?", [data.meal_id, data.date]);
            if (item.length <= 0) {
                let [result] = await database.query("insert into tbl_add_cart set?", [data]);
                if (result.length <= 0) {
                    return callback({
                        code: error_code.invalid_input,
                        keyword: "items is not selected",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "items is selected",
                    data: result
                })
            } else {
                data.qty = requireData.qty + item[0].qty;
                let [result] = await database.query("update tbl_add_cart set? where user_id=?", [data, data.user_id]);
                if (result.length <= 0) {
                    return callback({
                        code: error_code.invalid_input,
                        keyword: "items is not selected",
                        data: []
                    })
                }
                return callback({
                    code: error_code.success,
                    keyword: "items is selected",
                    data: result
                })
            }


        } catch (Error) {
            console.log(Error);
            return callback({
                code: error_code.invalid_input,
                keyword: "items is not selected",
                data: []
            })
        }

    }
    async placeOrder(requireData, callback) {
        try {
            // Check if the user has an active subscription
            let [subscribstatus] = await database.query(
                `SELECT u.is_subscribe 
                 FROM tbl_user AS u 
                 INNER JOIN tbl_user_subscription AS us 
                 WHERE us.ending_date > CURRENT_DATE AND u.id = ?;`, 
                [requireData.user_id]
            );
    
            if (subscribstatus[0].is_subscribe !== 1) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "First buy a subscription plan to place an order",
                });
            }
    
            let data = {
                user_id: requireData.user_id,
                address_id: requireData.address_id,
                notes: requireData.notes
            };
    
            let mainresult = {};
    
            // Fetch unique days from the user's cart
            let [orders] = await database.query(
                `SELECT DISTINCT(date) 
                 FROM tbl_add_cart 
                 WHERE user_id = ?;`,
                [data.user_id]
            );
            if (orders.length<=0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "cart is empty",
                });
            }
            console.log("Orders:", orders);
    
            for (let i = 0; i < orders.length; i++) {
                let [cart] = await database.query(
                    `SELECT user_id, meal_id, qty, date 
                     FROM tbl_add_cart 
                     WHERE user_id = ? AND date = ?`,
                    [requireData.user_id, orders[i].date]
                );
    
                if (cart.length === 0) {
                    return callback({
                        code: error_code.not_approve,
                        keyword: "Cart is empty, order not placed",
                        data: []
                    });
                }
    
                data.order_date = cart[i].date;
    
                // Check if item is orderable based on time
                if (!(await common.checkitemtime(cart[i].meal_id, orders[i].date))) {
                    return callback({
                        code: error_code.not_register,
                        keyword: "Order must be placed at least 6 hours in advance",
                        data: mainresult
                    });
                }
    
                // Calculate total price
                let [price] = await database.query(
                    `SELECT SUM(m.price * a.qty) AS total 
                     FROM tbl_meal AS m 
                     INNER JOIN tbl_add_cart AS a ON m.id = a.meal_id
                     WHERE a.user_id = ? AND a.date = ?`,
                    [data.user_id, orders[i].date]
                );
    
                console.log("Price:", price);
    
                // Calculate delivery charge based on distance
                let distance = await common.getDistance(data.address_id);
                console.log("Distance:", distance);
    
                data.delivery_charge = distance * 20;
                data.total_price = parseInt(price[0].total) + data.delivery_charge;
    
                // Insert order into tbl_order
                let [result] = await database.query("INSERT INTO tbl_order SET ?", [data]);
                mainresult.orders = result;
    
                if (result.length === 0) {
                    return callback({
                        code: error_code.not_approve,
                        keyword: "Order is not placed",
                        data: []
                    });
                }
    
                let sub_totals = 0;
                let qty = 0;
    
                // Insert order details
                for (let element of cart) {
                    let [mealData] = await database.query(
                        "SELECT * FROM tbl_meal WHERE id = ?",
                        [element.meal_id]
                    );
    
                    let itemPrice = mealData[0].price * element.qty;
                    sub_totals += itemPrice;
                    qty += element.qty;
    
                    await database.query(
                        `INSERT INTO tbl_order_detials (order_id, meal_id, qty, price) 
                         VALUES (?, ?, ?, ?);`,
                        [result.insertId, element.meal_id, element.qty, itemPrice]
                    );
                }
    
                console.log("Sub Total:", sub_totals);
    
                // Update order summary
                let updateOrder = {
                    sub_total: sub_totals,
                    total_qty: qty,
                    status: "Confirm"
                };
    
                await database.query(
                    "UPDATE tbl_order SET ? WHERE id = ?",
                    [updateOrder, result.insertId]
                );
    
                console.log("Order Date:", orders[i].date);
    
                // Delete cart items after order placement
                await database.query(
                    `DELETE a FROM tbl_add_cart AS a 
                     INNER JOIN tbl_meal AS m ON m.id = a.meal_id 
                     WHERE a.user_id = ? AND a.date = ?;`,
                    [requireData.user_id, orders[i].date]
                );
    
                // Send order notification
                let notification = {
                    sender_id: 1,
                    reciver_id: requireData.user_id,
                    type: "place Order",
                    notification: "Your order has been placed successfully"
                };
    
                await database.query("INSERT INTO tbl_notification SET ?", [notification]);
    
                return callback({
                    code: error_code.success,
                    keyword: "Order placed successfully",
                    data: mainresult
                });
            }
        } catch (error) {
            console.error("Error in placeOrder:", error);
            return callback({
                code: error_code.not_approve,
                keyword: "Order not placed",
                data: []
            });
        }
    }
    async displayAllMeal(requireData, type, callback) {
        try {
            let mainresut = {};
            if (!requireData) {
                requireData.Day = new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date());
            }

            let id = 0;
            if (type == undefined) {
                id = 1;
            } else if (type == "Breakfast") {
                id = 2;
            } else if (type == "Dinner") {
                id = 3;
            }
            mainresut.user_details = await common.getUserDetails(requireData.user_id);
            let [allpost] = await database.query("select * from tbl_meal where catagory_id=? and day=?", [id, requireData.Day]);
            console.log(allpost[0]);
            mainresut.allpost = allpost;

            if (allpost.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "data is not found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresut
            })

        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "data not found",
                data: []
            })
        }
    }
    async displaykcalry(requireData, callback) {
        try {
            let [calary] = await database.query("select sum(m.kcal*o.qty) as calary from tbl_order_detials as o INNER JOIN tbl_meal as m on m.id=o.meal_id where o.user_id=? and m.day = DAYNAME(CURDATE())   GROUP BY o.user_id; ", [requireData.user_id]);
            if (calary.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "data is not found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: calary
            })

        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "data not found",
                data: []
            })
        }
    }
    async displayMealDetails(requireData, callback) {
        try {
            let data = {
                meal_id: requireData.meal_id
            }
            let mainresult = {}
            let [result] = await database.query("select * from tbl_meal  where id=?", [data.meal_id]);
            mainresult.mealDetails = result;
            let ingradiants = await database.query("select s.ingrediant_name  from tbl_meal as m inner join tbl_meal_ingrediants as i on i.meal_id=m.id INNER JOIN tbl_ingrediants as s on s.id=i.ingrediant_id where m.id=?", [data.meal_id]);
            mainresult.ingradiants = ingradiants[0];
            if (result.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "data is not found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "Success",
                data: mainresult
            })
        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "data not found",
                data: []
            })
        }
    }
    async displayOrderDetails(requireData, callback) {
        try {
            let data = {
                order_id: requireData.order_id
            }
            let mainresult = {};

            let [order] = await database.query("SELECT * FROM tbl_order WHERE  id=?", [data.order_id]);
            mainresult.order = order;
            let [result] = await database.query("select * from  tbl_order_detials where order_id=?", [data.order_id]);
            mainresult.orderDetails = result;
            if (order.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "not data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: " data found",
                data: mainresult
            })

        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
    }
    async displayOrders(requireData, callback) {
        try {

            let [order] = await database.query("SELECT * FROM tbl_order WHERE  user_id=?", [requireData.user_id]);
            if (order.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "not data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: " data found",
                data: order
            })

        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
    }
    async displayAddress(requireData, callback) {
        try {

            let [result] = await database.query("SELECT * FROM tbl_delivery_address WHERE  user_id=?", [requireData.user_id]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "not data found",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: " data found",
                data: result
            })

        } catch (Error) {
            return callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
    }
    async addDeliveryAddress(requireData, callback) {
        try {
            let data = {
                latitude: requireData.latitude,
                longitude: requireData.longitude,
                address: requireData.address,
                type: requireData.type,
                user_id: requireData.user_id
            }
            let [result] = await database.query("insert into tbl_delivery_address set ?", [data]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "address is not set",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "address is set",
                data: result
            })

        } catch (Error) {
            return callback({
                code: error_code.not_register,
                keyword: "address is not set",
                data: []
            })
        }
    }
    async displayNotification(requireData, callback) {
        let [notification] = await database.query("select * from tbl_notification where reciver_id=?", [requireData.user_id]);
        if (notification.length <= 0) {
            callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
        callback({
            code: error_code.success,
            keyword: "Success",
            data: notification
        })
    }
    async displaySubscriptionPlane(requireData, callback) {
        let [result] = await database.query("select * from tbl_subscription_plane");
        if (result.length <= 0) {
            callback({
                code: error_code.no_data_found,
                keyword: "no data found",
                data: []
            })
        }
        callback({
            code: error_code.success,
            keyword: "Success",
            data: result
        })
    }
    async selectSubscriptionPlane(requireData, callback) {
        let data = {
            user_id: requireData.user_id,
            plan_id: requireData.plan_id,

        }
        let [duration] = await database.query("select * from tbl_subscription_plane where id=?", [data.plan_id]);

        let date = common.calculateStartingEndDate(duration[0].duration);
        data.starting_date = date[0];
        data.ending_date = date[1];
        console.log(date);


        let [result] = await database.query("insert into tbl_user_subscription set ?", [data]);
        if (result.length <= 0) {
            callback({
                code: error_code.not_register,
                keyword: "not subscribe",
                data: []
            })
        }
        await database.query("update tbl_user set is_subscribe=1 where id=?", [requireData.user_id]);
        let notificationdata = {
            type: "subscription status",
            notification: "your subscription in done",
            reciver_id: requireData.user_id
        }
        await database.query("insert into tbl_notification set ?", [notificationdata]);
        callback({
            code: error_code.success,
            keyword: "Success",
            data: result
        })
    }
    async helpAndSupport(requireData, callback) {
        try {
            let data = {
                full_name: requireData.full_name,
                phone: requireData.phone,
                email: requireData.email,
                description: requireData.description
            }


            let insert = "insert into tbl_help set ?";
            let [result] = await database.query(insert, data);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "your query is  not register",
                    data: []
                })
            }

            return callback({
                code: error_code.success,
                keyword: "yor query is register",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "your query is  not register",
                data: []
            })
        }
    }
    async contactUs(requireData, callback) {
        try {
            let data = {
                first_name: requireData.first_name,
                last_name: requireData.last_name,
                email: requireData.email,
                subject: requireData.subject,
                description: requireData.description
            }


            let insert = "insert into tbl_contact_us set ?";
            let [result] = await database.query(insert, data);
            if (result.length < 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "your query is  not register",
                    data: []
                })
            }

            return callback({
                code: error_code.success,
                keyword: "yor query is register",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "your query is  not register",
                data: []
            })
        }
    }
    async aboutUs(requireData, callback) {
        try {
            let insert = "select * from tbl_context_page where tag=?";
            let [result] = await database.query(insert, [requireData.tag]);
            if (result.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "page not found",
                    data: []
                })
            }

            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "page not found",
                data: []
            })
        }
    }
    async termAndCondition(requireData, callback) {
        try {
            let insert = "select * from tbl_context_page where tag=?";
            let [result] = await database.query(insert, [requireData.tag]);
            if (result.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "page not found",
                    data: []
                })
            }

            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "page not found",
                data: []
            })
        }
    }
    async privacyPolicy(requireData, callback) {
        try {
            let insert = "select * from tbl_context_page where tag=?";
            let [result] = await database.query(insert, [requireData.tag]);
            if (result.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "page not found",
                    data: []
                })
            }

            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "page not found",
                data: []
            })
        }
    }
    async report(requireData, callback) {
        try {
            let data = {
                user_id: requireData.user_id,
                report: requireData.report
            }
            let insert = "insert into tbl_report set?";
            let [result] = await database.query(insert, [data]);
            if (result.length < 0) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "page not found",
                    data: []
                })
            }

            return callback({
                code: error_code.success,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.no_data_found,
                keyword: "report is not ",
                data: []
            })
        }
    }


}
module.exports = new userModule();