let md5 = require("md5");
let Commen = require("../../../../utilities/common");
const database = require("../../../../config/databse");
let error_code = require("../../../../utilities/error_response");
const common = require("../../../../utilities/common");
const { plan } = require("../../../../middelware/validation_rules");
class adminModule {

    async logIn(requireData, callback) {
        try {
            let data = {
                password: md5(requireData.password),
                email: requireData.email
            }
            let deviceDetails = {
                device_type: requireData.deviceType,
                device_token: common.generatetocken(5),
                token: common.generatetocken(10)

            }

            let check = "select * from tbl_admin where  email=? and password=? and is_deleted=0 and is_active=1";
            let [result] = await database.query(check, [data.email, data.password]);
            console.log(result[0]);

            if (result.length <= 0) {
                console.log("data not found");
                return callback({
                    code: error_code.no_data_found,
                    keyword: "admin not found",
                    data: []
                })
            }
            deviceDetails.admin_id = result[0].id;
            //await database.query("update tbl_user set ? where id=?", [location, result[0].id]);
            let [check_admin] = await database.query("select * from tbl_admin_device where admin_id=?", [result[0].id]);
            if (check_admin.length > 0) {
                await database.query("update tbl_admin_device set ? where admin_id=? ", [deviceDetails, result[0].id])
            } else {
                await database.query("insert into tbl_admin_device set ? ", [deviceDetails])
            }

            return callback({
                code: error_code.success,
                content: { username: 'admin' },
                keyword: "login_success",
            })
        } catch (Error) {
            return callback({
                code: error_code.not_register,
                keyword: "invalide email and password",
            })
        }


    }
    async addmeal(requireData, callback) {
        try {
            let data = {
                name: requireData.meal_name,
                image_name: requireData.image,
                kcal: requireData.kcal,
                carbs: requireData.carbs,
                protein: requireData.protein,
                fat: requireData.fat,
                description: requireData.description,
                ingredients: requireData.ingredients,
                catagory_id: requireData.catagory_id,
                day: requireData.day,
            }
            console.log(data);

            let [result] = await database.query("insert into tbl_meal set ?", [data]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "meal is not register",
                    data: []
                })
            }
            let ingredientsarray=data.ingredients.split(',');
            for(let i=0;i<ingredientsarray.length;i++){
                let items={
                    ingrediant_id:ingredientsarray[i],
                    meal_id:result.insertId
                }
                await database.query("insert into tbl_meal_ingrediants set ?",[items])
            }
            return callback({
                code: error_code.success,
                keyword: "meal is register ",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "meal is not register",
                data: []
            })
        }

    }
    async changeStatus(requireData, callback) {
        try {
            let data = {
                id: requireData.order_id,
                status: requireData.status
            }
            //update order status
            let [result] = await database.query("update tbl_order set status=? where id=?", [data.status, data.id]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.operation_failed,
                    keyword: "status is not change",
                    data: []
                })
            }
           
            // set notification
            let setnotifiaction = "insert into tbl_notification set ?";
            let notificationdata = {};
            let [reciver_id] = await database.query("select u.id  as id from tbl_user as u inner join tbl_order as o on o.user_id=u.id where o.id=?", [data.id]);
            notificationdata.reciver_id = reciver_id[0].id;
            
            //check status
            if (data.status == "InPreperation") {
                notificationdata.type = "Order Inprocess",
                    notificationdata.notification = "your order in process"
            }
            else if (data.status == "Out For Delivery") {
                notificationdata.type = "Order Delivery",
                    notificationdata.notification = "your order Out For Delivery"
            }
            else if (data.status == "Completed") {
                notificationdata.type = "Order is complete",
                    notificationdata.notification = "your order is complete"
            }


            let [notifiaction] = await database.query(setnotifiaction, [notificationdata]);
            if (notifiaction.length <= 0) {
                return callback({
                    code: error_code.operation_failed,
                    keyword: "notifiaction is not sent",
                    data: []
                })
            }

            return callback({
                code: error_code.success,
                keyword: "notifiaction is sent",
                data: notifiaction
            })

        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.operation_failed,
                keyword: "status is not change",
                data: []
            })
        }

    }
    async desboard(requireData,callback){
        try{
        let data={
            total_user:await common.gettotalUser(),
            total_order: await common.gettotalorder(),
            total_pending_Order:await common.gettotalPendingOrder(),
            total_completed_orders:await common.gettotalCompletedOrder(),
            toal_subscription_plan:await common.gettotalplan()
        }
        console.log(data);
        
        if(data.length<=0){
            return callback({
                code:error_code.no_data_found,
                keyword:"no data found",
                data:[]
            })
        }
        else{
            return callback({
                code:error_code.success,
                keyword:"Success",
                data:data
            })
        }
    }catch(Error){
        console.log(Error);
        return callback({
            code:error_code.no_data_found,
            keyword:"no data found",
            data:[]
        })
        
    }
    }
    async changePassword(RequireData, callback) {
        try {


            let oldPassword = md5(RequireData.old_password);
            let newPassword = md5(RequireData.new_password);

            let checkPasswordQuery = "SELECT * FROM tbl_user WHERE id=? and is_deleted=0 and is_active=1";

            let [result] = await database.query(checkPasswordQuery, [RequireData.user_id]);
            console.log(result[0]);

            if (!result.length) {
                return callback({
                    code: error_code.no_data_found,
                    keyword: "User not found"
                });
            }

            let dbPassword = result[0].password;

            // Check if old password matches
            if (dbPassword !== oldPassword) {
                return callback({
                    code: error_code.invalid_input,
                    keyword: "Old password does not match"
                });
            }


            if (newPassword === dbPassword) {
                return callback({
                    code: error_code.not_approve,
                    keyword: "Old password and new password cannot be the same"
                });
            }


            let updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";
            let [updateResult] = await database.query(updatePasswordQuery, [newPassword, RequireData.user_id]);

            if (updateResult.affectedRows <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "Password not changed"
                });
            }

            return callback({
                code: error_code.success,
                keyword: "Password changed successfully"
            });

        } catch (error) {
            console.error("Error in ChangePassword:", error);
            return callback({
                code: error_code.invalid_input,
                keyword: "Enter proper values in the form"
            });
        }
    }
    async addSubscriptionPlan(requireData, callback) {
        try {
            let data = {
                plan_name: requireData.plan_name,
                duration: requireData.duration,
                description: requireData.description,
                price: requireData.price,
               
            }
            console.log(data);

            let [result] = await database.query("insert into tbl_subscription_plane set ?", [data]);
            if (result.length <= 0) {
                return callback({
                    code: error_code.not_register,
                    keyword: "subscription plan is not register",
                    data: []
                })
            }
            return callback({
                code: error_code.success,
                keyword: "subscription plan is register ",
                data: data
            })
        } catch (Error) {
            console.log(Error);

            return callback({
                code: error_code.not_register,
                keyword: "subscription plan is not register",
                data: []
            })
        }

    }
}
module.exports = new adminModule();