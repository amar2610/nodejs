let userModule = require("../../admin/module/admin_modules");
const middleware = require("../../../../middelware/validation");
let validation_rules = require("../../../../middelware/validation_rules");
const common = require("../../../../utilities/common");
const admin_modules = require("../../admin/module/admin_modules");
class admin {
   
    logIn(req, res) {
        try{
             let data = req.body;
                    if (Object.keys(data).length != 0) {
                        data = JSON.parse(common.decryptPlain(req.body));
                    }
            let rules =validation_rules.adminlog;
            let message = {
                reauired: req.reauired
            }
            
            let keyword = {};
            if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
                admin_modules.logIn(data, function (_respons) {
                    middleware.send_response(req, res, _respons);
                })
            }
        }catch(Error){
            console.log(Error);
            
             res.status(401);
             res.send(common.encryptPlain("data is required"));
        }
    }
    async addMeal(req, res) {
        try{
            let data = req.body;
                   if (Object.keys(data).length != 0) {
                       data = JSON.parse(common.decryptPlain(req.body));
                   }
            let rules=validation_rules.addmeal;
            let message = {
                reauired: req.reauired
            }
            let keyword = {};
            if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
                admin_modules.addmeal(data, function (_respons) {
                    middleware.send_response(req, res, _respons);
                })
            }
        }catch(Error){
            console.log(Error);
            
            res.status(401);
            res.send(common.encryptPlain("data is required"));
        }
      
    }
    async addSubscriptionPlan(req, res) {
        try{
            let data = req.body;
                   if (Object.keys(data).length != 0) {
                       data = JSON.parse(common.decryptPlain(req.body));
                   }
            let rules=validation_rules.plan;
            let message = {
                reauired: req.reauired
            }
            let keyword = {};
            if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
                admin_modules.addSubscriptionPlan(data, function (_respons) {
                    middleware.send_response(req, res, _respons);
                })
            }
        }catch(Error){
            console.log(Error);
            
            res.status(401);
            res.send(common.encryptPlain("data is required"));
        }
      
    }
    async changeStatus(req, res) {
        try{
            let data = req.body;
                   if (Object.keys(data).length != 0) {
                       data = JSON.parse(common.decryptPlain(req.body));
                   }
            let rules="";
            let message = {
                reauired: req.reauired
            }
            let keyword = {};
            if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
                admin_modules.changeStatus(data, function (_respons) {
                    middleware.send_response(req, res, _respons);
                })
            }
        }catch(Error){
            console.log(Error);
            
            res.status(401);
            res.send(common.encryptPlain("data is required"));
        }
      
    }
    async desboard(req, res) {
        try{
            let data = req.body;
                   if (Object.keys(data).length != 0) {
                       data = JSON.parse(common.decryptPlain(req.body));
                   }
            let rules="";
            let message = {
                reauired: req.reauired
            }
            let keyword = {};
            if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
                admin_modules.desboard(data, function (_respons) {
                    middleware.send_response(req, res, _respons);
                })
            }
        }catch(Error){
            console.log(Error);
            
            res.status(401);
            res.send(common.encryptPlain("data is required"));
        }
      
    }
   
    changePassword(req, res) {
        let data= JSON.parse(common.decryptPlain(req.body)); 
        let rules = validation_rules.changePassword;
        let message = {
            reauired: req.reauired
        }
        data.user_id=req.user_id;
        let keyword = {};
        if (middleware.checkValidationRules(req, res, data, rules, message, keyword)) {
            userModule.changePassword(data, function (_respons) {
                middleware.send_response(req, res, _respons);
            })
        }
    }
}
module.exports = new admin();