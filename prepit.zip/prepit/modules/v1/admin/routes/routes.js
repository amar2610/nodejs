let admin=require("../../admin/controller/admin");
let CustomeRoute=(app)=>{
   
    app.post("/v1/admin/login",admin.logIn);
    app.post("/v1/admin/addmeal",admin.addMeal);
    app.post("/v1/admin/addsubscriptionplan",admin.addSubscriptionPlan);
    app.post("/v1/admin/changestatus",admin.changeStatus);
    app.post("/v1/admin/desboard",admin.desboard);



   
}
module.exports=CustomeRoute;